#!/usr/bin/env python3
"""Reproducible parameter stress test of BYTE-UNCHANGED 2026 original Plunder optimizer.
This is NOT a Bend-Rotation sweep: historical bend_rotation.py is not available.
Run: python run_stress_test.py
"""
from __future__ import annotations
import contextlib, copy, csv, hashlib, importlib.util, io, json, os, pathlib, statistics, time, types
import numpy as np
import torch

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = ROOT / 'original_plunder_allinone_final.py'
EXPECTED_SHA256='3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==EXPECTED_SHA256, 'source changed'
spec=importlib.util.spec_from_file_location('plunder_original', SOURCE)
original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
torch.set_num_threads(1)

BASE=dict(agents=16,steps=800,dt=.001,D0=.05,alpha=1.,adaptive_gain=.995,
          mem_size=100,mem_inject_every=500,mem_blend=.3,log_every=800,device='cpu')

def instances(seed,n=96):
    rng=np.random.default_rng(seed)
    J=rng.normal(0,1/np.sqrt(n),(n,n))
    J=np.triu(J,1);J=J+J.T
    return J,np.zeros(n)

def candidates():
    out=[('original_default',{})]
    for dt in [.0001,.001,.003,.01,.03,.1,.3]:
        for D0 in [0.,.001,.03,.2,1.0]:
            out.append((f'dt={dt:g};D0={D0:g}',dict(dt=dt,D0=D0)))
    for alpha in [.2,2.,6.]:
        for dt in [.01,.03]:
            out.append((f'dt={dt:g};alpha={alpha:g}',dict(dt=dt,alpha=alpha)))
    for gain in [.99,.9995,1.0]:
        out.append((f'dt=.03;gain={gain:g}',dict(dt=.03,adaptive_gain=gain)))
    for blend in [0.,.8]:
        out.append((f'dt=.03;mem_blend={blend:g}',dict(dt=.03,mem_blend=blend)))
    return out

COHORTS={'screen':([1001,1002,1003],[11,29]), 'holdout':([9001,9002,9003,9004,9005,9006,9007,9008],[11,29,47])}

CACHE={}
def evaluate(name,mods,instance,seed,cohort):
    if instance not in CACHE:
        J,h=instances(instance)
        CACHE[instance]=(J,h,torch.tensor(J,dtype=torch.float32),torch.tensor(h,dtype=torch.float32))
    J,h,Jt,ht=CACHE[instance]
    cfg=types.SimpleNamespace(**(BASE|mods|{'seed':seed}))
    start=time.perf_counter()
    buf=io.StringIO()
    with contextlib.redirect_stdout(buf):
        r=original.run_plunder(Jt,ht,cfg)
    duration=time.perf_counter()-start
    spins=np.asarray(r['best_assign'],dtype=np.float64)
    E=float(-(spins@J@spins+h@spins))
    assert np.isfinite(E) and set(spins).issubset({-1,1}), f'bad state {name}, {instance}'
    assert abs(E-float(r['best_E'])) < .03, (name,E,r['best_E'])
    return {'cohort':cohort,'configuration':name,'instance':instance,'random_seed':seed,
            'energy':E,'runtime_sec':duration,'n_spins':len(spins)}

def record_csv(path,rows):
    with path.open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)

def paired_ranking(rows,configs,instances_,seeds):
    lookup={(r['configuration'],r['instance'],r['random_seed']):r['energy'] for r in rows}
    ref='original_default'
    ranked=[]
    for name in configs:
        gains=[lookup[(ref,i,s)]-lookup[(name,i,s)] for i in instances_ for s in seeds]
        ranked.append({'configuration':name,'mean_gain_vs_default':float(np.mean(gains)),
                       'wins':sum(g>1e-6 for g in gains),'ties':sum(abs(g)<=1e-6 for g in gains),
                       'losses':sum(g < -1e-6 for g in gains),
                       'mean_energy':float(np.mean([lookup[(name,i,s)] for i in instances_ for s in seeds]))})
    return sorted(ranked,key=lambda r:r['mean_gain_vs_default'],reverse=True)

def main():
    t0=time.perf_counter()
    configs=candidates()
    config_dict=dict(configs)
    screen=[]
    inst,seeds=COHORTS['screen']
    print('SCREEN',len(configs),'configs x',len(inst)*len(seeds),'trials',flush=True)
    for k,(name,mods) in enumerate(configs):
        for i in inst:
            for s in seeds:
                screen.append(evaluate(name,mods,i,s,'screen'))
        if k%7==0:
            print('screen',k+1,'/',len(configs),'elapsed',round(time.perf_counter()-t0,1),flush=True)
    record_csv(ROOT/'screen_results.csv',screen)
    sr=paired_ranking(screen,[name for name,_ in configs],inst,seeds)
    # Top 5 from screening other than baseline; freeze before held-out execution.
    top=[r['configuration'] for r in sr if r['configuration']!='original_default'][:5]
    (ROOT/'selection.json').write_text(json.dumps({'source_sha256':EXPECTED_SHA256,'screen_instances':inst,'screen_seeds':seeds,'selection_by':'mean paired advantage on screen','selected':top,'rankings':sr},indent=2))
    print('selected',top,flush=True)
    hold=[]
    inst,seeds=COHORTS['holdout']
    test=['original_default']+top
    for k,name in enumerate(test):
        for i in inst:
            for s in seeds:
                hold.append(evaluate(name,config_dict[name],i,s,'holdout'))
        print('holdout',k+1,'/',len(test),'elapsed',round(time.perf_counter()-t0,1),flush=True)
    record_csv(ROOT/'holdout_results.csv',hold)
    hr=paired_ranking(hold,test,inst,seeds)
    # Instance-level paired gain CI: resample independent matrices, preserving paired stochastic trials.
    lookup={(r['configuration'],r['instance'],r['random_seed']):r['energy'] for r in hold}
    rng=np.random.default_rng(7744)
    for r in hr:
        name=r['configuration']
        diffs=np.array([np.mean([lookup[('original_default',i,s)]-lookup[(name,i,s)] for s in seeds]) for i in inst])
        boot=rng.choice(diffs,size=(10000,len(diffs)),replace=True).mean(axis=1)
        r['instance_mean_gain_95pct_bootstrap_CI']=[float(q) for q in np.quantile(boot,[.025,.975])]
        r['instance_wins']=int((diffs>1e-6).sum())
        r['instance_losses']=int((diffs < -1e-6).sum())
        r['instance_ties']=int((np.abs(diffs)<=1e-6).sum())
        r['avg_runtime_sec']=float(np.mean([row['runtime_sec'] for row in hold if row['configuration']==name]))
        r['modifications']=config_dict[name]
    result={'not_bend_rotation':True,'notice':'The historical bend_rotation.py operator is unavailable; no Bend-Rotation settings were changed. The historical 3-SAT encoder was defective, so independently generated symmetric SK Ising instances were used. This tests original Plunder parameter sensitivity only.',
            'source_sha256':EXPECTED_SHA256,'problem':'SK96 symmetric zero diagonal, zero field, independently rescored E(s)=-s^T J s, lower is better',
            'baseline':BASE,'screen_config_count':len(configs),'screen_trial_count':len(screen),
            'holdout_unique_instance_count':len(inst),'holdout_seeds_per_instance':len(seeds),
            'holdout_rows':len(hold),'top_frozen_before_holdout':top,'holdout_ranked':hr,'total_elapsed_seconds':time.perf_counter()-t0}
    (ROOT/'summary.json').write_text(json.dumps(result,indent=2))
    with (ROOT/'REPORT.md').open('w') as f:
        f.write('# Original CPPU aggressive parameter sweep (Bend–Rotation source missing)\n\n')
        f.write('**Status:** Executed and independently rescored. Does NOT test Bend–Rotation.\n\n')
        f.write(f'Original source SHA-256: `{EXPECTED_SHA256}`.\n\n')
        f.write(f'{len(configs)} pre-specified configurations were screened on 3 independently generated SK96 matrices × 2 stochastic seeds. Top five selected by mean paired improvement. The untouched settings and those five settings were then assessed on 8 fresh matrices × 3 stochastic seeds each. Test seeds were not used for selection.\n\n')
        f.write('All holdout energies are independently calculated as `-s.T @ J @ s`. Smaller (more negative) is better. Gains are `original energy - tuned energy`, positive means the tuned configuration is better. Confidence intervals resample 8 independent problem instances, not 24 correlated trials. The source remains unchanged; only config arguments were varied.\n\n')
        f.write('| config | mean gain vs original | wins/ties/losses (24) | matrix wins (8) | 95% bootstrap interval (energy units) |\n|---|---:|---:|---:|---|\n')
        for r in hr:
            c0,c1=r['instance_mean_gain_95pct_bootstrap_CI']
            f.write(f"| {r['configuration']} | {r['mean_gain_vs_default']:.2f} | {r['wins']}/{r['ties']}/{r['losses']} | {r['instance_wins']}/8 | [{c0:.2f}, {c1:.2f}] |\n")
        f.write('\n**Limits:** Screened on only 3 matrices, so significant selection bias may persist. Heldout eight matrices give a preliminary check, not a general superiority claim. Equal step/agent budgets for these configurations; CPU wall times may still differ. 2026 Bend–Rotation source unavailable: this study says nothing decisive about its tuning. This study also does not compare to annealing or exact optima.\n')
    print('DONE',json.dumps({'elapsed':round(time.perf_counter()-t0,1),'top':top,'holdout_top':hr[0]},indent=2),flush=True)

if __name__=='__main__': main()
