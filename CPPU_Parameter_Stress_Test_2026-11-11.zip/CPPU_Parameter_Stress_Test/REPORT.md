# Original CPPU aggressive parameter sweep (Bend–Rotation source missing)

**Status:** Executed and independently rescored. Does NOT test Bend–Rotation.

Original source SHA-256: `3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a`.

47 pre-specified configurations were screened on 3 independently generated SK96 matrices × 2 stochastic seeds. Top five selected by mean paired improvement. The untouched settings and those five settings were then assessed on 8 fresh matrices × 3 stochastic seeds each. Test seeds were not used for selection.

All holdout energies are independently calculated as `-s.T @ J @ s`. Smaller (more negative) is better. Gains are `original energy - tuned energy`, positive means the tuned configuration is better. Confidence intervals resample 8 independent problem instances, not 24 correlated trials. The source remains unchanged; only config arguments were varied.

| config | mean gain vs original | wins/ties/losses (24) | matrix wins (8) | 95% bootstrap interval (energy units) |
|---|---:|---:|---:|---|
| dt=.03;gain=0.99 | 53.30 | 24/0/0 | 8/8 | [50.77, 55.70] |
| dt=0.03;D0=0 | 52.74 | 24/0/0 | 8/8 | [49.63, 55.64] |
| dt=0.01;D0=0.001 | 52.42 | 24/0/0 | 8/8 | [49.23, 56.15] |
| dt=0.01;D0=0 | 51.66 | 24/0/0 | 8/8 | [49.01, 54.01] |
| dt=0.03;alpha=2 | 51.15 | 24/0/0 | 8/8 | [48.17, 53.68] |
| original_default | 0.00 | 0/24/0 | 0/8 | [0.00, 0.00] |

**Limits:** Screened on only 3 matrices, so significant selection bias may persist. Heldout eight matrices give a preliminary check, not a general superiority claim. Equal step/agent budgets for these configurations; CPU wall times may still differ. 2026 Bend–Rotation source unavailable: this study says nothing decisive about its tuning. This study also does not compare to annealing or exact optima.

## Independent SA sanity control

Same 24 holdout trials, Numba SA 60-sweep restarts and similar CPU time. Original mean -78.71; tuned mean -132.01; SA mean -141.13. SA wins 24 times, tuned wins 0 times, ties 0. SA mean advantage over tuned: 9.12 energy units (matrix-level bootstrap interval [7.88,10.40]). SA average runtime 0.0374s, CPPU tuned average runtime 0.0372s. SA is an independently written Numba control, not official Neal; compiled and runtime methods differ.
