#!/usr/bin/env python3
"""Independent Metropolis simulated annealing control. On the *same* held-out SK96 instances.
This is an illustrative CPU-time control, not an official Neal benchmark.
"""
import importlib.util, json, pathlib, time, csv
import numba as nb
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stress', ROOT/'run_stress_test.py')
stress=importlib.util.module_from_spec(spec);spec.loader.exec_module(stress)

@nb.njit
# bounded 60-sweep SA restart, exactly recalculate energy on finished state
# note J symmetric, diag=0; dE_flip=4*s_i*(J@s)_i.
def _sa_restart(J,seed,sweeps,hot,cold):
    np.random.seed(seed)
    n=J.shape[0]
    s=np.empty(n,np.int8)
    for i in range(n):s[i]=1 if np.random.random()<.5 else -1
    local=J@s.astype(np.float64)
    e=0.
    for i in range(n):e-=s[i]*local[i]
    best=e
    best_s=s.copy()
    ratio=np.log(cold/hot)/max(1,sweeps-1)
    for sweep in range(sweeps):
        temp=hot*np.exp(ratio*sweep)
        for step in range(n):
            i=np.random.randint(n)
            dE=4.*s[i]*local[i]
            if dE<=0 or np.random.random()<np.exp(-dE/temp):
                old=s[i]
                s[i]=-old
                for j in range(n):local[j]-=2.*old*J[j,i]
                e+=dE
                if e<best:
                    best=e
                    best_s=s.copy()
    return best,best_s

def sa_timed(J,seed,budget=.038,hot=4.,cold=.01,sweeps=60):
    start=time.perf_counter()
    best=np.inf;best_s=None;restarts=0
    while time.perf_counter()-start < budget or restarts==0:
        e,s=_sa_restart(J,seed+restarts*104729,sweeps,hot,cold)
        if e < best:
            best=e;best_s=s
        restarts+=1
    runtime=time.perf_counter()-start
    E=-(best_s.astype(float)@J@best_s.astype(float))
    assert abs(best-E)<1e-7, (E,best)
    return E,runtime,restarts

def main():
    _sa_restart(np.zeros((4,4)),123,2,1.,.1) # compile outside timer
    data=json.loads((ROOT/'summary.json').read_text())
    tuned='dt=.03;gain=0.99'
    look={(int(r['instance']),int(r['random_seed']),r['configuration']):r for r in csv.DictReader((ROOT/'holdout_results.csv').open())}
    rows=[]
    for instance in stress.COHORTS['holdout'][0]:
        J,_=stress.instances(instance)
        for seed in stress.COHORTS['holdout'][1]:
            # Use measured tuned runtime as target; SA may finish a restart after budget.
            budget=float(look[(instance,seed,tuned)]['runtime_sec'])
            E,runtime,restarts=sa_timed(J,seed+500,budget)
            rows.append({'instance':instance,'seed':seed,'SA_energy':E,'SA_runtime_sec':runtime,
                         'SA_restarts':restarts,'tuned_energy':float(look[(instance,seed,tuned)]['energy']),
                         'tuned_runtime_sec':budget,'original_energy':float(look[(instance,seed,'original_default')]['energy'])})
    with (ROOT/'sa_holdout.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    d=np.array([r['tuned_energy']-r['SA_energy'] for r in rows]) # positive means SA beats tuned
    gains=[]
    for i in stress.COHORTS['holdout'][0]:
        gains.append(np.mean([r['tuned_energy']-r['SA_energy'] for r in rows if r['instance']==i]))
    rng=np.random.default_rng(12344)
    ci=np.quantile(rng.choice(gains,size=(10000,len(gains)),replace=True).mean(axis=1),[.025,.975])
    out={'SA_mean_energy':float(np.mean([r['SA_energy'] for r in rows])),
         'tuned_mean_energy':float(np.mean([r['tuned_energy'] for r in rows])),
         'original_mean_energy':float(np.mean([r['original_energy'] for r in rows])),
         'SA_wins':int((d>1e-7).sum()),'SA_ties':int((abs(d)<=1e-7).sum()),'tuned_wins':int((d<-1e-7).sum()),
         'SA_mean_advantage_over_tuned':float(np.mean(d)),
         'instance_bootstrap95_CI_SA_advantage':[float(ci[0]),float(ci[1])],
         'SA_mean_runtime_sec':float(np.mean([r['SA_runtime_sec'] for r in rows])),
         'tuned_mean_runtime_sec':float(np.mean([r['tuned_runtime_sec'] for r in rows])),
         'average_restarts':float(np.mean([r['SA_restarts'] for r in rows])),
         'method':'Independent Numba Metropolis annealing, 60 sweeps/restart, geometric temperature 4 to 0.01, runtime target = matched tuned original wall-time. Restarts may slightly overrun; not DWave Neal.'}
    (ROOT/'sa_summary.json').write_text(json.dumps(out,indent=2))
    with (ROOT/'REPORT.md').open('a') as f:
        f.write('\n## Independent SA sanity control\n\n')
        f.write(f"Same 24 holdout trials, Numba SA 60-sweep restarts and similar CPU time. Original mean {out['original_mean_energy']:.2f}; tuned mean {out['tuned_mean_energy']:.2f}; SA mean {out['SA_mean_energy']:.2f}. SA wins {out['SA_wins']} times, tuned wins {out['tuned_wins']} times, ties {out['SA_ties']}. SA mean advantage over tuned: {out['SA_mean_advantage_over_tuned']:.2f} energy units (matrix-level bootstrap interval [{ci[0]:.2f},{ci[1]:.2f}]). SA average runtime {out['SA_mean_runtime_sec']:.4f}s, CPPU tuned average runtime {out['tuned_mean_runtime_sec']:.4f}s. SA is an independently written Numba control, not official Neal; compiled and runtime methods differ.\n")
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
