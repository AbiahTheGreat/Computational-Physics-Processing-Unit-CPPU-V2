# Bend–Rotation: source-dependent next stress test

This is a future experiment specification, **not executed Bend–Rotation testing**. The original `bend_rotation.py` is missing from the available files. Do not substitute a newly invented Bend–Rotation update while claiming to reproduce the August 2026 study.

## Historically recorded interface

- Imported classes: `BendRotationConfig`, `BendRotationOperator`
- Processor call: `x, bend, omega, br_metrics = bend_rotation.step(x,bend,omega,drift,dt)` after the regular drift/noise and sphere projection.
- Historical defaults (reported in conversation): `stiffness=.20`, `inertia=1.0`, `coupling=1.0`, `damping=.08`, `load_gain=.20`, `max_angle=.25`, `max_bend=2.0`.
- Plunder historical control: `dt=.001`, `D0=.05`, `adaptive_gain=.995`, `agents=64`, `steps=1000`, though the source archive's default config differs on agents and hardcodes an optimizer seed.

## Parameter exploration once original source is recovered

1. Correct seed plumbing. Ensure per-run, per-matrix independent initial conditions for both branches. Save hashes of all source files.
2. Control for **identical random initial states** (and if possible, identical exogenous noise sequences) between Bend–Rotation enabled vs disabled.
3. One-at-a-time logarithmic scans for `stiffness ∈ {.005,.02,.08,.2,.8,2}`, `inertia ∈ {.05,.2,1,5,20}`, `coupling ∈ {0,.05,.2,1,4,12}`, `damping ∈ {0,.005,.02,.08,.3,1.2}`, `load_gain ∈ {0,.02,.1,.2,.8,3}`, `max_angle ∈ {.01,.05,.25,.75,2}`, `max_bend ∈ {.05,.25,2,6,15}`; vary dt and noise separately. These are proposed experimental values, not proven numerically stable.
4. Use controlled randomized / Latin-hypercube combinations rather than full factorial. Track finite states, any forced clipping/saturation, angular displacement, bend magnitude, drift contribution, and true discrete objective improvements at equal compute/time budgets.
5. Screen on 12 independent Ising SK matrices and 12 correctly encoded MAX-3SAT instances (not original incorrect 3-SAT script); freeze top settings before testing on at least 24 completely new matrices and clause sets with multiple run seeds. Score SAT as actual violated clauses, and independently rescore all saved assignments.
6. Compare original CPPU, original plus Bend–Rotation, tuned CPPU, tuned CPPU plus Bend–Rotation, tuned SA, and optionally first-order local search; vary rotation disabled/bend disabled to isolate specific contributions. Report wall time, objective gap, and paired uncertainties by **instance**, not by agent or repeated seed.
7. Reject claims of effectiveness if improvements disappear on held-out instances or if rotation only speeds continuous relaxation without helping the discrete scores.

## Current executed results

See `REPORT.md`, `screen_results.csv`, `holdout_results.csv`, and `sa_holdout.csv`. Those assess only the original Plunder optimizer under different configuration inputs. They are **not** Bend–Rotation ablations.
