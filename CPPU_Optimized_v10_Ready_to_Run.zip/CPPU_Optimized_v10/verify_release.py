"""CPU smoke checks for packaged CPPU research solvers; no external downloads required."""
from pathlib import Path
import hashlib
import numpy as np
from phase8_direct_sat import occurrence_table
from phase9_event_core import solve_event
from phase7_core_optimized import refractory_ising

root=Path(__file__).parent
expected_source_sha='3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a'
source_sha=hashlib.sha256((root/'source_reference/plunder_allinone_final.py').read_bytes()).hexdigest()
assert source_sha==expected_source_sha,'Original CPPU source integrity mismatch'
C=np.array([[1,-2,3],[-1,2,-4],[1,3,-4]],dtype=np.int32)
O,P,cnt=occurrence_table(C,4)
b,v,moves=solve_event(C,O,P,cnt,901,300,1,4,45,.15,True)
real=int(np.sum(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))
assert int(v)==real and int(v)==0,('SAT scoring mismatch',v,real)
J=np.array([[0.,1.,-0.4],[1.,0.,0.2],[-0.4,0.2,0.]],dtype=np.float64)
h=np.zeros(3,dtype=np.float64)
s,e=refractory_ising(J,h,902,250,7,0.)
real_e=-float(s@(J@s)+h@s)
assert abs(float(e)-real_e)<1e-8,'Ising scoring mismatch'
print('PASS: original-source SHA256, SAT event cache, SAT objective, Ising objective')
