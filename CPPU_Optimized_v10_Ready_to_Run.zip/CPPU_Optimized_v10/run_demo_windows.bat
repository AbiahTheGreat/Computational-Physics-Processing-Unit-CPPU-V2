@echo off
py -3.10 -m pip install -r requirements.txt
py -3.10 run_cppu.py --demo --starts 8 --steps 2000
pause
