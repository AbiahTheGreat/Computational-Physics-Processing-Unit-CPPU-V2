"""Standalone CLI for *new classical Phase9 research solvers*, not source-original CPPU.
3CNF input must have exactly three distinct literals per clause. Ising input uses
CPPU convention E = -(s.T @ J @ s + h.T @ s), J symmetric with zero diagonal.
"""
import argparse,pathlib,time,json
import numpy as np
from phase8_cases import generate_clauses
from phase8_direct_sat import occurrence_table
from phase9_event_core import solve_event
from phase7_core_optimized import refractory_ising

def load_dimacs(path):
    n=None;declared=None;clauses=[];pending=[]
    for line in pathlib.Path(path).read_text(encoding='utf-8').splitlines():
        s=line.strip()
        if not s or s.startswith('c') or s.startswith('%'):continue
        if s.startswith('p'):
            toks=s.split()
            if len(toks)!=4 or toks[1]!='cnf':raise ValueError('Only DIMACS p cnf is supported, not weighted/hard MaxSAT')
            n=int(toks[2]);declared=int(toks[3]);continue
        if n is None:raise ValueError('DIMACS header required')
        for token in s.split():
            lit=int(token)
            if lit==0:
                if len(pending)!=3 or len(set(abs(v) for v in pending))!=3:
                    raise ValueError('Each clause must contain exactly 3 distinct variables')
                if any(abs(v)>n or v==0 for v in pending):raise ValueError('Invalid variable index')
                clauses.append(pending);pending=[]
            else:pending.append(lit)
    if n is None or pending or len(clauses)!=declared:raise ValueError('Malformed or incomplete DIMACS CNF')
    return np.asarray(clauses,dtype=np.int32),n

def sat(C,n,seed,starts,steps,output):
    O,P,cnt=occurrence_table(C,n)
    best_score=len(C)+1;best_bits=None
    tic=time.perf_counter()
    for t in range(starts):
        b,v,moves=solve_event(C,O,P,cnt,seed+t*7919,steps,1,4,45,.15)
        independent=int(np.sum(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))
        if independent!=v:raise AssertionError('Score mismatch')
        if v<best_score:best_score=v;best_bits=b.copy()
        if v==0:break
    seconds=time.perf_counter()-tic
    np.savez_compressed(output,assignment=best_bits,clauses=C,violations=best_score)
    print(json.dumps(dict(mode='3SAT classical event-tabu research',n=n,clauses=len(C),violations=best_score,
                          starts=t+1,seconds=round(seconds,6),saved=str(output)),indent=2))

def ising(J,h,seed,steps,output):
    if J.ndim!=2 or J.shape[0]!=J.shape[1] or h.shape!=(len(J),) or not np.isfinite(J).all() or not np.isfinite(h).all() or not np.allclose(J,J.T,atol=1e-9):
        raise ValueError('J must be finite symmetric NxN and h finite N-vector')
    if not np.allclose(np.diag(J),0,atol=1e-9):raise ValueError('Diagonal must be zero (remove it and separately record any offset)')
    tic=time.perf_counter()
    s,energy=refractory_ising(J,h,seed,steps,17,0.)
    actual=-float(s@(J@s)+h@s)
    if abs(actual-energy)>1e-6:raise AssertionError('Energy mismatch')
    np.savez_compressed(output,assignment=s,energy=actual)
    print(json.dumps(dict(mode='Ising classical refractory memory research',n=len(s),energy=actual,
                          seconds=round(time.perf_counter()-tic,6),saved=str(output)),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    z=p.add_mutually_exclusive_group(required=True)
    z.add_argument('--demo',action='store_true');z.add_argument('--cnf');z.add_argument('--ising')
    p.add_argument('--h');p.add_argument('--seed',type=int,default=1234)
    p.add_argument('--starts',type=int,default=8);p.add_argument('--steps',type=int,default=2000)
    p.add_argument('--output',default='phase9_solution.npz');args=p.parse_args()
    if args.steps<1 or args.starts<1:raise SystemExit('steps and starts must be positive')
    output=pathlib.Path(args.output)
    if args.ising:
        J=np.load(args.ising)
        h=np.load(args.h) if args.h else np.zeros(J.shape[0],dtype=float)
        ising(J,h,args.seed,args.steps,output)
    else:
        if args.demo:C=generate_clauses(64,round(4.27*64),987654);n=64
        else:C,n=load_dimacs(args.cnf)
        sat(C,n,args.seed,args.starts,args.steps,output)
