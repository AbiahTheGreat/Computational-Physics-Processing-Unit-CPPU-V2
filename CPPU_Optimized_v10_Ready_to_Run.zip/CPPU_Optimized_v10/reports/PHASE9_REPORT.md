# CPPU Research Phase 9: Event-Driven Discrete Search, Controlled Tests, and Distribution Shift

**Run date:** November 7, 2026 (session research continuation).  
**Status:** Original CPPU preserved as reference; new **classical**, Numba-compiled optimization software measured and audited.  
**Not established:** No unique physical processing law, no novel hardware acceleration, no published state-of-the-art performance, and **no executed official D-Wave Neal, D-Wave Tabu, MaxSAT Evaluation, or MIPLIB benchmark**.

## Executive result

The leading Phase 8 SAT implementation scanned every clause on each optimization move to locate an unsatisfied clause. Phase 9 maintains an *incrementally updated list of unsatisfied clauses* with constant-time uniform selection and constant-time removal/insertion per clause-status change. The objective remains the exact number of violated original 3-SAT clauses, the short-term flip-memory mechanism is retained, and independent verification detects score errors.

This gives much more search throughput at equal short wall-clock budgets. **The consistently transferable version is unweighted event-driven flip-memory (called `event_tabu` below)**. Additional dynamic clause weighting helped modestly on some 512-variable random instances but **hurt** on structured parity/XOR instances and generally at larger sizes.

This is an incremental-data-structure improvement to a conventional local-search algorithm. It is **not** proof that the original CPPU sphere dynamics outperformed annealing or that the custom architecture has demonstrated physics-driven superiority.

## 1. Locked random MAX-3SAT confirmation

Fresh 72 random problems: 512 and 1,024 variables, each with 12 instances at three clause densities **4.10, 4.27, 4.50**, tested twice for each of six methods. Each method received nominal **75 ms CPU-wall time** per attempt on the same host with JIT compilation warmed up and excluded from the budget. Actual runtimes were recorded; the maximum budget overrun was about **12%**. This yields **864 independently rescored final assignments**.

| Method | Mean violated clauses, 512 variables | Mean violated clauses, 1,024 variables |
|---|---:|---:|
| Phase 8 source implementation | 8.056 | 39.972 |
| **Phase 9 event-driven flip memory (unweighted)** | **5.444** | **24.000** |
| Phase 9 event-driven flip memory + clause weights | 5.389 | 24.972 |
| Event-driven local WalkSAT-style control | 8.194 | 37.569 |
| Event-driven local ProbSAT-style control | 6.778 | 35.097 |
| Event-driven Novelty-style local control | 6.361 | 26.708 |

**Paired difference versus Phase 8** (positive means fewer violated clauses with Phase 9, using an instance-stratified bootstrap that retains both attempts per instance):

- **512 variables:** +2.611 fewer clauses, exploratory 95% bootstrap interval **[2.139, 3.056]**; 57 improvements, 9 ties, 6 regressions across 72 attempts.
- **1,024 variables:** +15.972 fewer clauses, interval **[14.611, 17.375]**; 71 improvements, 1 tie, 0 regressions.

These are genuine same-host results on a locked independent test set after small calibration. The comparison is against *these implementations*, not external industrial solvers. The altered method's main gain comes from skipping redundant scans and performing more attempted flips within the time budget, not a new search law.

## 2. Independent distribution-shift test: parity/XOR-derived 3-CNF

Constructed 32 independently seeded parity systems at 256/512 variables and 0.8/1.1 XOR equations per variable. Each XOR constraint was encoded by exactly four 3-literal CNF clauses, such that a violated XOR equation produces exactly one violated clause, for every assignment. Two trials per instance and six methods produced **384 independently verified solutions**. No parameter retuning was performed on this test family.

| Method | 256 variables: mean violated XOR equations | 512 variables: mean violated XOR equations |
|---|---:|---:|
| Phase 8 source implementation | 8.844 | 28.969 |
| **Phase 9 unweighted event-driven flip memory** | **6.188** | **19.281** |
| Phase 9 weighted event-driven variant | 7.719 | 26.344 |
| Local event Novelty-style | 6.656 | 22.531 |
| Local event WalkSAT-style | 7.938 | 27.125 |
| Local event ProbSAT-style | 8.625 | 29.188 |

**Crucial negative result:** Additional clause weighting had previously looked beneficial in random 512-variable 3-SAT, but **underperformed unweighted memory on parity-structured clauses**. The simpler method is therefore the most defensible default for this release. Both are established classes of local search; an advantage over these local baseline implementations is not a claim of novelty or state-of-the-art performance.

## 3. Limited scaling check: 2,048 and 4,096 variables

Sixteen additional fresh random MAX-3SAT problems (8 per problem size, clause ratios 4.27 and 4.50), one run per method and nominal **100 ms** per method, with five methods (80 independently verified assignments):

| Method | 2,048 variables: mean violated clauses | 4,096 variables: mean violated clauses |
|---|---:|---:|
| Phase 8 source | 187.625 | 772.250 |
| **Phase 9 unweighted memory** | **100.625** | **447.500** |
| Phase 9 weighted memory | 139.125 | 555.625 |
| Local event Novelty-style | 118.875 | 485.875 |
| Local event ProbSAT-style | 175.750 | 699.500 |

These small scale samples are diagnostic, not a formal scaling-law study. The new data structure continues to help at these larger sizes. An execution at 100 ms is too brief to characterize the algorithms' best-achievable qualities.

## 4. Verification, provenance, and scientific limitations

- **1,328** final assignments independently rescored using original clause matrices reconstructed from deterministic instance seeds: 864 random confirmation + 384 XOR shifts + 80 large-instance trials. **Zero score mismatches.**
- Each XOR assignment independently checked against both the CNF clause count and source XOR parity constraints, yielding identical objective values.
- Incrementally maintained clause counters, unsatisfied-index positions, and list cardinality checked after individual moves in instrumented tests across three problem sizes and five algorithms. The test uses up to 1,000 optimization steps per configuration; a solved instance may terminate earlier.
- Original archived `plunder_allinone_final.py` SHA-256: `3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a`, unchanged. Source is included **for provenance**, but Phase 9 SAT result tables compare new classical methods, **not original Plunder versus Neal**.
- One-machine ~75–100 ms comparisons are sensitive to scheduling, JIT warmup behavior, other workloads, and exact solver settings. They are not hardware-independent performance rankings.
- These test sets are synthetic, heavily randomized and limited to unweighted **exactly 3-distinct-literal** clauses. Phase 9 cannot simply accept arbitrary industrial WCNF, weighted partial MaxSAT, or MIPLIB problems.
- The event-driven control methods are local implementations of WalkSAT/ProbSAT/Novelty-style heuristics, **not the authors' optimized official implementations**. They cannot establish superiority over leading external programs.

## 5. Retained post-December findings

The strongest transferable ideas from the historical review were: correct SAT representation and independent verification, flip-memory that prevents short search cycles, avoiding wasted random draws when noise is zero, and accurate seeds/objectives. Bend-Rotation's controlled August test had 30 ties; the later Pop/Shell/Thumper investigations did not establish a distinct speed advantage for optimization. No evidence in these results justifies reintroducing those unverified operators into the best SAT engine.

The source-original CPPU numerical dynamics remain preserved separately. A useful software optimization and a validated distinct CPPU physical advantage are different claims.

## 6. Official Neal verification remains external and **unexecuted**

`phase9_official_dwave_runner.py --preflight` passed exact QUBO/Ising and incremental event-state checks in the current CPU runtime. The `--run` path intentionally fails if the actual `dwave-neal` package is unavailable. The package cannot be installed here due to restricted network access; no official Neal scores appear in this report.

The repository-ready workflow `phase9_official_dwave_workflow.yml` installs `dwave-neal`, `dwave-samplers`, `dimod`, `torch`, `numpy`, `numba` on GitHub-hosted CPU hardware, compares source-original Plunder, Phase 7, Phase 8, Phase 9, official Neal and official D-Wave Tabu, and stores complete returned solutions with independently scored energies/clauses. **This workflow has been locally preflighted but not actually run on GitHub Actions.** SAT methods use different internal encodings; they are evaluated by shared clause count, and original Plunder runtime anchors the nominal budgets.

The **2026 MaxSAT Evaluation** provides a more demanding public collection and rankings: https://maxsat-evaluations.github.io/2026/ . Those data and submitted solvers are not yet compatible with this exact-3CNF-only solver without additional changes. See the published benchmark collection at https://zenodo.org/records/21358014 .

## 7. Local reproduction

Requirements: Python 3.10+ or another compatible Python version with `numpy`, `numba`, `pandas` (audits), and optional `matplotlib` (visualizations). All runs are CPU-compatible. Install optional D-Wave packages **only** for the external benchmark.

```
python phase9_event_core.py
python phase9_audit.py
python phase9_xor_audit.py
python phase9_large_audit.py
python phase9_official_dwave_runner.py --preflight
python run_cppu_phase9.py --demo
python run_cppu_phase9.py --cnf example.cnf
python run_cppu_phase9.py --ising example_J.npy
```

The benchmark generation and repeated-attempt scripts are included. Run `phase9_benchmark.py --phase confirmation --budget .075 --shard K --shards 8` for K=0…7 to reproduce the experimental method (results will vary slightly with host scheduling). No original experiments were rerun during packaging; saved results are checked independently.

**Conclusion:** Phase 9 delivered a measurable, reproducible engineering improvement in a **new classical local-search implementation**. The most durable result is event-driven maintenance of unsatisfied clauses combined with the existing short-term flip-memory. The original CPPU's unique physical operators still have **no demonstrated competitive advantage**, and actual Neal/industrial benchmarking remains the next external requirement.
