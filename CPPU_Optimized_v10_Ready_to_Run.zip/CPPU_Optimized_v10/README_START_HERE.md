# CPPU Optimized v10 | Runnable research software

This is the **latest packaged optimized solver** from CPPU Phases 9–10 (November 7, 2026). It contains:

- An **event-driven exact-3CNF MAX-SAT solver** with short-term flip memory (default, Phase 9).
- A separate **Ising spin-glass solver** with discrete refractory memory (Phase 7, retained in Phase 10).
- Your **unchanged original Plunder/CPPU code** under `source_reference/` for research provenance.
- A prepared, **NOT YET EXECUTED**, official D-Wave Neal/Tabu benchmark runner and GitHub Actions workflow.

This is ordinary **CPU-based classical optimization software**, not a quantum processor or a proven novel physical computing advantage. The strongest practical improvements from these phases use established local-search approaches.

## Quick start on Windows

1. Extract this ZIP.
2. Open Terminal/PowerShell inside the extracted `CPPU_Optimized_v10` directory.
3. Install requirements: `py -3.10 -m pip install -r requirements.txt`
4. Run demo: `py -3.10 run_cppu.py --demo --starts 8 --steps 2000`
5. Test included SAT input: `py -3.10 run_cppu.py --cnf examples/example.cnf --output sat_solution.npz`
6. Test included Ising input: `py -3.10 run_cppu.py --ising examples/example_J.npy --steps 8000 --output ising_solution.npz`
7. Check package: `py -3.10 verify_release.py`

If your Python command is `python` rather than `py -3.10`, use `python` in the commands. No GPU or Ollama required.

## Common commands

```
python run_cppu.py --demo --starts 8 --steps 2000
python run_cppu.py --cnf examples/example.cnf --starts 8 --steps 2000
python run_cppu.py --ising examples/example_J.npy --steps 8000
python verify_release.py
python official_dwave_runner.py --preflight
```

The SAT parser accepts **unweighted DIMACS CNF with exactly three distinct literals per clause**; other SAT/MaxSAT formats are intentionally rejected rather than silently misinterpreted. Input Ising matrices must be finite, symmetric and have zero diagonals. `J`, `h` follow `E(s)=-(s.T @ J @ s + h.T @ s)`.

## D-Wave official test

The included `.github/workflows/official-dwave.yml` runs `official_dwave_runner.py` on GitHub-hosted CPU hardware using `dwave-samplers`, `dimod` and `torch`. **It has not been run, and it is not a performance result.** GitHub Actions will only execute after these files are committed to a repository with Actions enabled and the workflow is manually dispatched. See the published source and reports for detailed limitations.

## What is and isn't the original CPPU

`source_reference/plunder_allinone_final.py` is byte-preserved original source. The optimized `phase9_event_core.py` and `phase7_core_optimized.py` are separately developed, classic local-search variants. Do not attribute their benchmarks to the original continuous Plunder dynamics.

Research reports: `reports/PHASE9_REPORT.md`, `reports/PHASE10_REPORT.md`.
