"""Confirmatory test: LOCKED settings from separate calibration.
Fresh independent problems across critical +/- clause-density shift.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import sys,csv,time,pathlib,json,platform
import numpy as np
from phase8_direct_sat import occurrence_table
from phase8_focused_memory import focused_memory
from phase8_baselines import fast_walksat,probsat
from phase8_cases import generate_clauses
D=pathlib.Path(__file__).parent;out=D/'confirm_assignments';out.mkdir(exist_ok=True)
METHODS=('focused_tabu','focused_tabu_weights','walksat_optimized','probsat_optimized')

def independent(C,b):return int((~(b[np.abs(C)-1]==(C>0)).any(axis=1)).sum())
def run(name,C,O,P,ct,seed,budget=0.065):
 st=time.perf_counter();best=10**9;state=None;r=0
 while r==0 or time.perf_counter()-st<budget:
  sd=seed+809*r
  if name=='focused_tabu':b,v=focused_memory(C,O,P,ct,sd,3500,4,0,1,.15)
  elif name=='focused_tabu_weights':b,v=focused_memory(C,O,P,ct,sd,3500,4,1,1,.15)
  elif name=='walksat_optimized':b,v=fast_walksat(C,O,P,ct,sd,3500,.38)
  else:b,v=probsat(C,O,P,ct,sd,3500,2.3)
  z=independent(C,b)
  if z!=v:raise AssertionError('Incorrect clause score')
  if z<best:best=z;state=b.copy()
  r+=1
  if best==0:break
 return state,best,time.perf_counter()-st,r
C=generate_clauses(32,137,1);O,P,ct=occurrence_table(C,32)
for name in METHODS:run(name,C,O,P,ct,123,.0001)
rows=[]
for ratio_i,ratio in enumerate([4.1,4.27,4.5]):
 for j in range(10):
  inst=1080000+ratio_i*1000+j
  C=generate_clauses(512,round(ratio*512),inst);O,P,ct=occurrence_table(C,512)
  for rep in range(2):
   seed=inst*37+rep*7919
   order=METHODS[(j+rep)%4:]+METHODS[:(j+rep)%4]
   for name in order:
    b,v,secs,reads=run(name,C,O,P,ct,seed)
    fname=f'{inst}_{rep}_{name}.npz';np.savez_compressed(out/fname,clauses=C,bits=b,violations=v)
    rows.append(dict(ratio=ratio,instance=inst,rep=rep,seed=seed,method=name,violations=v,seconds=secs,reads=reads,assignment=fname))
  print('CONFIRM',ratio,inst,flush=True)
with (D/'confirm.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
sums=[]
for ratio in (4.1,4.27,4.5):
 for name in METHODS:
  a=[r for r in rows if r['ratio']==ratio and r['method']==name]
  sums.append(dict(ratio=ratio,method=name,trials=len(a),median=float(np.median([r['violations'] for r in a])),mean=float(np.mean([r['violations'] for r in a])),solved=sum(r['violations']==0 for r in a),median_seconds=float(np.median([r['seconds'] for r in a]))))
  print('C-SUMMARY',sums[-1],flush=True)
(D/'confirm_summary.json').write_text(json.dumps(dict(summary=sums,seed_starts=[1080000,1081000,1082000],n=512,ratio_values=[4.1,4.27,4.5],notable='No tuning performed on confirmation cases.'),indent=2))
