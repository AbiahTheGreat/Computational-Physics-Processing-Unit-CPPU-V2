"""Fresh independent held-out set after tuning on seeds 798000..004 and 926000..004.
Nominal wallclock budgets include all work after JIT compilation; completed calls overshoot.
Full assignments saved and separately rescored. No official DWave Neal run.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import sys,csv,time,pathlib,json,platform,hashlib
import numpy as np
from phase8_direct_sat import occurrence_table
from phase8_focused_memory import focused_memory
from phase8_baselines import fast_walksat,probsat
from phase8_cases import generate_clauses
D=pathlib.Path(__file__).parent
OUT=D/'focused_assignments';OUT.mkdir(exist_ok=True)
METHODS=('focused_no_tabu','focused_tabu','focused_tabu_weights','walksat_optimized','probsat_optimized')
PLANS=((128,12,0.015,1061280),(256,12,0.035,1062560),(512,8,0.065,1065120))

def rescore(C,b):
    literal_truth=(b[np.abs(C)-1]==(C>0).astype(np.int64))
    return int(np.count_nonzero(np.logical_not(np.any(literal_truth,axis=1))))

def execute(name,C,O,P,cnt,seed,budget):
    start=time.perf_counter();best=10**9;bb=None;reads=0
    while reads==0 or time.perf_counter()-start<budget:
        sd=seed+reads*5927
        if name=='focused_no_tabu':b,v=focused_memory(C,O,P,cnt,sd,3500,0,0,1,.15)
        elif name=='focused_tabu':b,v=focused_memory(C,O,P,cnt,sd,3500,4,0,1,.15)
        elif name=='focused_tabu_weights':b,v=focused_memory(C,O,P,cnt,sd,3500,4,1,1,.15)
        elif name=='walksat_optimized':b,v=fast_walksat(C,O,P,cnt,sd,3500,.38)
        else:b,v=probsat(C,O,P,cnt,sd,3500,2.3)
        rv=rescore(C,b)
        if rv!=v:raise AssertionError((name,rv,v))
        if rv<best:
            best=rv;bb=b.copy()
        reads+=1
        if best==0:break
    return bb,best,time.perf_counter()-start,reads
C=generate_clauses(32,137,2027);O,P,ct=occurrence_table(C,32)
for name in METHODS:execute(name,C,O,P,ct,303,0.0001)
rows=[]
for n,ninst,budget,prefix in PLANS:
    for ii in range(ninst):
        inst=prefix+ii
        C=generate_clauses(n,round(4.27*n),inst);O,P,ct=occurrence_table(C,n)
        for rep in range(2):
            seed=inst*61+rep*9001
            order=METHODS[(ii+rep)%5:]+METHODS[:(ii+rep)%5]
            for name in order:
                b,v,secs,reads=execute(name,C,O,P,ct,seed,budget)
                fn=f'{n}_{inst}_{rep}_{name}.npz';np.savez_compressed(OUT/fn,clauses=C,bits=b,violations=v)
                rows.append(dict(n=n,instance=inst,rep=rep,method=name,violations=v,seconds=secs,budget_s=budget,reads=reads,assignment=fn))
        print('FOCUSED HELDOUT',n,inst,flush=True)
with (D/'focused_heldout.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
s=[]
for n,_,_,_ in PLANS:
    for name in METHODS:
        a=[r for r in rows if r['n']==n and r['method']==name]
        s.append(dict(n=n,method=name,trials=len(a),median=float(np.median([r['violations'] for r in a])),mean=float(np.mean([r['violations'] for r in a])),solved=sum(r['violations']==0 for r in a),median_sec=float(np.median([r['seconds'] for r in a])),median_reads=float(np.median([r['reads'] for r in a]))))
        print('F-SUMMARY',s[-1],flush=True)
with (D/'focused_heldout_summary.json').open('w') as f:json.dump(dict(summary=s,plans=PLANS,platform=platform.platform(),numpy=np.__version__,seed_disclosure='fresh 1061280/1062560/1065120+; zero overlap with calibration'),f,indent=2)
