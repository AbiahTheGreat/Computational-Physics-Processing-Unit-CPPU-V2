# plunder_allinone_buster.py
"""
All-in-one hardest test driver for plunder_stability_buster.py
- Generates two nasty problems: Random 3-SAT at phase transition and a large SK spin glass.
- Converts 3-SAT -> QUBO -> Ising (J,h) with ancilla penalties (using pyqubo).
- Saves J/h to .npy
- Runs plunder_stability_buster.py via subprocess with aggressive flags and hardware-aware throttling.
- Collects results, loads outputs, makes a short diagnostic plot and summary.
- Defaults are aggressively 'hard'. Use --safe to tone down.
"""

import os, sys, argparse, subprocess, time, json, math
import numpy as np
import random
from pathlib import Path

# try imports that may be optional
try:
    from pyqubo import Array, Binary
except Exception as e:
    print("pyqubo import failed. Please pip install pyqubo dimod")
    raise

try:
    import pynvml
    pynvml.nvmlInit()
    NVML_OK = True
except Exception:
    NVML_OK = False

import psutil
import matplotlib.pyplot as plt

# -------------------------
# Utilities: temp probes
# -------------------------
def get_gpu_temp():
    if not NVML_OK:
        return None
    try:
        h = pynvml.nvmlDeviceGetHandleByIndex(0)
        t = pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU)
        return float(t)
    except Exception:
        return None

def get_cpu_temp():
    # use psutil sensors if available; fallback None
    try:
        temps = psutil.sensors_temperatures()
        if not temps:
            return None
        # pick the first sensor with values
        for k, vals in temps.items():
            if vals:
                # return the first current temperature available
                return float(vals[0].current)
    except Exception:
        pass
    return None

# -------------------------
# 3-SAT generator + QUBO builder (pyqubo gadget)
# -------------------------
def random_3sat(n, alpha=4.267, seed=12345):
    random.seed(seed)
    m = int(round(alpha * n))
    clauses = []
    for _ in range(m):
        vars_ = random.sample(range(n), 3)
        lits = []
        for v in vars_:
            if random.random() < 0.5:
                lits.append(('pos', v))
            else:
                lits.append(('neg', v))
        clauses.append(lits)
    return clauses

def build_qubo_from_clauses(n, clauses, A=10.0):
    # x variables
    x = Array.create('x', shape=n, vartype='BINARY')
    zs = [Binary(f"z_{i}") for i in range(len(clauses))]
    H = 0
    for i, clause in enumerate(clauses):
        # val: positive -> x[v], negative -> 1 - x[v]
        a = clause
        val0 = x[a[0][1]] if a[0][0]=='pos' else (1 - x[a[0][1]])
        val1 = x[a[1][1]] if a[1][0]=='pos' else (1 - x[a[1][1]])
        val2 = x[a[2][1]] if a[2][0]=='pos' else (1 - x[a[2][1]])
        U = (1 - val0) * (1 - val1) * (1 - val2)   # unsat indicator
        z = zs[i]
        H += A * (z - U) ** 2
    model = H.compile()
    bqm = model.to_bqm()  # dimod BQM
    # build Q (numpy) consistent with bqm variables order
    variables = list(bqm.variables)
    idx = {v:i for i,v in enumerate(variables)}
    N = len(variables)
    Q = np.zeros((N, N))
    # linear
    for v, bias in bqm.linear.items():
        Q[idx[v], idx[v]] += bias
    # quadratic
    for (u,v), bias in bqm.quadratic.items():
        # bqm.quadratic gives each pair once
        Q[idx[u], idx[v]] += bias
        Q[idx[v], idx[u]] += bias
    return Q, variables

# -------------------------
# QUBO -> Ising conversion
# -------------------------
def qubo_to_ising(Q):
    # Q is NxN with quadratic and linear on diagonal
    N = Q.shape[0]
    # We'll compute equivalent Ising J,h such that for s in {-1,+1}, E(s) = s^T J s + h^T s + const
    # Using x = (1 + s)/2. E_Q(x) = x^T Q x
    # Expand and collect s_i s_j and s_i terms.
    J = np.zeros((N,N))
    h = np.zeros(N)
    const = 0.0
    for i in range(N):
        const += 0.25 * Q[i,i]  # because x_i^2 = x_i = (1+s_i)/2 contributes
        h[i] += 0.5 * Q[i,i]
    # Off-diagonals:
    for i in range(N):
        for j in range(i+1, N):
            q = Q[i,j]
            # contribution: q * x_i x_j = q * (1+s_i)(1+s_j)/4
            # = q/4 * s_i s_j + q/4 * s_i + q/4 * s_j + q/4
            J[i,j] += q / 4.0
            J[j,i] += q / 4.0
            h[i] += q / 4.0
            h[j] += q / 4.0
            const += q / 4.0
    # Convert to the standard Ising energy sign convention used by your solver:
    # Many solvers use E = - sum_{i<j} J_ij s_i s_j - sum_i h_i s_i
    # But earlier in this project we used E = s^T J s + h^T s. We'll keep J,h as produced and let your solver's conventions handle it.
    return J, h, const

# -------------------------
# SK generator
# -------------------------
def gen_SK(N, seed=12345, gaussian=True):
    rng = np.random.RandomState(seed)
    if gaussian:
        J = rng.normal(0.0, 1.0/np.sqrt(N), size=(N,N))
    else:
        J = rng.choice([1.0, -1.0], size=(N,N)) / np.sqrt(N)
    J = np.triu(J,1)
    J = J + J.T
    np.fill_diagonal(J, 0.0)
    return J

# -------------------------
# Launcher for plunder solver (subprocess wrapper)
# -------------------------
def call_plunder(j_path, h_path=None, prefix="plunder_auto", cfg=None):
    # cfg: dict of flags
    base_cmd = [sys.executable, "plunder_stability_buster.py"]
    if j_path is not None:
        base_cmd += ["--load_J", str(j_path)]
    if h_path is not None:
        base_cmd += ["--load_h", str(h_path)]
    # choose device
    device = cfg.get("device", "auto")
    base_cmd += ["--device", device]
    # core aggressive flags
    for k,v in cfg.items():
        if k in ["device"]:
            continue
        if isinstance(v, bool):
            if v:
                base_cmd.append(f"--{k}")
        else:
            base_cmd += [f"--{k}", str(v)]
    # always set save prefix
    base_cmd += ["--save_prefix", prefix]
    print("Running plunder with command:")
    print(" ".join(base_cmd))
    # run and stream output
    proc = subprocess.Popen(base_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, bufsize=1)
    # stream lines and simple temp-monitoring
    try:
        while True:
            line = proc.stdout.readline()
            if not line and proc.poll() is not None:
                break
            if line:
                print(line, end="")
            # sample temperatures and throttle printed every second
            # (Note: throttling of plunder is left to its flags like --auto_throttle; here we just monitor)
    except KeyboardInterrupt:
        print("User abort: terminating child process...")
        proc.terminate()
    rv = proc.wait()
    return rv

# -------------------------
# Postprocessing quick diagnostics
# -------------------------
def summarize_outputs(prefix, out_dir="plunder_outputs"):
    # plunder likely wrote files like {prefix}_results.json, {prefix}_best_assignment.txt
    j = {}
    outdir = Path(out_dir)
    resfile = outdir / f"{prefix}_results.json"
    if resfile.exists():
        data = json.load(open(resfile, "r"))
        j['results'] = data
    else:
        print("No results JSON found at", resfile)
    best_assign = outdir / f"{prefix}_best_assignment.txt"
    if best_assign.exists():
        j['best_assignment'] = best_assign.read_text()
    return j

# -------------------------
# Main driver
# -------------------------
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--which", choices=["both","3sat","sk"], default="both", help="which tests to run")
    p.add_argument("--safe", action="store_true", help="use toned-down settings (useful for laptops)")
    p.add_argument("--really_hard", action="store_true", help="push extremely hard (huge N/agents/steps) - WARNING")
    p.add_argument("--seed", type=int, default=12345)
    p.add_argument("--outdir", default="plunder_inputs")
    args = p.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    # hardware info
    gpu_temp = get_gpu_temp()
    cpu_temp = get_cpu_temp()
    print("Detected temps - GPU:", gpu_temp, "CPU:", cpu_temp)
    torch_device="auto"
    # Choose safe defaults based on flags
    if args.safe:
        SAT_n = 120
        SK_N = 400
        agents = 64
        steps = 80000
    elif args.really_hard:
        SAT_n = 900
        SK_N = 2000
        agents = 512
        steps = 400000
    else:
        # default hard but reasonable
        SAT_n = 400
        SK_N = 1000
        agents = 256
        steps = 200000

    # If no GPU present, scale down a bit to avoid huge CPU time/memory
    try:
        import torch
        cuda_ok = torch.cuda.is_available()
        print("Torch cuda available:", cuda_ok, "torch version:", torch.__version__)
    except Exception:
        cuda_ok = False
    if not cuda_ok:
        print("CUDA not available: reducing default parallelism to be CPU-friendly")
        agents = max(32, agents // 4)
        steps = max(40000, steps // 4)
        torch_device = "cpu"
    else:
        torch_device = "cuda"

    # ---------------
    # Generate 3-SAT -> QUBO -> Ising
    # ---------------
    if args.which in ("both","3sat"):
        print("Generating random 3-SAT (phase transition) n=", SAT_n)
        clauses = random_3sat(SAT_n, alpha=4.267, seed=args.seed)
        print("Num clauses:", len(clauses))
        print("Building QUBO (this may take memory/time)...")
        Q, vars_list = build_qubo_from_clauses(SAT_n, clauses, A=12.0)
        qpath = outdir / "hard_3sat_Q.npy"
        np.save(qpath, Q)
        print("Saved QUBO:", qpath, "shape:", Q.shape)
        print("Converting QUBO -> Ising (J,h)...")
        J, h, const = qubo_to_ising(Q)
        Jpath = outdir / "hard_3sat_J.npy"
        hpath = outdir / "hard_3sat_h.npy"
        np.save(Jpath, J); np.save(hpath, h)
        print("Saved J,h:", Jpath, hpath, "const:", const)

        # run plunder on 3-SAT instance
        prefix = f"plunder_hard_3sat_seed{args.seed}"
        cfg = {
            "agents": agents,
            "steps": steps,
            "dt": 0.001,
            "D0": 0.05,
            "mem_size": 800,
            "mem_inject_every": 500,
            "mem_blend": 0.3,
            "device": torch_device,
            "auto_throttle": True,
            "use_sys_temp": True,
            "use_sys_time": True,
            "mixed_precision": True if cuda_ok else False,
            "hard": True,
            "log_every": 250
        }
        print("Calling plunder on 3-SAT. This will take a while.")
        rv = call_plunder(str(Jpath), str(hpath), prefix=prefix, cfg=cfg)
        print("plunder exited with code", rv)

        # Collect and summarize outputs
        summ = summarize_outputs(prefix)
        print("Summary for 3-SAT run:", list(summ.keys()))

    # ---------------
    # Generate and run SK
    # ---------------
    if args.which in ("both","sk"):
        print("Generating SK model N=", SK_N)
        Jsk = gen_SK(SK_N, seed=args.seed, gaussian=True)
        Jsk_path = outdir / "hard_SK_J.npy"
        np.save(Jsk_path, Jsk)
        print("Saved SK J:", Jsk_path, "shape:", Jsk.shape)

        prefix = f"plunder_hard_SK_N{SK_N}_seed{args.seed}"
        cfg = {
            "agents": agents,
            "steps": steps,
            "dt": 0.001,
            "D0": 0.05,
            "mem_size": 800,
            "mem_inject_every": 500,
            "mem_blend": 0.3,
            "device": torch_device,
            "auto_throttle": True,
            "use_sys_temp": True,
            "use_sys_time": True,
            "mixed_precision": True if cuda_ok else False,
            "hard": True,
            "log_every": 250
        }
        print("Calling plunder on SK. This will take a while.")
        rv = call_plunder(str(Jsk_path), None, prefix=prefix, cfg=cfg)
        print("plunder exited with code", rv)
        summ = summarize_outputs(prefix)
        print("Summary for SK run:", list(summ.keys()))

    print("All tasks attempted. Check plunder_outputs/ for result files and saved plots.")
    print("If you want PNG diagnostics, rerun me with --safe if your machine struggled.")
    return

if __name__ == "__main__":
    main()
