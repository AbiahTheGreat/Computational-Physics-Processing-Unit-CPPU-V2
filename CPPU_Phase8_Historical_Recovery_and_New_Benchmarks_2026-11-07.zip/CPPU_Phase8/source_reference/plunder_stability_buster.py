#!/usr/bin/env python3
import argparse, time, json, os, math
import numpy as np
import torch
from tqdm import tqdm

# -------------------------
# Optional temperature probes
# -------------------------
try:
    import pynvml
    pynvml.nvmlInit()
    NVML_AVAILABLE = True
except:
    NVML_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except:
    PSUTIL_AVAILABLE = False


# -------------------------
# Temperature helpers
# -------------------------
def get_gpu_temp():
    if not NVML_AVAILABLE:
        return None
    try:
        h = pynvml.nvmlDeviceGetHandleByIndex(0)
        return float(pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU))
    except:
        return None


def get_cpu_temp():
    if not PSUTIL_AVAILABLE:
        return None
    try:
        temps = psutil.sensors_temperatures()
        for name, entries in temps.items():
            for e in entries:
                if "cpu" in e.label.lower() or "core" in e.label.lower():
                    return float(e.current)
        # fallback: pick first numeric entry
        for _, entries in temps.items():
            for e in entries:
                return float(e.current)
    except:
        return None
    return None


# -------------------------
# Hypersphere projection
# -------------------------
def project_hypersphere(x):
    """Project each row vector onto unit hypersphere."""
    if x.dim() == 1:
        nrm = x.norm()
        return x / max(nrm, 1e-12)
    nrm = x.norm(dim=1, keepdim=True).clamp_min(1e-12)
    return x / nrm


# -------------------------
# Ising energies
# -------------------------
def cont_energy_per_agent(x, J, h):
    # E = -½ x J x + h x   (continuous)
    quad = torch.einsum("bi,ij,bj->b", x, J, x)
    lin = torch.einsum("bi,i->b", x, h)
    return -0.5 * quad + lin


def discrete_energy(s, J, h):
    # s ∈ {−1,+1}^n
    s = s.float()
    return float(-0.5 * s @ J @ s + h @ s)


def extract_discrete(x):
    return torch.sign(x).clamp(min=-1, max=1)


# -------------------------
# Engine
# -------------------------
def run_engine(cfg):

    device = torch.device("cuda" if (cfg.device == "cuda" and torch.cuda.is_available()) else "cpu")

    # Load model
    J = torch.tensor(np.load(cfg.load_J), dtype=torch.float32, device=device)
    if cfg.load_h is None:
        h = torch.zeros(J.shape[0], dtype=torch.float32, device=device)
    else:
        h = torch.tensor(np.load(cfg.load_h), dtype=torch.float32, device=device)

    n = J.shape[0]
    agents = cfg.agents

    # Mixed precision?
    use_amp = cfg.mixed_precision and device.type == "cuda"

    # Initialize continuous states
    x = torch.randn(agents, n, device=device)
    x = project_hypersphere(x)

    v = torch.zeros_like(x)  # momentum term

    # Memory bank
    mem_bank = []
    mem_ptr = 0

    best_discrete_E = float("inf")
    best_assign = None

    # optional auto-throttle
    last_temp_check = time.time()

    # main loop
    for step in tqdm(range(cfg.steps)):

        # ---------------------------------
        # External modulation: time & temp
        # ---------------------------------
        ext_factor = 1.0
        if cfg.use_sys_time:
            ext_factor *= (1.0 + 0.1 * math.sin(time.time()))

        if cfg.use_sys_temp:
            now = time.time()
            if now - last_temp_check > 0.25:
                last_temp_check = now
                gpu_t = get_gpu_temp()
                cpu_t = get_cpu_temp()
                highest = None
                if gpu_t: highest = gpu_t
                if cpu_t: highest = max(highest or cpu_t, cpu_t)
                if highest and highest > 85 and cfg.auto_throttle:
                    ext_factor *= 0.5  # slow diffusion
        # ---------------------------------

        D = cfg.D0 * ext_factor

        # Gradient: −Jx + h
        with torch.cuda.amp.autocast(enabled=use_amp):
            grad = -(x @ J) + h

        # diffusive noise
        z = torch.randn_like(x)

        # update rule
        v = cfg.momentum * v - cfg.dt * grad
        x = x + v + math.sqrt(2.0 * D * cfg.dt) * z

        # project
        x = project_hypersphere(x)

        # memory injection
        if len(mem_bank) > 0 and step % cfg.mem_inject_every == 0:
            idx = np.random.randint(len(mem_bank))
            mem_vec = mem_bank[idx].to(device)
            x = (1 - cfg.mem_blend) * x + cfg.mem_blend * mem_vec
            x = project_hypersphere(x)

        # store new memories
        if step % 250 == 0:
            with torch.no_grad():
                ce = cont_energy_per_agent(x, J, h)
                best_agent = torch.argmin(ce)
                mem_bank.append(x[best_agent].detach().cpu())
                if len(mem_bank) > cfg.mem_size:
                    mem_bank.pop(0)

                # update best discrete
                s = extract_discrete(x[best_agent])
                E = discrete_energy(s, J, h)
                if E < best_discrete_E:
                    best_discrete_E = E
                    best_assign = s.cpu().numpy()

        # periodic logging
        if step % cfg.log_every == 0:
            with torch.no_grad():
                ce = cont_energy_per_agent(x, J, h)
                print(f"[step {step:6d}] best_binE={best_discrete_E:.5f} contE_mean={ce.mean().item():.5f}")

    # save results
    os.makedirs("plunder_outputs", exist_ok=True)
    prefix = cfg.save_prefix
    np.save(f"plunder_outputs/{prefix}_best_assignment.npy", best_assign)

    with open(f"plunder_outputs/{prefix}_results.json", "w") as f:
        json.dump({
            "best_energy": best_discrete_E,
            "best_assignment_file": f"{prefix}_best_assignment.npy",
            "steps": cfg.steps,
            "agents": cfg.agents,
            "n": n
        }, f, indent=2)

    return {
        "best_energy": best_discrete_E,
        "best_assignment": best_assign
    }


# -------------------------
# CLI
# -------------------------
def build_arg_parser():
    p = argparse.ArgumentParser()
    p.add_argument("--load_J", required=True)
    p.add_argument("--load_h", default=None)
    p.add_argument("--agents", type=int, default=32)
    p.add_argument("--steps", type=int, default=20000)
    p.add_argument("--dt", type=float, default=0.002)
    p.add_argument("--D0", type=float, default=0.03)
    p.add_argument("--momentum", type=float, default=0.90)
    p.add_argument("--mem_size", type=int, default=200)
    p.add_argument("--mem_inject_every", type=int, default=500)
    p.add_argument("--mem_blend", type=float, default=0.2)
    p.add_argument("--log_every", type=int, default=250)
    p.add_argument("--mixed_precision", action="store_true")
    p.add_argument("--use_sys_time", action="store_true")
    p.add_argument("--use_sys_temp", action="store_true")
    p.add_argument("--auto_throttle", action="store_true")
    p.add_argument("--save_prefix", type=str, default="plunder_solver_output")
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--seed", type=int, default=12345)
    return p


def main():
    parser = build_arg_parser()
    cfg = parser.parse_args()
    print("Config:", cfg)

    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)

    run_engine(cfg)


if __name__ == "__main__":
    main()
