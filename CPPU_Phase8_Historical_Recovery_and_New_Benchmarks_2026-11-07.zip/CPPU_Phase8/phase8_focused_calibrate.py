import sys, csv, time, pathlib, numpy as np

from phase8_direct_sat import occurrence_table,count_unsat
from phase8_focused_memory import focused_memory
from phase8_baselines import fast_walksat,probsat
from phase8_cases import generate_clauses
rows=[]; D=pathlib.Path(__file__).resolve().parent
C=generate_clauses(16,68,11111);O,P,CT=occurrence_table(C,16)
for fn in [lambda:focused_memory(C,O,P,CT,1,100),lambda:fast_walksat(C,O,P,CT,1,100),lambda:probsat(C,O,P,CT,1,100)]:fn()
settings=[('focused0',4,0,0.15),('focusedw2',2,1,0.15),('focusedw4',4,1,0.15),('focusedw8',8,1,0.15),('focusedw4_noisy',4,1,1.4),('focusedw8_noisy',8,1,1.4),('walksat',0,0,0),('probsat',0,0,0)]
for n in (128,256):
 for j in range(5):
  instance=670000+n*1000+j
  C=generate_clauses(n,round(4.27*n),instance);O,P,CT=occurrence_table(C,n)
  for rep in range(2):
   seed=instance*11+rep*10007
   for name,tn,weight,no in settings:
    t=time.perf_counter()
    if name=='walksat':b,v=fast_walksat(C,O,P,CT,seed,3500)
    elif name=='probsat':b,v=probsat(C,O,P,CT,seed,3500)
    else:b,v=focused_memory(C,O,P,CT,seed,3500,tn,weight,1,no)
    dt=time.perf_counter()-t
    assert v==count_unsat(C,b)
    rows.append(dict(n=n,instance=instance,rep=rep,method=name,violations=v,seconds=dt))
  print('FCAL',n,instance,flush=True)
with (D/'focused_calibration.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
for n in (128,256):
 for name,tn,weight,no in settings:
  a=[r for r in rows if r['n']==n and r['method']==name]
  print('SUMMARY',n,name,'mean',round(np.mean([r['violations'] for r in a]),2),'med',np.median([r['violations'] for r in a]),'runtime',round(np.median([r['seconds'] for r in a]),4))
