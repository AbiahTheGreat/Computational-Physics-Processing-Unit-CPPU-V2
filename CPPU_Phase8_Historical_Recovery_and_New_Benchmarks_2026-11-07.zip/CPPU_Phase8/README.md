# CPPU Phase 8: reproducible November 7, 2026 research

**Read `CPPU_Phase8_Research_Report_2026-11-07.md` first.** This ZIP preserves a standalone copy of the source, fresh problem seeds, saved solutions, the original Plunder source, one archived SK matrix, and independent auditing code.

**Main finding:** A newly implemented *classical* focused MAX-3SAT solver with short-term tabu memory and dynamic clause weights produced a modest quality advantage on one locked 512-variable synthetic confirmation set against two separately implemented SAT heuristics. **This is not the original CPPU optimizer.** The modified Phase 7 solver continues to give good local spin-glass results. Actual official Neal, official D-Wave Tabu and MIPLIB benchmarks are not executed in this package.

## Files

- `phase8_direct_sat.py`: original Phase 8 full variable-scan experimental direct-constraint solver.
- `phase8_focused_memory.py`: improved, focused, faster Phase 8 classical solver.
- `phase8_baselines.py`: separately written WalkSAT-style and ProbSAT-style local controls.
- `phase8_cases.py`: deterministic SAT and QUBO/Ising instance creation.
- `phase7_core_optimized.py`, `phase6_core.py`: preserved previous Numba source for spin-glass continuation.
- `phase8_*calibrate.py`, `phase8_*heldout.py`, `phase8_confirm.py`, `phase8_sk_check.py`: complete experiment scripts, including random seeds.
- `*.csv`, `*_summary.json`, `phase8_*.png`: results and plots.
- `heldout_assignments/`, `focused_assignments/`, `confirm_assignments/`, `sk_assignments_light/`: saved best trial states.
- `source_reference/plunder_allinone_final.py` plus original variants and `SK_J.npy`: archived original research sources; source file untouched.
- `phase8_audit.py`, `AUDIT_RESULTS.json`: independent reassessment of 940 saved assignments.
- `phase8_official_dwave_runner.py`: official D-Wave test preparation, not executed in current sandbox.

## Verify the saved work

From the unzipped directory:

```
python -m pip install numpy numba
python phase8_audit.py
python phase8_official_dwave_runner.py --preflight
```

If running from Windows 10 Python 3.10, prefix each command with `py -3.10` instead of `python`.

## Official D-Wave cloud runner (not executed yet)

The experimental workflow file is `phase8_official_dwave_workflow.yml`. To use GitHub Actions, copy it into your repository under **`.github/workflows/phase8_official_dwave_workflow.yml`**, and copy the top-level `.py` files plus the `source_reference/` directory into the repository root. Then use **GitHub → Actions → CPPU Phase 8 vs D-Wave Neal and Tabu → Run workflow**. It installs the real D-Wave package and publishes a results artifact. A GitHub account with permissions is required; merely downloading the ZIP does **not** launch an official test.

The workflow also appears in this ZIP under `.github/workflows/` for convenience. The GitHub execution has NOT been run or verified here. It should be treated as a prepared external test rather than results.

## Controls and limitations

The new SAT solver is a conventional local-search design. It has **not** been established to outperform the published state of the art, industrial MaxSAT solvers, the official D-Wave implementations, or every SAT distribution. Timings are CPU host-specific and include full-run overshoots. For a scientific submission, use preregistered benchmarks and compare with a tuned external MAX-SAT implementation and official Neal.
