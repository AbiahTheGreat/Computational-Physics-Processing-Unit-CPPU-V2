"""Pre-registered held-out comparison, no external data/test set tuning after running.
Calibration: 64/128 (seeds 774001.. / 838001..) and 256 (889001..).
Held-out seeds are completely distinct: 996400+, 991280+, 992560+.
Equal *nominal* wall-time budget, complete-run overshoot measured. CPU timings approximate.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import sys,csv,time,pathlib,json,platform,hashlib
import numpy as np
from phase8_direct_sat import solve,occurrence_table,count_unsat
from phase8_baselines import fast_walksat,probsat
from phase8_cases import generate_clauses
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'heldout_assignments';OUT.mkdir(exist_ok=True)
METHODS=['direct_no_memory','direct_tabu','direct_weighted_memory','focused_walksat','focused_probsat']
PLANS=[(64,8,0.004,996400),(128,12,0.020,991280),(256,12,0.045,992560)]
ROWS=[]

def independent_score(clauses,bits):
    # Vectorized independent path does not call JIT's rolling counter.
    z=np.asarray(bits,dtype=np.int64)
    L=clauses
    is_true=(z[np.abs(L)-1] == (L>0).astype(np.int64))
    return int(np.count_nonzero(~np.any(is_true,axis=1)))

def run_method(name,C,O,P,cnt,seed,budget,n):
    t0=time.perf_counter();best=10**9;bestb=None;nr=0;raw_secs=[]
    # Entire fixed-size run always counted; after at least one run, stop once elapsed budget.
    while nr==0 or time.perf_counter()-t0<budget:
        sd=seed+nr*1901
        tt=time.perf_counter()
        if name=='direct_no_memory':b,v=solve(C,O,P,cnt,sd,3500,0,0,1)
        elif name=='direct_tabu':b,v=solve(C,O,P,cnt,sd,3500,4,0,1)
        elif name=='direct_weighted_memory':b,v=solve(C,O,P,cnt,sd,3500,4,1,1)
        elif name=='focused_walksat':b,v=fast_walksat(C,O,P,cnt,sd,3500,0.38)
        else:b,v=probsat(C,O,P,cnt,sd,3500,2.3)
        raw_secs.append(time.perf_counter()-tt)
        verified=independent_score(C,b)
        if v!=verified:raise AssertionError(f'Mismatch {name} reported {v}, independently {verified}')
        if verified<best:
            best=verified;bestb=b.copy()
        nr+=1
        if best==0:break
    return bestb,best,time.perf_counter()-t0,nr,raw_secs

# Warmup JIT using material with disjoint seeds
C=generate_clauses(32,round(4.27*32),102);O,P,CNT=occurrence_table(C,32)
for m in METHODS:run_method(m,C,O,P,CNT,301,0.001,32)
for n,ninstances,budget,prefix in PLANS:
    for j in range(ninstances):
        inst=prefix+j
        C=generate_clauses(n,round(4.27*n),inst)
        O,P,CNT=occurrence_table(C,n)
        clause_hash=hashlib.sha256(C.tobytes()).hexdigest()
        for rep in range(2):
            seed=int(inst*101+rep*9083)
            # Rotate order, reducing bias from host drift (not a substitute for pinning CPU).
            ordered=METHODS[(j+rep)%len(METHODS):]+METHODS[:(j+rep)%len(METHODS)]
            for name in ordered:
                b,v,dt,nr,dt_runs=run_method(name,C,O,P,CNT,seed,budget,n)
                save=OUT/f'{n}_{inst}_{rep}_{name}.npz'
                np.savez_compressed(save,clauses=C,bits=b,violations=v)
                ROWS.append(dict(n=n,instance=inst,rep=rep,seed=seed,method=name,violations=v,seconds=dt,
                                 budget_s=budget,full_runs=nr,sha256_clauses=clause_hash,assignment_file=save.name))
        print('HELDOUT',n,inst,'complete',flush=True)
with (ROOT/'heldout.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(ROWS[0]));w.writeheader();w.writerows(ROWS)
summary=[]
for n,_,_,_ in PLANS:
    for method in METHODS:
        aa=[r for r in ROWS if r['n']==n and r['method']==method]
        summary.append(dict(n=n,method=method,ntrials=len(aa),median_violations=float(np.median([r['violations'] for r in aa])),
                            mean_violations=float(np.mean([r['violations'] for r in aa])),solved=sum(r['violations']==0 for r in aa),
                            median_seconds=float(np.median([r['seconds'] for r in aa])),median_restarts=float(np.median([r['full_runs'] for r in aa]))))
for r in summary:print('SUMMARY',r,flush=True)
meta=dict(plans=PLANS,calibration_seeds='774001...; 838001...; 889001...',
          methods=METHODS,python=platform.python_version(),numpy=np.__version__,machine=platform.platform(),
          scoring='Original 3-literal clauses; no ancilla or QUBO conversion in Phase8 direct solvers',
          caveat='Wall-time budget is nominal, complete runs overshoot. No official Neal, no industrial solver.')
(ROOT/'heldout_summary.json').write_text(json.dumps(dict(summary=summary,meta=meta),indent=2))
