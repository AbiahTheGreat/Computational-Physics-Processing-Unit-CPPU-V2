"""Independent audit: re-score every assignment, verify matrices and gadget conversion,
bootstrap over instances (not pseudoreplicated trials), and confirm source checksums.
"""
from __future__ import annotations
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import csv,json,hashlib,pathlib,itertools
import numpy as np
from phase8_cases import generate_clauses,qubo_to_cppu_correct,sat_to_symmetric_Q
D=pathlib.Path(__file__).parent

def sat_literal_independent(clauses,b):
    nbad=0
    for clause in clauses:
        ok=False
        for val in clause:
            i=abs(int(val))-1
            if (val>0 and b[i]==1) or (val<0 and b[i]==0):ok=True
        if not ok:nbad+=1
    return nbad

def readcsv(name):
    with (D/name).open(newline='') as f:return list(csv.DictReader(f))

report={'assignment_sets':{},'errors':[],'checks':{}}
for csv_name,folder in [('heldout.csv','heldout_assignments'),('focused_heldout.csv','focused_assignments'),('confirm.csv','confirm_assignments')]:
    rows=readcsv(csv_name);checked=0;bad=0;instancehash={}
    for row in rows:
        fname=row.get('assignment_file') or row.get('assignment')
        with np.load(D/folder/fname) as a:
            C=a['clauses'];b=a['bits'];v=int(a['violations'])
        assert C.dtype.kind in 'iu' and b.dtype.kind in 'iu'
        n=int(row['n']) if row.get('n') else 512
        if len(b)!=n or int(C.shape[1])!=3:raise AssertionError(('shape',fname))
        if np.any(np.abs(C)>n) or np.any(np.abs(C)<1):raise AssertionError(('range',fname))
        if not np.isin(b,(0,1)).all():raise AssertionError(('not binary',fname))
        actual=sat_literal_independent(C,b)
        if actual!=v or actual!=int(row['violations']):raise AssertionError(('SAT score',fname,actual,v,row['violations']))
        inst=int(row['instance'])
        if inst not in instancehash:instancehash[inst]=hashlib.sha256(C.tobytes()).hexdigest()
        if instancehash[inst]!=hashlib.sha256(C.tobytes()).hexdigest():raise AssertionError(('not same instance',inst))
        # Rebuild each source formula from seeds, not just check saved score
        seed=inst
        expected=generate_clauses(n,len(C),seed)
        if not np.array_equal(C,expected):raise AssertionError(('generator mismatch',fname))
        checked+=1
    report['assignment_sets'][csv_name]={'checked':checked,'unique_instances':len(instancehash),'errors':bad}

skrows=readcsv('sk_continuation.csv')
with open(D/'source_reference'/'SK_J.npy','rb') as f:
    archived_bytes=f.read()
import io
archiveJ=np.load(io.BytesIO(archived_bytes))
for row in skrows:
    n=int(row['n']);inst=int(row['instance']);rep=int(row['rep']);method=row['method']
    f=D/'sk_assignments_light'/f'{inst}_{rep}_{method}.npz'
    with np.load(f) as data:
        b=data['spins'];e=float(data['energy'])
    if inst==999999:J=archiveJ
    else:
        rng=np.random.default_rng(inst);a=np.triu(rng.normal(0,1/np.sqrt(n),size=(n,n)),1);J=a+a.T
    if len(b)!=n or not np.isin(b,(-1.,1.)).all():raise AssertionError(('SK spins',f))
    calc=-float(b@(J@b))
    if abs(calc-e)>1e-5 or abs(calc-float(row['energy']))>1e-5:raise AssertionError(('SK score',f,calc,e))
report['assignment_sets']['sk_continuation.csv']={'checked':len(skrows),'unique_instances':9,'errors':0}

source_sha=hashlib.sha256((D/'source_reference'/'plunder_allinone_final.py').read_bytes()).hexdigest()
sk_sha=hashlib.sha256(archived_bytes).hexdigest()
assert source_sha=='3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a'
assert sk_sha=='e9ff8b56fe147ccd68f8261d3ffeeefe5823dae1b49b5aed56e35e3e19deb165'
report['checks']['source_original_sha256']=source_sha
report['checks']['SK_archived_sha256']=sk_sha

# QUBO↔Ising equivalence across binary assignments and one-ancilla clause gadgets.
for clause in ((1,2,3),(-1,2,-3),(1,-2,-3),(-1,-2,-3)):
    C=np.array([clause],dtype=np.int32)
    Q,c=sat_to_symmetric_Q(C,3,penalty=2)
    J,h,k=qubo_to_cppu_correct(Q)
    for b3 in itertools.product([0,1],repeat=3):
        truth=sum((lit>0 and b3[abs(lit)-1]==1) or (lit<0 and b3[abs(lit)-1]==0) for lit in clause)
        target=int(truth==0)
        energies=[]
        for aux in (0,1):
            b=np.asarray((*b3,aux),dtype=float);s=2*b-1
            direct=float(b@Q@b+c)
            spun=-float(s@(J@s)+h@s)+c+k
            if abs(direct-spun)>1e-9:raise AssertionError(('QUBO->Ising mismatch',clause,b3,aux))
            energies.append(direct)
        if abs(min(energies)-target)>1e-9:raise AssertionError(('gadget wrong',clause,b3,energies))
report['checks']['QUBO_equivalent_energies']=4*8*2

# Exact Ising delta, all spins x n<=6 configurations, independent enumeration
rng=np.random.default_rng(334455);N=6;J=rng.normal(size=(N,N));J=(J+J.T)/2;np.fill_diagonal(J,0);h=rng.normal(size=N)
for b in itertools.product([-1.,1.],repeat=N):
    s=np.array(b,dtype=float);f=J@s;energy=-(s@(J@s)+h@s)
    for i in range(N):
        y=s.copy();y[i]=-y[i];calc=-(y@(J@y)+h@y)-energy
        formula=4*s[i]*f[i]+2*s[i]*h[i]
        if abs(calc-formula)>1e-9:raise AssertionError(('flip identity',i))
report['checks']['exact_flip_deltas']=64*6

# PRE-SPECIFIED final contrast: focused weighted vs locally implemented optimized ProbSAT on confirmation set.
rows=readcsv('confirm.csv')
G={}
for row in rows:
    key=(float(row['ratio']),int(row['instance']),int(row['rep']))
    G.setdefault(key,{})[row['method']]=int(row['violations'])
ratios=[4.1,4.27,4.5]
rng=np.random.default_rng(20261107)
for other in ('probsat_optimized','walksat_optimized','focused_tabu'):
    delta=np.array([[np.mean([G[(ratio,int(1080000+ii*1000+j),rep)][other]-G[(ratio,int(1080000+ii*1000+j),rep)]['focused_tabu_weights'] for rep in range(2)]) for j in range(10)] for ii,ratio in enumerate(ratios)])
    draws=np.mean(delta[np.arange(3)[:,None,None],rng.integers(0,10,size=(3,20000,10))],axis=(0,2))
    ci=np.quantile(draws,[0.025,0.975]);report['checks'][f'confirm_weighted_vs_{other}']={'mean_fewer_violations':float(delta.mean()),'ci95_instance_stratified':[float(x) for x in ci]}
report['checks']['total_assignments']=sum(v['checked'] for v in report['assignment_sets'].values())
(D/'AUDIT_RESULTS.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
