import pathlib,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=pathlib.Path(__file__).parent
rows=list(csv.DictReader((D/'confirm.csv').open()))
ratios=[4.1,4.27,4.5]
methods=['focused_tabu_weights','probsat_optimized','walksat_optimized']
labels=['Phase8 focused + memory + weights','Local ProbSAT-style control','Local WalkSAT-style control']
vals=np.array([[np.mean([float(r['violations']) for r in rows if abs(float(r['ratio'])-ratio)<1.e-8 and r['method']==method]) for method in methods] for ratio in ratios])
fig,ax=plt.subplots(figsize=(8.5,4.7));x=np.arange(len(ratios));w=.24
for i in range(3):ax.bar(x+(i-1)*w,vals[:,i],width=w,label=labels[i])
ax.set_xticks(x,labels=['4.10','4.27','4.50']);ax.set_xlabel('Clauses per variable, n=512');ax.set_ylabel('Mean unsatisfied clauses (lower is better)');ax.set_title('CPPU Phase 8: locked confirmation set (30 instances, 60 trials per method)');ax.legend(fontsize=8);fig.tight_layout();fig.savefig(D/'phase8_sat_confirmation.png',dpi=160);plt.close(fig)
rows=list(csv.DictReader((D/'sk_continuation.csv').open()))
methods=['phase7_memory','local_sa','random_quench']
med=np.array([np.median([float(r['energy']) for r in rows if int(r['n'])==1000 and r['method']==method]) for method in methods]);fig,ax=plt.subplots(figsize=(7.5,4.4))
ax.bar(['Phase7 memory','Local annealing','Random quench'],med);ax.set_ylabel('Median 1,000-spin energy (lower is better)');ax.set_title('Archived SK-1000 instance; 4 trials/method; ~0.06 s per trial')
for i,m in enumerate(med):ax.text(i,float(m)+15,f'{m:,.1f}',ha='center',fontsize=9)
ax.set_ylim(-1700,0);fig.tight_layout();fig.savefig(D/'phase8_SK1000_continuation.png',dpi=160);plt.close(fig)
print('Charts saved')
