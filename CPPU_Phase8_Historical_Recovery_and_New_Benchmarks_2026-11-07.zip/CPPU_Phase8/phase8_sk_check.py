"""Continuation check, not a new SK solver. Compare fast Phase7 refractory to local SA.
Include archived 1000-spin SK file plus independent 512-spin instances.
"""
import os
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import pathlib,sys,zipfile,io,csv,json,time,hashlib
import numpy as np

from phase7_core_optimized import refractory_ising
from phase6_core import sa_fixed,quench
D=pathlib.Path(__file__).parent;A=D/'sk_assignments';A.mkdir(exist_ok=True)
with open(D/'source_reference'/'SK_J.npy','rb') as f:
 original_bytes=f.read()
 archived=np.load(io.BytesIO(original_bytes))
print('ARCHIVED SK',archived.shape,'sym max',np.abs(archived-archived.T).max(),'diag max',np.abs(np.diag(archived)).max(),flush=True)
if not np.allclose(archived,archived.T,atol=1e-8):raise ValueError('Archived matrix not symmetric')
if not np.allclose(np.diag(archived),0,atol=1e-8):raise ValueError('Diagonal nonzero')
archived=archived.astype(np.float64)
# warm up
n=8;J=np.zeros((n,n));h=np.zeros(n);refractory_ising(J,h,1,30,13);sa_fixed(J,h,1,10);quench(J,h,np.ones(n))
rows=[]
for jj in range(9):
 if jj<8:
  n=512;inst=122000+jj;rng=np.random.default_rng(inst)
  a=np.triu(rng.normal(0,1/np.sqrt(n),size=(n,n)),1);J=a+a.T
 else:n=1000;inst=999999;J=archived
 h=np.zeros(n,dtype=np.float64)
 for rep in range(2 if jj<8 else 4):
  seed=inst*51+rep*991
  for method in ('phase7_memory','local_sa','random_quench'):
   best=1e30;bb=None;count=0;t=time.perf_counter()
   while count==0 or time.perf_counter()-t<0.060:
    st=seed+count*2303
    if method=='phase7_memory':b,e=refractory_ising(J,h,st,5000,17,0.)
    elif method=='local_sa':b,e=sa_fixed(J,h,st,45)
    else:
     rng2=np.random.default_rng(st);b=quench(J,h,rng2.choice(np.array([-1.,1.]),size=n))
    check=-float(b@(J@b)+h@b)
    assert abs(check-e)<1e-5 if method!='random_quench' else True
    if check<best:best=check;bb=b.copy()
    count+=1
   secs=time.perf_counter()-t
   path=A/f'{inst}_{rep}_{method}.npz';np.savez_compressed(path,J=J,h=h,spins=bb,energy=best)
   rows.append(dict(n=n,instance=inst,rep=rep,method=method,energy=best,seconds=secs,reads=count,source='archived' if n==1000 else 'fresh'))
 print('SK',n,inst,'done',flush=True)
with (D/'sk_continuation.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
for n in (512,1000):
 for method in ('phase7_memory','local_sa','random_quench'):
  a=[r for r in rows if r['n']==n and r['method']==method]
  print('SK-SUMMARY',n,method,'median',np.median([r['energy'] for r in a]),'median seconds',np.median([r['seconds'] for r in a]),flush=True)
(D/'sk_meta.json').write_text(json.dumps(dict(archived_SK_SHA256=hashlib.sha256(original_bytes).hexdigest(),no_neal=True),indent=2))
