import os
for s in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[s]='1'
import sys,time,csv,pathlib
import numpy as np
from phase8_direct_sat import solve,occurrence_table,count_unsat
from phase8_baselines import fast_walksat,probsat
from phase8_cases import generate_clauses
D=pathlib.Path(__file__).resolve().parent
METHODS=[('bare',0,0,1),('tabu4',4,0,1),('tabu8',8,0,1),('weights4',4,1,1),('weights8',8,1,1),('weights12',12,1,1),('weights8_noescape',8,1,0),('walksat',0,0,0),('probsat',0,0,0)]
rows=[]
# warm up
c=generate_clauses(16,68,2026);o,p,ct=occurrence_table(c,16)
for f in (lambda:solve(c,o,p,ct,1,100),lambda:fast_walksat(c,o,p,ct,1,100),lambda:probsat(c,o,p,ct,1,100)):f()
for n in (64,128):
 for j in range(5):
  instance=710001+1000*n+j
  c=generate_clauses(n,round(4.27*n),instance)
  o,p,ct=occurrence_table(c,n)
  for rep in range(2):
   seed=instance*7+rep*101
   for name,t,w,e in METHODS:
    t0=time.perf_counter()
    if name=='walksat':b,v=fast_walksat(c,o,p,ct,seed,3500)
    elif name=='probsat':b,v=probsat(c,o,p,ct,seed,3500)
    else:b,v=solve(c,o,p,ct,seed,3500,t,w,e)
    elapsed=time.perf_counter()-t0
    assert int(v)==int(count_unsat(c,b))
    rows.append(dict(n=n,instance=instance,rep=rep,method=name,violations=int(v),seconds=elapsed))
  print('CAL',n,instance,'done',flush=True)
with (D/'calibration.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for n in (64,128):
 for name,_,_,_ in METHODS:
  a=[r for r in rows if r['n']==n and r['method']==name]
  print(n,name,'median',np.median([r['violations'] for r in a]),'mean',round(np.mean([r['violations'] for r in a]),2),'time',round(np.median([r['seconds'] for r in a]),5),flush=True)
