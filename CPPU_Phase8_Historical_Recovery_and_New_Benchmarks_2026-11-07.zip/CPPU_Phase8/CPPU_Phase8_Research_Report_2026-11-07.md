# CPPU research, Phase 8: historical recovery, direct clause physics-inspired search, and independent validation

**Research date:** November 7, 2026  
**Classification:** CPU-executed, exploratory engineering benchmarks, with independently rescored assignments.  
**Critical distinction:** The strongest new SAT implementation is a **new classical local-search algorithm with tabu/refractory memory and clause-weight adaptation**. It is **not** a byte-preserved copy of Abiah Avila's original Plunder/CPPU and does not establish a new law of physics or a unique hardware advantage. **Official D-Wave Neal and MIPLIB tests have not run in this environment.**

## 1. What was checked from the post-December CPPU history

| Period | Retrieved change or result | Evidence status | Retain for optimization? |
|---|---|---|---|
| Jan–Feb 2026 | Original Plunder/stability programs: projected stochastic drift, adaptive diffusion, momentum in some variants, memory injection, multi-agent states; previous long-run SK/3-SAT output. | Source in `frozen.zip`; historical energies without adequately matched competitor runs. | Keep as original baseline, not a proved advantage. |
| February 2026 | CPPU physics integration into collision/pool simulations. | Interface/prototype work; no solver-quality advantage in retrieved numerical benchmarks. | Separate application, not evidence for SAT/Ising optimization. |
| August 2026 | Bend–Rotation added to Plunder. 30 matched-seed tests reportedly tied baseline (0 wins, 0 losses, 30 ties); a hardcoded seed bug was separately found. | Historical conversation result, not independently rerun in Phase 8. | No measured reason to adopt into discrete optimization. Retain the **seed-plumbing lesson**. |
| October–November 2026 | Pop/Shell/Thumper physics-inspired reasoning and physical-state bridge. | Some useful integration/control behavior; source-grounded Shell matched conventional relaxation in controlled tests. No unique optimizer improvement. | Ideas for other tasks, not a proven SAT accelerator. |
| Nov 7, Phases 3–5 | Corrected QUBO/Ising objective, gradient factor-of-two and sphere geometry; discrete corrections helped but conventional SA still ahead. | Previously executed tests; Phase 8 preserved the corrected encoding. | **Yes: independent objective verification and direct discrete scoring.** |
| Nov 7, Phases 6–7 | Temporary flip-memory/tabu-like dynamics and a zero-amplitude RNG fix; a memory ablation was decisive, 8.6–13.3x implementation speed improvements in Phase 7. | Reproducible prior files; Phase 8 carries forward the faster implementation for spin glass and the memory idea for SAT. | **Yes, strongest measured transferable engineering results.** |

**Original-source observation:** In the archived `plunder_allinone_final.py`, `get_cpu_temp()` simply returns `None`; the `--use_sys_temp` flag is parsed but not used by `run_plunder`. That specific source does **not** implement CPU-heat-driven optimization, regardless of the laptop's actual temperature. This does not rule out other experiments having injected temperatures into other scripts.

**Original-source reproduction:** SHA-256 of archived `plunder_allinone_final.py`: `3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a`. Archived SK input SHA-256: `e9ff8b56fe147ccd68f8261d3ffeeefe5823dae1b49b5aed56e35e3e19deb165`.

## 2. Phase 8 engineering design

The Phase 6/7 redesigned solver operated on an Ising objective. This can be a poor SAT interface, because each three-literal clause is represented using auxiliary variables and energy penalties. Phase 8 tests **direct MAX-3SAT clause violations** rather than working through ancillas:

`V(b) = number of clauses with all three literals false`, for binary bits `b`.

A first global variable-scan tabu search improved fixed-update scores, but the scan was computationally expensive. The later **focused** search chooses one currently unsatisfied clause, considers only its three variables, and uses the exact change in clause-violation count if a variable is flipped. The candidate flip is blocked briefly if recently used, except for improvements to the best known solution. An optional pressure mechanism raises the weights of persistently violated clauses, occasionally reduces accumulated weights, and independently records the **true unweighted best** solution. The focused solver also permits stochastic restarts from a verified best state after stagnation.

This is a combination of **established local-search ideas**. Temporary flip bans resemble tabu search; changing clause weights resembles dynamic-weight MAX-SAT heuristics; focusing on an unsatisfied clause is common in WalkSAT-family methods. The result is an engineering improvement, not evidence for unique original CPPU dynamics.

**Methods and scoring:** JIT-compiled single-thread CPU runs; every assignment independently rescored from the original literal clauses. Timers were measured after compilation. Each method got a nominal wall-time budget and could exceed it while completing a final fixed-size call. Some methods terminated early on zero violations. The primary comparisons are on the same problem instances and the same clock, but time equality is approximate rather than cycle-accurate.

## 3. Experimental sequence (selection and validation kept separate)

- **Calibration:** 64/128-variable cases; later 256-variable cases. Explored tabu tenure, unsatisfied-clause weighting, and focused versus global selection. The strongest global weighted design was not consistently faster than optimized specialized baselines.
- **First held-out global test:** 32 independent random MAX-3SAT cases at 64, 128 and 256 variables, two attempts per case for five methods (320 independently rescored assignments). On 256 variables, global weighting reduced median violations from 3.5 without memory to 2, but specialized controls reached median 1 in much less time.
- **Focused design calibration:** five independent instances each at 128 and 256 variables, two attempts each. Focused variable selection made a major efficiency difference. Selected fixed settings before further tests: tabu tenure 4; weighted variant uses 45-step unsatisfied-clause pressure updates; 3,500 attempted flips per call.
- **Focused held-out test:** 32 independent instances at 128/256/512 variables, two attempts each, five methods (320 saved assignments). Strong direct memory ablation; modest performance relative to specialty controls.
- **Separate confirmation:** 30 **new**, unvisited 512-variable instances, 10 per clause ratio 4.10, 4.27, 4.50, two attempts each, four methods (240 independently rescored assignments). No retuning on confirmation cases. Fixed wall-clock budget ~0.065 s per trial, with recorded overshoot.

## 4. Main held-out comparison: 512 variables

**Mean violated clauses, lower is better.** The final confirmation includes **60 attempts across 30 distinct instances per method**.

| Clause ratio | Focused + memory + weights | Focused + memory | Optimized local WalkSAT-style | Optimized local ProbSAT-style |
|---|---:|---:|---:|---:|
| 4.10 | **0.50** | 0.90 | 2.05 | 1.15 |
| 4.27 | **2.95** | 3.65 | 5.35 | 3.50 |
| 4.50 | 7.25 | **7.15** | 8.60 | 7.65 |

The fixed, weighted focused method averaged **0.533 fewer unsatisfied clauses per attempt than the locally implemented ProbSAT-style baseline**, with a **95% instance-stratified bootstrap interval of +0.183 to +0.933** (comparison minus new, positive favors the new method). The corresponding advantage over the locally implemented WalkSAT-style baseline was **1.767 fewer**, interval **+1.417 to +2.117**. Weighting itself improved over focused unweighted tabu by **0.333 fewer** on average, interval **+0.067 to +0.600**. These intervals resample 30 distinct instances within ratio strata, retaining both paired attempts per instance.

This is **measurable performance on these synthetic instances against these two local controls only**. It does **not** establish superiority over official ProbSAT/WalkSAT implementations, industrial MaxSAT, D-Wave Neal, D-Wave Tabu, or all Ising solvers. The ratio 4.50 stratum individually did not show a clear weighting advantage over unweighted focused tabu. Note that this was the selected final configuration after exploratory calibration, and the confidence intervals are descriptive, not multiplicity-adjusted discovery guarantees.

![Confirmation graph](phase8_sat_confirmation.png)

## 5. Direct test of memory

On the earlier, independently seeded focused held-out set, the unweighted focused search with **temporary flip-memory** versus no tenure (same budget) yielded:

| Variables | Mean violations: no tenure | Mean violations: tenure 4 | Mean reduction |
|---|---:|---:|---:|
| 128 | 1.083 | **0.167** | 0.917 |
| 256 | 3.375 | **0.917** | 2.458 |
| 512 | 8.813 | **4.313** | 4.500 |

In those paired trials, tenure 4 improved over zero tenure in 18/24, 23/24, and 16/16 attempts respectively; all remaining trials tied, none lost. This establishes the importance of short-term flip-memory **for this particular focused implementation**. It does not establish novelty of that established technique.

## 6. Continue testing the archived spin glass

The Phase 7 fast memory solver also remained strong under a new local, approximately time-matched control check:

| Input | Phase 7 memory median | Local SA median | Random greedy quench median |
|---|---:|---:|---:|
| 512-spin random SK (8 new instances, 2 repeats each) | **−767.245** | −737.014 | −731.153 |
| Archived 1,000-spin SK (one instance, four repeats) | **−1504.042** | −1442.089 | −1425.388 |

All are the same Ising energy definition, `E = −(sᵀJs + hᵀs)`, **lower better**, and all 60 final assignments were rescored against the actual matrix. This is a comparison with **locally implemented simulated annealing**, **not the official Neal binary**. One 1,000-spin input is not evidence of across-instance superiority. The new SAT solver and existing SK solver are two task-specific, classical methods, not a demonstrated universal unified processor.

![Archived SK test](phase8_SK1000_continuation.png)

## 7. Independent integrity audit

`phase8_audit.py` passed and wrote `AUDIT_RESULTS.json`:

- **940 independently rescored saved assignments**, zero discrepancies: 320 global held-out SAT, 320 focused held-out SAT, 240 512-variable confirmation SAT, 60 SK.
- Original source and archived SK input byte hashes matched the published local archive.
- Verified 64 small QUBO-to-Ising assignment energies, correct minima after ancilla optimization, and 384 exact Ising one-bit flip-energy identities.
- Confirmed every SAT assignment's clause matrix reconstructs bit-for-bit from its recorded seed, identical across competing solvers.
- Saved the 30-instance stratified bootstrap estimate, fixed seeds and repeated-trial grouping.

## 8. Next external milestone: actual D-Wave solvers

`phase8_official_dwave_runner.py --preflight` **executed locally** and passed exact QUBO/Ising tests. Its actual `--run` path has **not run**, because this environment cannot install `dwave-neal` / `dwave-samplers` from the internet. The provided GitHub Actions workflow installs **official D-Wave Neal**, **official D-Wave Tabu**, and the unchanged original CPPU source; then compares the original engine, Phase 7, and Phase 8 on specified SAT and SK cases with independent scoring. It fails closed if dependencies are missing; it does not fabricate an official result or quietly substitute a local simulated annealer.

Murray Thom's supplied reference: https://github.com/dwavesystems/dwave-neal. D-Wave's newer classical samplers: https://pypi.org/project/dwave-samplers/ . The company documents that this package implements both simulated annealing and tabu search. This benchmark is **not yet equivalent to MIPLIB**; direct clause-centric heuristics cannot solve general mixed-integer linear programs without new interfaces and constraint handling.

## 9. Interpretation and next research direction

The most useful historical improvements are now measurable: **proper energy/constraint modeling, temporary memory that prevents cycling, specialized representations, and avoiding needless computation**. CPPU's original continuous unit-sphere dynamics have not been demonstrated to cause the new performance gains. In the archived original source, CPU temperature is not an active feedback input, and the CLI config still hard-codes a seed. We retained source provenance and corrected seed handling in the external wrapper rather than rewriting the original code and calling it unchanged.

A credible claim to send Murray now is **that the independent numerical investigation found and corrected representation issues, and that an explicitly redesigned local-search solver performs competitively on our local synthetic SAT cases**. Do not assert that original CPPU beats Neal, has a novel physics advantage, or solved MIPLIB.

### Full reproduction

Unzip the release. From the extracted folder install `numpy`, `numba`, and `matplotlib` (plots optional). Run:

```
python phase8_audit.py
python phase8_official_dwave_runner.py --preflight
```

The archive includes complete solver source, original archived Plunder source, archived SK matrix, calibration and held-out CSVs, reproducibility scripts, output states and the **unexecuted** official D-Wave workflow. `README.md` explains the mobile/GitHub route.
