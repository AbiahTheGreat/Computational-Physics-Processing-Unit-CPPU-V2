"""Official D-Wave benchmark runner (NOT executed in current sandbox).

Requires pip install numpy numba torch dwave-neal dimod dwave-samplers.
CPPU original source is loaded byte-identically. All solver scores checked independently.
SAT methods have different representations; clause counts are the common criterion.
Performance is exploratory and seed-specified. Never silently substitute a local annealer.
"""
from __future__ import annotations
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[name]='1'
import argparse,csv,hashlib,importlib.util,json,pathlib,platform,time,io,contextlib
from types import SimpleNamespace
import numpy as np
from phase8_cases import generate_clauses,sat_to_symmetric_Q,qubo_to_cppu_correct
from phase8_direct_sat import occurrence_table
from phase8_focused_memory import focused_memory
from phase7_core_optimized import refractory_ising
ROOT=pathlib.Path(__file__).parent


def gadget_preflight():
    from itertools import product
    for cl in [[1,2,3],[-1,2,-3],[-1,-2,-3]]:
        C=np.asarray([cl],dtype=np.int32);Q,c=sat_to_symmetric_Q(C,3);J,h,k=qubo_to_cppu_correct(Q)
        for b in product((0,1),repeat=3):
            real=int(not any((v>0 and b[v-1]) or (v<0 and not b[-v-1]) for v in cl))
            outcomes=[]
            for aux in (0,1):
                y=np.asarray([*b,aux],dtype=float);s=2*y-1
                q=float(y@Q@y+c);ising=-float(s@(J@s)+h@s)+c+k
                if abs(q-ising)>1.e-9:raise AssertionError('QUBO and Ising differ')
                outcomes.append(q)
            if abs(min(outcomes)-real)>1.e-9:raise AssertionError('Gadget does not count violation')
    print('PRE-FLIGHT: QUBO/Ising/gadget exact checks passed',flush=True)

def objective(J,h,s):return -float(s@(J@s)+h@s)

def clause_score(C,binvars):
    return int((~(binvars[np.abs(C)-1]==(C>0)).any(axis=1)).sum())

def install_guard():
    # Actual external packages REQUIRED. Fail-closed with no silent local replacement.
    try:import neal,torch,dimod
    except ImportError as e:raise SystemExit('D-Wave comparison NOT run. Install dwave-neal, dimod and torch. Original error: '+str(e))
    try:from dwave.samplers import TabuSampler
    except ImportError:TabuSampler=None
    return neal,torch,dimod,TabuSampler

def original_runner(J,h,seed,torch):
    source=ROOT/'source_reference'/'plunder_allinone_final.py'
    sha=hashlib.sha256(source.read_bytes()).hexdigest()
    if sha!='3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a':
        raise ValueError('Original solver source checksum mismatch; abort')
    spec=importlib.util.spec_from_file_location('plunder_archived_exact',source)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    cfg=SimpleNamespace(agents=8,steps=1200,dt=.02,D0=.25,mem_size=5,mem_inject_every=30,mem_blend=.15,
                        alpha=1.,adaptive_gain=.995,log_every=600,seed=int(seed),device='cpu')
    t=time.perf_counter()
    with contextlib.redirect_stdout(io.StringIO()):
        r=module.run_plunder(torch.as_tensor(J,dtype=torch.float32),torch.as_tensor(h,dtype=torch.float32),cfg)
    s=np.asarray(r['best_assign'],dtype=np.float64)
    return s,time.perf_counter()-t

def one_instance(case,inst,seed,neal,torch,dimod,TabuSampler,outdir):
    if case=='SAT':
        n=32;C=generate_clauses(n,round(4.27*n),inst);Q,c=sat_to_symmetric_Q(C,n)
        J,h,k=qubo_to_cppu_correct(Q);offset=c+k
    else:
        n=256;C=None;rng=np.random.default_rng(inst)
        A=np.triu(rng.normal(0,1/np.sqrt(n),size=(n,n)),1);J=A+A.T;h=np.zeros(n);offset=0.
    # CPPU energy = -(s^T J s + h^T s): sum_{i<j}(-2J_ij)s_i s_j + sum_i(-h_i)s_i.
    biases={i:-float(h[i]) for i in range(len(h)) if abs(h[i])>1e-12}
    links={(i,j):-2*float(J[i,j]) for i in range(len(h)) for j in range(i+1,len(h)) if abs(J[i,j])>1e-12}
    N=len(h)
    np.random.seed(seed)
    # Source-original timing anchors the budget; this is not hardware-neutral algorithmic fairness.
    s0,orig_time=original_runner(J,h,seed,torch)
    baseline_time=max(.03,float(orig_time))
    def read_result(name,s,sec,reads):
        if len(s)!=N and name!='direct_focused':raise ValueError('Incorrect assignment length')
        if name!='direct_focused':
            v=objective(J,h,s)+offset
            viol=clause_score(C,((s[:n]+1)//2).astype(np.int64)) if C is not None else None
        else:
            v=None;viol=clause_score(C,s.astype(np.int64))
        return dict(kind=case,instance=inst,seed=seed,method=name,variables=n,ising_spins=N,
                    computed_energy=v,violations=viol,seconds=sec,reads=reads,budget=baseline_time)
    rows=[read_result('original_plunder',s0,orig_time,1)]
    methods=['official_neal','phase7_refractory']
    if C is not None:methods.append('direct_focused')
    if TabuSampler is not None:methods.append('official_dwave_tabu')
    if C is not None: O,P,ct=occurrence_table(C,n)
    for name in methods:
        t=time.perf_counter();reads=0;bestvalue=float('inf');bestspin=None
        while reads==0 or time.perf_counter()-t<baseline_time:
            rseed=int(seed+reads*1013)
            if name=='official_neal':
                sample=neal.SimulatedAnnealingSampler().sample_ising(biases,links,num_reads=4,num_sweeps=500,seed=rseed)
                spins=[np.asarray([dict(row.sample)[i] for i in range(N)],dtype=float) for row in sample.data(['sample'])]
                for v in spins:
                    val=clause_score(C,((v[:n]+1)//2).astype(np.int64)) if C is not None else objective(J,h,v)
                    if val<bestvalue:bestvalue=val;bestspin=v.copy()
            elif name=='official_dwave_tabu':
                # Official TabuSampler through the optional dwave-samplers package.
                sample=TabuSampler().sample_ising(biases,links,num_reads=4)
                spins=[np.asarray([dict(row.sample)[i] for i in range(N)],dtype=float) for row in sample.data(['sample'])]
                for v in spins:
                    val=clause_score(C,((v[:n]+1)//2).astype(np.int64)) if C is not None else objective(J,h,v)
                    if val<bestvalue:bestvalue=val;bestspin=v.copy()
            elif name=='phase7_refractory':
                v,e=refractory_ising(J,h,rseed,5000,17,0.)
                val=clause_score(C,((v[:n]+1)//2).astype(np.int64)) if C is not None else objective(J,h,v)
                if val<bestvalue:bestvalue=val;bestspin=v.copy()
            else:
                v,e=focused_memory(C,O,P,ct,rseed,3500,4,1,1,.15)
                val=clause_score(C,v)
                if val<bestvalue:bestvalue=val;bestspin=v.copy()
            reads+=1
            if C is not None and bestvalue==0:break
        rows.append(read_result(name,bestspin,time.perf_counter()-t,reads))
        print('BENCH',case,inst,name,rows[-1]['violations'] if C is not None else rows[-1]['computed_energy'],flush=True)
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--preflight',action='store_true');p.add_argument('--run',action='store_true')
    p.add_argument('--count',type=int,default=3);args=p.parse_args()
    gadget_preflight()
    if not args.run:return
    neal,torch,dimod,TabuSampler=install_guard()
    out=ROOT/'official_dwave_results';out.mkdir(exist_ok=True)
    rows=[]
    for kind in ('SK','SAT'):
        for i in range(args.count):
            seed=20261108+i*979
            rows.extend(one_instance(kind,950000+i,seed,neal,torch,dimod,TabuSampler,out))
    with (out/'official_results.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    (out/'metadata.json').write_text(json.dumps(dict(Python=platform.python_version(),official_neal_version=getattr(neal,'__version__','unavailable'),
                  dimod_version=getattr(dimod,'__version__','unavailable'),torch_version=torch.__version__,
                  caveat='Original vs Neal vs new implementations, common SAT clause count but different solver representations; time-budgets approximate, source anchored; no MIPLIB test.'),indent=2))
if __name__=='__main__':main()
