"""Independent optimized, incidence-cached WalkSAT baseline for Phase8.
Same SAT clause input, independent scoring, no QUBO/Ising ancillas.
"""
import os
for x in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[x]='1'
import numpy as np
from numba import njit

@njit
def fast_walksat(clauses,occ,pol,cnt,seed,steps=3000,noise=0.38):
    np.random.seed(seed)
    n=len(cnt);m=len(clauses)
    b=np.random.randint(0,2,n)
    sat=np.zeros(m,dtype=np.int32)
    for j in range(m):
        for k in range(3):
            lit=clauses[j,k]
            if (lit>0 and b[lit-1]==1) or (lit<0 and b[-lit-1]==0):sat[j]+=1
    cur=0
    for j in range(m):
        if sat[j]==0:cur+=1
    best=b.copy();bestv=cur
    for t in range(steps):
        if bestv==0:break
        num=0;chosen_clause=-1
        # Reservoir sampling uniform unsatisfied clause without materializing a list
        for j in range(m):
            if sat[j]==0:
                num+=1
                if np.random.randint(num)==0:chosen_clause=j
        if chosen_clause<0:break
        clause=clauses[chosen_clause]
        if np.random.random()<noise:
            chosen=abs(clause[np.random.randint(3)])-1
        else:
            bestd=100000;chosen=-1
            for k in range(3):
                i=abs(clause[k])-1;d=0
                for z in range(cnt[i]):
                    cj=occ[i,z]
                    ist=(b[i]==1 and pol[i,z]==1) or (b[i]==0 and pol[i,z]==-1)
                    if ist and sat[cj]==1:d+=1
                    elif not ist and sat[cj]==0:d-=1
                if d<bestd or (d==bestd and np.random.random()<0.5):
                    bestd=d;chosen=i
        old=b[chosen];b[chosen]=1-old
        for z in range(cnt[chosen]):
            j=occ[chosen,z]
            istr=(old==1 and pol[chosen,z]==1) or (old==0 and pol[chosen,z]==-1)
            if istr:
                if sat[j]==1:cur+=1
                sat[j]-=1
            else:
                if sat[j]==0:cur-=1
                sat[j]+=1
        if cur<bestv:
            bestv=cur;best=b.copy()
    return best,bestv

@njit
def probsat(clauses,occ,pol,cnt,seed,steps=3000,exponent=2.3):
    """Focused probabilistic local search with inverse-break scoring.
    Strong SAT-specific control (not a byte-for-byte external ProbSAT implementation)."""
    np.random.seed(seed)
    n=len(cnt);m=len(clauses)
    b=np.random.randint(0,2,n)
    sat=np.zeros(m,dtype=np.int32)
    for j in range(m):
        for k in range(3):
            lit=clauses[j,k]
            if (lit>0 and b[lit-1]==1) or (lit<0 and b[-lit-1]==0):sat[j]+=1
    cur=0
    for j in range(m):
        if sat[j]==0:cur+=1
    best=b.copy();bestv=cur
    for t in range(steps):
        if bestv==0:break
        num=0;chosen_clause=-1
        for j in range(m):
            if sat[j]==0:
                num+=1
                if np.random.randint(num)==0:chosen_clause=j
        if chosen_clause<0:break
        clause=clauses[chosen_clause]
        probs=np.empty(3,dtype=np.float64);total=0.
        for k in range(3):
            i=abs(clause[k])-1;breakcnt=0
            for z in range(cnt[i]):
                cj=occ[i,z]
                ist=(b[i]==1 and pol[i,z]==1) or (b[i]==0 and pol[i,z]==-1)
                if ist and sat[cj]==1:breakcnt+=1
            p=(0.2+breakcnt)**(-exponent)
            probs[k]=p;total+=p
        r=np.random.random()*total
        k=0
        while k<2 and r>probs[k]:
            r-=probs[k];k+=1
        chosen=abs(clause[k])-1
        old=b[chosen];b[chosen]=1-old
        for z in range(cnt[chosen]):
            j=occ[chosen,z]
            istr=(old==1 and pol[chosen,z]==1) or (old==0 and pol[chosen,z]==-1)
            if istr:
                if sat[j]==1:cur+=1
                sat[j]-=1
            else:
                if sat[j]==0:cur-=1
                sat[j]+=1
        if cur<bestv:
            bestv=cur;best=b.copy()
    return best,bestv
