#!/usr/bin/env python3
"""Package authenticity and independent score checks. No network needed."""
import hashlib,json,pathlib,subprocess,sys
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
for name,sha in manifest.items():
    p=ROOT/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:raise AssertionError(f'Package file changed or missing: {name}')
print('PASS: sha256 manifest for',len(manifest),'files')
assert hashlib.sha256((ROOT/'original/plunder_allinone_final.py').read_bytes()).hexdigest()=='3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a'
print('PASS: original Plunder byte-level integrity')
sys.path.insert(0,str(ROOT))
from full_cppu import energy,greedy_polish
J=np.array([[0.,1.,-.4],[1.,0.,.2],[-.4,.2,0.]])
s=np.array([1,-1,1],dtype=np.int8);h=np.array([.2,-.1,.3])
s2,e2,n=greedy_polish(s,J,h)
assert e2<=energy(s,J,h)+1e-10
for i in range(3):
    t=s2.copy();t[i]*=-1
    assert energy(t,J,h)>=e2-1e-9
print('PASS: greedy polish never worsens and ends locally stable')
subprocess.run([sys.executable,str(ROOT/'optimized/verify_release.py')],cwd=ROOT/'optimized',check=True)
print('PASS: Phase 9 SAT and Phase 7 Ising independent rescoring')
