# CPPU Full-Power Reconstruction | 2026-11-11

This is a **source-verified recovery** of Abiah Avila's historical virtual Computational Physics Processing Unit (CPPU) and its **separately developed**, later classical optimization research. It is **not** a demonstrated analog, quantum, self-aware, or independent physical hardware device. The state-of-the-art claim has not been established.

## Quick start: Windows 10 / Python 3.10

Extract all files. Open a terminal in the extracted folder, then run:

```bat
py -3.10 -m pip install -r requirements.txt
py -3.10 full_cppu.py --mode verify
py -3.10 full_cppu.py --mode hybrid --demo --steps 800 --polish --output results\hybrid_demo.npz
```

Or double-click `RUN_WINDOWS.bat`. GPU use requires a CUDA-capable PyTorch installation; the default checks CUDA availability automatically and otherwise uses the CPU.

## Four practical execution modes

| Mode | What actually runs | Status |
|---|---|---|
| `--mode original` | Byte-preserved original Plunder sphere-drift/noise/memory program, with configurable arguments instead of a hard-coded seed | Authentic, verified SHA256 |
| `--mode sat` | Phase 9 3-literal SAT event cache + temporary tabu memory, fast local search | Strongest measured random/MAX-3SAT native algorithm in this project, **new classical solver** |
| `--mode ising` | Phase 7 Numba Ising + short-term refractory flip memory | New classical solver |
| `--mode hybrid` | Run original Plunder and Phase 7 Ising on same J/h, independently score, keep lower energy, optionally 1-spin polish | New convenience combination; **more compute**, not benchmark evidence |
| `--mode stability` | User's original momentum+temperature/time-modulation experimental source | Archived optional path, advantage unproven |

**Do not combine SAT and Ising numerical scores as though they are the same metric.** The direct SAT engine reports *violated clauses*; the Ising engines report the distinct `E(s)=-(sᵀJs+hᵀs)` objective.

Examples:

```bat
py -3.10 full_cppu.py --mode original --demo --profile sk96_tuned --output results\plunder_tuned.npz
py -3.10 full_cppu.py --mode sat --demo --steps 10000 --starts 16 --output results\sat.npz
py -3.10 full_cppu.py --mode sat --cnf optimized\examples\example.cnf --starts 16 --steps 10000
py -3.10 full_cppu.py --mode ising --ising optimized\examples\example_J.npy --steps 8000
py -3.10 full_cppu.py --mode hybrid --ising optimized\examples\example_J.npy --steps 8000 --polish
py -3.10 full_cppu.py --mode original --demo --profile historical_sk_tuned --steps 2000 --agents 64
```

### Profiles: not universal constants

`sk96_tuned` uses `agents=16,steps=800,dt=0.03,D0=0.05,adaptive_gain=0.99,alpha=1,mem_size=100,mem_inject_every=500,mem_blend=0.3`; it was selected from and independently tested on **SK96**, not larger SAT or SK instances. The stress experiment found a mean improvement of 53.30 units versus its default original Plunder settings on 8 fresh SK96 matrices (24 paired runs), yet a separately implemented Numba annealer still beat this tuned version. See `benchmarks/parameter_sweep_2026_11_11/REPORT.md`.

`historical` reproduces the old high-step setting (`agents=64,steps=50000,dt=.001,D0=.05`); `historical_sk_tuned` uses `dt=.02` from the old SK experiments. All can be overridden with `--agents`, `--steps`, `--dt`, `--D0`, `--adaptive-gain`, `--alpha` etc. The original source is NEVER modified; the wrapper supplies new settings externally.

## Historical source and complete benchmark records

- `original/`: all three archived Plunder variants byte for byte.
- `legacy/`: two separate earlier, recovered CPPU and 3-SAT prototypes from the uploaded Python source collection.
- `research/operator_papers/`: all **16** original-recovered operator papers as PDFs, unmodified.
- `optimized/`: Phase 7 Ising, Phase 8 encoders/controls, Phase 9 SAT engine, input examples, original source provenance, D-Wave runner.
- `benchmarks/`: runnable parameter stress sweep, Phase 9 and 10 audits, reports, saved result tables.
- `historical_archives/`: untouched complete original user `frozen(2).zip`, Phase 8–10 research archives (including saved trial assignments), November 11 stress-test archive and optimized v10 release.
- `MANIFEST_SHA256.json`: release-file hashes; `verify_all.py` verifies every non-manifest file.
- `.github/workflows/official_dwave.yml`: an **unexecuted** workflow for a future external official comparison.

### Critical limitations

1. **The original 32 independently distinct CPPU operators were not recovered.** The 16 archived paper names have documented conceptual equations, but the bundled programs do not demonstrate 32 fully implemented, integrated operators. The Frankenstein “32 slots” are not those operators.
2. Bend–Rotation's original `bend_rotation.py` is not present among the accessible recovered files; historic 30 matched-seed SAT tests reportedly tied. Hydra filter recently had only ~0.098% measured advantage in one small test and its source was not recovered. Neither is silently invented here.
3. The original 3-SAT QUBO encoder was mathematically inaccurate for clause count; newer direct SAT models are separate corrected algorithms. Original archived assignments, labels and input matrices remain available for provenance.
4. The unmodified source's CPU temperature function returns `None`; `--use_sys_temp` was not wired into its original `run_plunder`. The optional stability variant contains a different temperature path, not proof of a thermal optimization effect.
5. Independent D-Wave Neal/Tabu and MIPLIB tests are **not completed**; the supplied workflow is preparation, not a result. More specialized external solvers may outperform this system. No software integration demonstrates actual physically analog hardware.
6. `--mode hybrid` spends time on multiple algorithms. Keeping the best candidate yields a score at least as good as either candidate in that run but does not establish a faster optimizer.
7. The unrelated personal archive (`py files.zip`) was **not included wholesale**, to avoid packaging unrelated applications and personal memory/crypto project data. Only the two CPPU-related early scripts were copied into `legacy/`.

**Provenance:** Original `plunder_allinone_final.py` SHA256 `3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a`. This archive preserves the original under `/original` and the byte-identical copies in historical archives. All new wrappers are clearly labeled as independent work.
