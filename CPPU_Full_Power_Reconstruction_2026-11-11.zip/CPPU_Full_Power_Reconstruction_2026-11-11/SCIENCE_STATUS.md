# Research status and evidence boundaries

Original Plunder explores a continuous stochastic relaxation on a hypersphere. The observed closest continuous state can be excellent while its sign-projected discrete Ising assignment underperforms simulated annealing because the objectives differ geometrically. That is a real mathematically important failure mode, not proof that the continuous dynamics are useless.

- **November 7 (original pilot):** 16-agent, 1500-step SK1000 median original E=-851.738 against independent annealing E=-1492.559, both CPU, approximately matched compute time.
- **November 7 (Phase 9):** event-driven `event_tabu` mean unsatisfied clauses 5.444 vs Phase 8 8.056 (512 variables), 24.000 vs 39.972 (1024 variables) on the locked random benchmark, with independent rescoring. Phase 9 is a separate classical solver, not the original physical sphere implementation.
- **November 7 (Phase 10 longer):** 0.4s tests: random512 event-tabu 3.083 and weighted 2.500 mean; XOR512 event-tabu 14.125 vs weighted 22.750. Thus weighted mode does not universally dominate.
- **November 11 (original source tuning):** original Plunder SK96 tuning `(dt=.03,adaptive_gain=.99)` improved by mean 53.30 on 8 fresh problem instances x3 seeds, but independent simulated annealing still won all 24 comparisons, by mean 9.12 energy units at similar run time.

All numbers above describe specific benchmarks, not universal capability. 32 authentic operators and historical Bend–Rotation source remain unrecovered; original source isn't secretly replaced. Related Frankenstein neuro-physical interfaces are a different package and do not make the CPPU a validated scientific-discovery agent.

See `benchmarks/reports/` and `benchmarks/parameter_sweep_2026_11_11/` for full design and negative controls.
