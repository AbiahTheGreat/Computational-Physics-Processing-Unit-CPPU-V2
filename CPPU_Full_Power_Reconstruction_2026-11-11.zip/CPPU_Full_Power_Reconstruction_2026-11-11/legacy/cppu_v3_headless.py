import numpy as np
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()
parser.add_argument("--memory", action="store_true")
parser.add_argument("--shock", action="store_true")
parser.add_argument("--delay", action="store_true")
args = parser.parse_args()

# =========================
# CONFIG
# =========================
np.random.seed(42)

N = 30
STEPS = 2000
LR = 0.01
NOISE = 0.002

SHOCK_INTERVAL = 300

MEMORY_DECAY = 0.01
MEMORY_WEIGHT = 0.5

DELAY = 5
DELAY_WEIGHT = 0.3

# =========================
# INITIAL STATE
# =========================
p = np.random.rand(N)
bias = np.random.uniform(0.2, 0.8, N)

C = np.random.uniform(-1, 1, (N, N))
np.fill_diagonal(C, 0)

memory = np.zeros(N)
history = []

energy_history = []

# =========================
# ENERGY FUNCTION
# =========================
def energy(p):
    pair = 0.0
    for i in range(N):
        for j in range(N):
            pair += C[i, j] * np.tanh((p[i] - p[j])**2)

    bias_term = np.sum((p - bias)**2)
    conservation = (np.sum(p) - N / 2)**2

    mem_term = 0.0
    if args.memory:
        mem_term = np.sum((p - memory)**2)

    delay_term = 0.0
    if args.delay and len(history) > DELAY:
        delay_term = np.sum((p - history[-DELAY])**2)

    return pair + bias_term + conservation + mem_term + delay_term

# =========================
# SIMULATION LOOP
# =========================
for step in range(STEPS):

    grad = np.zeros(N)

    for i in range(N):
        for j in range(N):
            diff = p[i] - p[j]
            grad[i] += 2 * C[i, j] * diff * (1 - np.tanh(diff**2)**2)

    grad += 2 * (p - bias)
    grad += 2 * (np.sum(p) - N / 2)

    if args.memory:
        memory[:] = (1 - MEMORY_DECAY) * memory + p
        grad += MEMORY_WEIGHT * (p - memory)

    if args.delay and len(history) > DELAY:
        grad += DELAY_WEIGHT * (p - history[-DELAY])

    grad += NOISE * np.random.randn(N)

    p -= LR * grad
    p = np.clip(p, 0.0, 1.0)

    if step % SHOCK_INTERVAL == 0 and step > 0:
        idx = np.random.randint(0, N)
        bias[idx] = np.random.rand() if args.shock else 1.0 - bias[idx]

    history.append(p.copy())
    energy_history.append(energy(p))

# =========================
# FINAL DIAGNOSTICS
# =========================
energy_history = np.array(energy_history)

print("Final energy:", energy_history[-1])
print("Energy mean (last 200):", np.mean(energy_history[-200:]))
print("Energy std (last 200):", np.std(energy_history[-200:]))

print("Mean p:", np.mean(p))
print("Std p:", np.std(p))
print("Min p:", np.min(p), "Max p:", np.max(p))

# Stability check
if np.isnan(energy_history).any():
    print("⚠️ NaNs detected (FAIL)")
elif np.std(energy_history[-200:]) > 5:
    print("⚠️ High energy volatility (WEAK)")
else:
    print("✅ Stable bounded behavior (PASS)")
