#!/usr/bin/env python3
import argparse
import json
import math
import random
import time
import numpy as np

# ------------------------------------------------------------
# 3SAT instance generator
# ------------------------------------------------------------

def make_random_3sat(n, ratio, seed=None):
    if seed is not None:
        np.random.seed(seed)
        random.seed(seed)
    m = int(n * ratio)
    clauses = []
    for _ in range(m):
        vars_ = random.sample(range(n), 3)
        signs = np.random.choice([-1, 1], size=3)
        clauses.append([(vars_[i], int(signs[i])) for i in range(3)])
    return clauses

# ------------------------------------------------------------
# 12–operator inspired continuous “plunder” solver
# ------------------------------------------------------------

def plunder_step(x, clauses, dt):
    n = len(x)
    grad = np.zeros(n)

    # Operator mix inspired by entropy–collapse–pop–thumper logic
    for clause in clauses:
        vals = [x[v] * s for v, s in clause]
        sat_term = np.tanh(np.mean(vals))
        for (v, s) in clause:
            grad[v] += s * (1 - sat_term**2) * 0.3

    # Add oscillatory “collapse + pop” term for chaotic mixing
    grad += 0.05 * np.sin(7.5 * x) - 0.03 * np.cos(11.3 * x)

    # “Thumper” damping + “clay to mud” adaptation
    x += dt * grad
    x *= 0.9975
    return x

def unsat_count(x, clauses):
    unsat = 0
    for clause in clauses:
        satisfied = False
        for v, s in clause:
            if s * x[v] > 0:
                satisfied = True
                break
        if not satisfied:
            unsat += 1
    return unsat

# ------------------------------------------------------------
# Experiment harness
# ------------------------------------------------------------

def run_experiment(args):
    np.random.seed(args.seed)
    random.seed(args.seed)

    clauses = make_random_3sat(args.n, args.ratio, seed=args.seed)
    x = np.random.uniform(-1, 1, size=args.n)

    t0 = time.time()
    results = []

    for step in range(args.steps + 1):
        if step % args.log_every == 0 or step == args.steps:
            unsat = unsat_count(x, clauses)
            norm = np.mean(np.abs(x))
            elapsed = time.time() - t0
            print(f"[{elapsed:6.2f}s] step={step:5d} unsat={unsat:8.4f} mean_abs={norm:6.3f}")
            results.append((step, unsat, norm))

        x = plunder_step(x, clauses, args.dt)

    total_time = time.time() - t0
    final_unsat = unsat_count(x, clauses)
    solved = final_unsat == 0

    print("\n=== Final Results ===")
    print(f"Solved: {solved}")
    print(f"Remaining unsatisfied clauses: {final_unsat}")
    print(f"Runtime: {total_time:.2f}s\n")

    out = {
        "n": args.n,
        "ratio": args.ratio,
        "steps": args.steps,
        "seed": args.seed,
        "solved": solved,
        "final_unsat": final_unsat,
        "runtime_s": total_time,
        "trace": [{"step": s, "unsat": u, "norm": n} for (s, u, n) in results],
    }

    with open("plunder_results.json", "w") as f:
        json.dump(out, f, indent=2)

    print("Results saved to plunder_results.json")

# ------------------------------------------------------------
# CLI
# ------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(description="Plunder Engine: continuous 3-SAT solver using 12-operator logic")
    p.add_argument("--n", type=int, default=100, help="number of variables")
    p.add_argument("--ratio", type=float, default=4.27, help="clause-to-variable ratio")
    p.add_argument("--steps", type=int, default=40000, help="number of evolution steps")
    p.add_argument("--dt", type=float, default=0.002, help="time step size")
    p.add_argument("--seed", type=int, default=12345, help="random seed")
    p.add_argument("--log_every", type=int, default=500, help="logging frequency (steps)")
    p.add_argument("--archive_every", type=int, default=100, help="archiving frequency (unused placeholder)")
    return p.parse_args()

# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

if __name__ == "__main__":
    args = parse_args()
    run_experiment(args)
