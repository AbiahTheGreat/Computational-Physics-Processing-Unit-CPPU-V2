#!/usr/bin/env python3
"""CPPU full-reconstruction CLI.

Modes:
 original  : BYTE-UNCHANGED 2026 Plunder numerical dynamics via external adapter.
 sat       : Phase 9 EVENT/TABU classical direct 3-CNF solver, NOT original Plunder.
 ising     : Phase 7 refractory-memory classical spin solver, NOT original Plunder.
 hybrid    : Plunder + Phase 7 Ising + optional conventional 1-flip descent.
 stability : Archived experimental momentum/thermal Plunder variant, opt-in.

All results are rescored outside the solver. CPU and GPU options only apply to
original/stability. The "hybrid" mode uses strictly more compute than either
base method and is NOT a time-matched benchmark win.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, pathlib, subprocess, sys, time
from types import SimpleNamespace
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
EXPECTED_SHA='3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a'

PROFILES={
 'sk96_tuned':dict(agents=16,steps=800,dt=0.03,D0=0.05,alpha=1.0,adaptive_gain=0.99,mem_size=100,mem_inject_every=500,mem_blend=0.3,log_every=800),
 'historical':dict(agents=64,steps=50000,dt=0.001,D0=0.05,alpha=1.0,adaptive_gain=0.995,mem_size=800,mem_inject_every=500,mem_blend=0.3,log_every=250),
 'historical_sk_tuned':dict(agents=64,steps=50000,dt=0.02,D0=0.05,alpha=1.0,adaptive_gain=0.995,mem_size=800,mem_inject_every=500,mem_blend=0.3,log_every=250),
}

def load_ising(path, h_path=None):
    J=np.asarray(np.load(path),dtype=np.float64)
    if J.ndim!=2 or J.shape[0]!=J.shape[1] or J.shape[0]==0:raise ValueError('Expected square nonempty J matrix')
    h=np.asarray(np.load(h_path),dtype=np.float64) if h_path else np.zeros(len(J),dtype=np.float64)
    if h.shape!=(len(J),) or not np.all(np.isfinite(J)) or not np.all(np.isfinite(h)):raise ValueError('Finite J,h required')
    if not np.allclose(J,J.T,rtol=0,atol=1e-9):raise ValueError('J must be symmetric')
    if not np.allclose(np.diag(J),0,rtol=0,atol=1e-9):raise ValueError('J diagonal must be zero')
    return J,h

def energy(s,J,h):
    s=np.asarray(s,dtype=np.float64)
    if s.shape!=(len(J),) or not np.all(np.isin(s,[-1,1])):raise AssertionError('Invalid spins')
    return -float(s@(J@s)+h@s)

def greedy_polish(spins,J,h,max_flips=100000):
    """New classic coordinate descent, not a CPPU operator. Exact Ising ΔE for symmetric, diagonal-zero J."""
    s=np.asarray(spins,dtype=np.int8).copy();field=J@s
    e0=energy(s,J,h)
    flips=0
    for _ in range(max_flips):
        delta=4.0*s*field+2.0*h*s
        i=int(np.argmin(delta))
        if delta[i]>=-1e-10:break
        previous=int(s[i]);s[i]=-previous
        field-=2.0*previous*J[:,i]
        flips+=1
    after=energy(s,J,h)
    assert after<=e0+1e-6,(after,e0)
    return s,after,flips

def original(J,h,args):
    import torch
    path=ROOT/'original'/'plunder_allinone_final.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==EXPECTED_SHA,'Original Plunder source altered!'
    if args.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA explicitly requested but unavailable')
    device='cuda' if (args.device=='cuda' or (args.device=='auto' and torch.cuda.is_available())) else 'cpu'
    if device=='cpu':torch.set_num_threads(min(4,torch.get_num_threads()))
    spec=importlib.util.spec_from_file_location('original_plunder_unchanged',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    cfg=PROFILES[args.profile].copy()
    for key in list(cfg):
        override=getattr(args,key,None)
        if override is not None:cfg[key]=override
    for key in ['agents','steps','mem_size','mem_inject_every','log_every']:
        if int(cfg[key])<1:raise ValueError(key+' must be > 0')
    if cfg['dt']<=0 or cfg['D0']<0 or cfg['adaptive_gain']<=0:raise ValueError('Invalid timestep/noise/gain')
    cfg.update(seed=args.seed,device=device)
    Jt=torch.as_tensor(J,dtype=torch.float32,device=device);ht=torch.as_tensor(h,dtype=torch.float32,device=device)
    t0=time.perf_counter();res=module.run_plunder(Jt,ht,SimpleNamespace(**cfg));secs=time.perf_counter()-t0
    s=np.asarray(res['best_assign'],dtype=np.int8)
    actual=energy(s,J,h)
    tol=max(.05,abs(actual)*1e-3)
    if abs(actual-float(res['best_E']))>tol:raise AssertionError('Original solver score disagrees with independent score')
    return s,actual,{'backend':'unchanged_original_plunder','source_sha256':EXPECTED_SHA,'settings':cfg,'seconds':secs,'reported_energy_float32':float(res['best_E'])}

def run_optimized(mode,args):
    # Preserve the published standalone solver source; route the same flags faithfully.
    script=ROOT/'optimized'/'run_cppu.py'
    pathlib.Path(args.output).expanduser().resolve().parent.mkdir(parents=True,exist_ok=True)
    if mode=='sat':
        if not args.demo and not args.cnf:raise ValueError('SAT requires --cnf or --demo')
        cmd=[sys.executable,str(script),'--demo'] if args.demo else [sys.executable,str(script),'--cnf',str(args.cnf)]
        cmd+=['--starts',str(args.starts),'--steps',str(args.steps or 2000),'--seed',str(args.seed),'--output',str(args.output)]
    else:
        if not args.ising and not args.demo:raise ValueError('Ising requires --ising or --demo')
        path=ROOT/'optimized/examples/example_J.npy' if args.demo else pathlib.Path(args.ising).resolve()
        cmd=[sys.executable,str(script),'--ising',str(path),'--steps',str(args.steps or 8000),'--seed',str(args.seed),'--output',str(args.output)]
        if args.h:cmd+=['--h',str(pathlib.Path(args.h).resolve())]
    subprocess.run(cmd,cwd=pathlib.Path.cwd(),check=True)

def save(s,e,meta,path):
    path=pathlib.Path(path).resolve();path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,assignment=s,energy=e)
    meta.update(energy=float(e),assignment_file=str(path))
    path.with_suffix('.json').write_text(json.dumps(meta,indent=2,default=str),encoding='utf8')
    print(json.dumps(meta,indent=2,default=str))

def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--mode',choices=['original','sat','ising','hybrid','stability','verify'],default='hybrid')
    p.add_argument('--ising');p.add_argument('--h');p.add_argument('--cnf');p.add_argument('--demo',action='store_true')
    p.add_argument('--profile',choices=tuple(PROFILES),default='sk96_tuned')
    p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    p.add_argument('--seed',type=int,default=1234)
    for name in ['agents','steps','mem_size','mem_inject_every','log_every']:
        p.add_argument('--'+name.replace('_','-'),type=int,default=None)
    for name in ['dt','D0','alpha','adaptive_gain','mem_blend']:
        p.add_argument('--'+name.replace('_','-'),type=float,default=None)
    p.add_argument('--starts',type=int,default=8)
    p.add_argument('--polish',action='store_true',help='Classic greedy single-spin polish; not original CPPU')
    p.add_argument('--output',default='results/cppu_solution.npz')
    a=p.parse_args()
    if a.mode=='verify':
        subprocess.run([sys.executable,str(ROOT/'verify_all.py')],cwd=ROOT,check=True);return
    if a.mode in ('sat','ising'):
        run_optimized(a.mode,a);return
    if a.mode=='stability':
        if not a.ising:raise SystemExit('Stability mode requires --ising <J.npy>')
        command=[sys.executable,str(ROOT/'original/plunder_stability_buster.py'),'--load_J',str(pathlib.Path(a.ising).resolve()),'--steps',str(a.steps or 1000),'--agents',str(a.agents or 16),'--device',a.device]
        if a.h: command+=['--load_h',str(pathlib.Path(a.h).resolve())]
        subprocess.run(command,cwd=ROOT,check=True);return
    if a.demo:
        rng=np.random.default_rng(11011);n=96
        J=rng.normal(0,1/np.sqrt(n),(n,n));J=np.triu(J,1);J=J+J.T;h=np.zeros(n)
    else:
        if not a.ising:raise SystemExit('Original/hybrid requires --ising J.npy or --demo')
        J,h=load_ising(a.ising,a.h)
    candidates=[]
    s,e,details=original(J,h,a);candidates.append((s,e,details))
    if a.mode=='hybrid':
        from optimized.phase7_core_optimized import refractory_ising
        t0=time.perf_counter()
        ss,reported=refractory_ising(J,h,a.seed+17,int(a.steps or 8000),17,0.)
        ee=energy(ss,J,h)
        if abs(ee-float(reported))>max(1e-5,1e-8*abs(ee)):raise AssertionError('Phase 7 score discrepancy')
        candidates.append((np.asarray(ss,dtype=np.int8),ee,{'backend':'new_classical_phase7_refractory','seconds':time.perf_counter()-t0,'steps':int(a.steps or 8000)}))
    s,e,details=min(candidates,key=lambda c:c[1]);before=e
    polish_flips=0
    if a.polish:
        s,e,polish_flips=greedy_polish(s,J,h)
    meta={'mode':a.mode,'winner':details,'candidates':[{'backend':d['backend'],'energy':en} for _,en,d in candidates],
          'energy_convention':'E(s)=-(s^T J s+h^T s)','polish_flips':polish_flips,'pre_polish_energy':before,
          'note':'Hybrid combines separate algorithms with extra compute; not a matched-budget benchmark.'}
    save(s,e,meta,a.output)

if __name__=='__main__':main()
