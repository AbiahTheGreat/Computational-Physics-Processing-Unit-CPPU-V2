"""Reproducible Phase9 release creation: packages data, code and complete audit manifest."""
import os,pathlib,hashlib,zipfile,platform,json,sys
import numpy as np
import numba
BASE=pathlib.Path(__file__).resolve().parent
DEST=pathlib.Path('/mnt/data/CPPU_Phase9_Event_Dynamics_Validated_2026-11-07.zip')

items=[]
for item in BASE.rglob('*'):
    if not item.is_file():continue
    rel=item.relative_to(BASE)
    if any(p in ('__pycache__','.git') for p in rel.parts):continue
    if item.suffix in ('.pyc',):continue
    if item.name in ('MANIFEST_SHA256.txt',):continue
    # Include named results and exact original source, skip temporary partial logs.
    if item.suffix in ('.log',):continue
    items.append((rel,item))
items.sort(key=lambda z:str(z[0]))
assert (BASE/'PHASE9_AUDIT.json').exists(), 'Run primary audit first'
assert (BASE/'phase9_xor.csv').exists() and (BASE/'phase9_large.csv').exists(), 'Run stress audits first'

metadata={
 'run_date':'2026-11-07','python':sys.version.split()[0],
 'numpy':np.__version__,'numba':numba.__version__,
 'cpu':next((line.split(':',1)[1].strip() for line in open('/proc/cpuinfo') if line.startswith('model name')),'unavailable'),
 'total_independently_verified_saved_assignments':1328,
 'official_dwave_neal_run':False,'external_maxsat_run':False,'miplib_run':False,
 'source_original_sha256':'3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a',
 'new_method':'classical event-cached 3CNF tabu-like local search (not original CPPU)'
}
(BASE/'PHASE9_RELEASE_METADATA.json').write_text(json.dumps(metadata,indent=2))
items=[(rel,item) for rel,item in items if rel.name!='PHASE9_RELEASE_METADATA.json']
items.append((pathlib.Path('PHASE9_RELEASE_METADATA.json'),BASE/'PHASE9_RELEASE_METADATA.json'))
items.sort(key=lambda z:str(z[0]))
manifest=''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel.as_posix()}\n' for rel,p in items)
(BASE/'MANIFEST_SHA256.txt').write_text(manifest)
root='CPPU_Phase9_Event_Dynamics_Validated_2026-11-07'
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for rel,p in items:z.write(p,arcname=f'{root}/{rel.as_posix()}')
    z.write(BASE/'MANIFEST_SHA256.txt',arcname=f'{root}/MANIFEST_SHA256.txt')
with zipfile.ZipFile(DEST,'r') as z:
    assert z.testzip() is None
    names=set(z.namelist())
    assert len(names)==len(items)+1
    for rel,p in items:
        data=z.read(f'{root}/{rel.as_posix()}')
        assert hashlib.sha256(data).digest()==hashlib.sha256(p.read_bytes()).digest()
print(json.dumps({'archive':str(DEST),'bytes':DEST.stat().st_size,'files':len(items)+1,
                  'original_source_sha256':metadata['source_original_sha256']},indent=2))
