"""Independent reconstruction and score audit for Phase 9, plus paired instance bootstrap."""
import json,hashlib,collections,glob,pathlib
import numpy as np,pandas as pd
from phase8_cases import generate_clauses
from phase9_event_core import solve_event
from phase8_direct_sat import occurrence_table
ROOT=pathlib.Path(__file__).parent
files=sorted(ROOT.glob('phase9_confirmation_shard*of8.csv'))
if len(files)!=8:raise AssertionError('Eight finished shards required')
df=pd.concat((pd.read_csv(p) for p in files),ignore_index=True)
assert len(df)==864,(len(df))
assert df.groupby(['n','ratio','instance','rep']).size().eq(6).all()
assert df.groupby(['n','ratio','instance']).size().eq(12).all()
assert df['assignment'].nunique()==len(df)
assert (df.seconds<=1.5*df.budget).all(),df[df.seconds>1.5*df.budget][['seconds','budget']]
assert (df.seconds>0).all()
cache={};max_error=0
for k,r in df.iterrows():
    inst=int(r.instance);n=int(r.n);ratio=float(r.ratio)
    if inst not in cache:
        C=generate_clauses(n,round(n*ratio),inst)
        cache[inst]=C
    C=cache[inst]
    assert hashlib.sha256(C.tobytes()).hexdigest()==r.instance_hash
    with np.load(ROOT/'assignments_confirmation'/r.assignment) as f:b=f['bits']
    assert b.shape==(n,)
    assert np.logical_or(b==0,b==1).all()
    actual=int(np.count_nonzero(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))
    max_error=max(max_error,abs(actual-int(r.violations)))
    if actual!=int(r.violations):raise AssertionError((r.assignment,actual,r.violations))
# Check state bookkeeping with full per-flip instrumentation across 3 sizes/5 variants.
for n in (16,64,256):
    C=generate_clauses(n,round(4.27*n),983142+n);O,P,cnt=occurrence_table(C,n)
    for mode in range(5):
        b,v,m=solve_event(C,O,P,cnt,1043+n,1000,mode,verify=True)
        assert int(np.count_nonzero(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))==v
out=ROOT/'phase9_confirmation.csv';df.to_csv(out,index=False)

# paired instance bootstrap preserve both attempts per instance, and stratify ratio
rng=np.random.default_rng(552101)
summary=[];pairs=[]
for n in (512,1024):
    chunk=df[df.n==n]
    for method,g in chunk.groupby('method'):
        summary.append(dict(n=n,method=method,trials=len(g),instances=g.instance.nunique(),
                 mean_violations=float(g.violations.mean()),median_violations=float(g.violations.median()),
                 solved=int((g.violations==0).sum()),mean_seconds=float(g.seconds.mean()),
                 median_updates=float(g.updates.median()),median_reads=float(g.reads.median())))
    pivot=chunk.pivot(index=['ratio','instance','rep'],columns='method',values='violations')
    for challenger in ['phase8_original','event_walksat','event_probsat','event_novelty','event_tabu','event_weighted']:
        for proposed in ['event_weighted','event_tabu']:
            if challenger==proposed:continue
            gap=pivot[challenger]-pivot[proposed]
            wins=int((gap>0).sum());ties=int((gap==0).sum());losses=int((gap<0).sum())
            ratio_groups={r:gap.loc[r].groupby('instance').mean().to_numpy() for r in sorted(chunk.ratio.unique())}
            boot=np.empty(3000)
            for j in range(len(boot)):
                boot[j]=np.mean([np.mean(a[rng.integers(0,len(a),len(a))]) for a in ratio_groups.values()])
            pairs.append(dict(n=n,control=challenger,method=proposed,mean_gain=float(gap.mean()),
                    lo=float(np.percentile(boot,2.5)),hi=float(np.percentile(boot,97.5)),
                    wins=wins,ties=ties,losses=losses))
(ROOT/'phase9_summary.csv').write_text(pd.DataFrame(summary).to_csv(index=False))
(ROOT/'phase9_pairs.csv').write_text(pd.DataFrame(pairs).to_csv(index=False))
record=dict(total_assignments=len(df),unique_instances=df[['n','ratio','instance']].drop_duplicates().shape[0],
              independent_score_errors=max_error,
              size_records={str(n):int(sum(df.n==n)) for n in (512,1024)},
              methods=sorted(df.method.unique()),
              clock_overrun_max=float((df.seconds/df.budget).max()),
              full_internal_state_audit='3 sizes x 5 methods x 1000 steps, assertion passes',
              note='No external Neal/Tabu/MaxSAT code was run; all controls are local Numba implementations.')
(ROOT/'PHASE9_AUDIT.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
print(pd.DataFrame(summary).round(3).to_string(index=False))
print('PRIMARY PAIRS')
print(pd.DataFrame(pairs)[lambda x:x.control.eq('phase8_original')|x.control.eq('event_probsat')].round(3).to_string(index=False))
