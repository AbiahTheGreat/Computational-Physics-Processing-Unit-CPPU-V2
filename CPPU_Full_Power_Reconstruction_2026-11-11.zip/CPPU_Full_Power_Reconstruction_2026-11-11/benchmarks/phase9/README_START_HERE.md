# CPPU Phase 9 Research Bundle

Open `PHASE9_REPORT.md` for methods, results and limitations. The best SAT implementation in this bundle is **new conventional CPU local-search code**, not an untouched original Plunder processor.

## Most useful files

- `run_cppu_phase9.py`: command-line runner for strict 3-literal DIMACS CNF or an Ising `.npy` matrix; see examples below.
- `phase9_event_core.py`: faster event-driven SAT search. `mode=1` is the simplest robust default (unweighted tabu-like flip-memory). `mode=0` adds dynamic clause weights, which hurt on shifted data.
- `phase8_focused_memory.py`: slower Phase 8 reference implementation.
- `phase7_core_optimized.py`: Phase 7 spin-glass numerical engine, **not** the original CPPU source.
- `source_reference/plunder_allinone_final.py`: original unmodified archived Plunder source, for provenance.
- `phase9_confirmation.csv`, `phase9_xor.csv`, `phase9_large.csv`: 1,328 measured and independently rescored final solutions with matching saved assignment files.
- `phase9_audit.py`, `phase9_xor_audit.py`, `phase9_large_audit.py`: verify results without trusting solver-reported objective values.
- `phase9_official_dwave_runner.py`: official D-Wave comparisons, **NOT run** here. `--preflight` runs without D-Wave packages.
- `phase9_official_dwave_workflow.yml`: copy to `.github/workflows/phase9_official_dwave_workflow.yml` in a GitHub repo with the source modules and `source_reference/` directory at root; then run manually on GitHub Actions. It is prepared, not yet tested on GitHub-hosted runners.

## Commands

```
python -m pip install numpy numba pandas
python run_cppu_phase9.py --demo --starts 8 --steps 2000
python run_cppu_phase9.py --cnf example.cnf --starts 8 --steps 2000
python run_cppu_phase9.py --ising example_J.npy --steps 8000
python phase9_audit.py
python phase9_xor_audit.py
python phase9_large_audit.py
python phase9_official_dwave_runner.py --preflight
```

For Windows, use `py -3.10` instead of `python` if that's your installed Python version. `run_cppu_phase9.py` accepts only exactly three **distinct** literals per clause with no hard or weighted clauses. This limitation is intentional, to avoid silently changing the mathematical question.

## Interpretation

Phase 9 software solves *some* instances more effectively than the Phase 8 experimental version at the same short CPU budget. It is not evidence of a new law of physics, a quantum computer, an exceptional universal optimizer, or superiority to actual Neal and competitive MaxSAT solvers. The original source is included to make the separation transparent.
