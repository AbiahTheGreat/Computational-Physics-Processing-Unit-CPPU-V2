import hashlib,pathlib,json,numpy as np,pandas as pd
from phase8_cases import generate_clauses
ROOT=pathlib.Path(__file__).parent
df=pd.read_csv(ROOT/'phase9_large.csv')
assert len(df)==80 and df.instance.nunique()==16
assert df.groupby(['instance','n','ratio']).size().eq(5).all()
for _,r in df.iterrows():
    C=generate_clauses(int(r.n),round(float(r.ratio)*int(r.n)),int(r.instance))
    assert hashlib.sha256(C.tobytes()).hexdigest()==r.instance_hash
    with np.load(ROOT/'assignments_large'/r.assignment) as f:b=f['bits']
    assert b.shape==(int(r.n),) and np.isin(b,(0,1)).all()
    actual=int(np.count_nonzero(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))
    assert actual==int(r.violations),r.assignment
s=df.groupby(['n','method']).agg(trials=('violations','size'),mean_violations=('violations','mean'),median_violations=('violations','median'),mean_seconds=('seconds','mean')).reset_index()
s.to_csv(ROOT/'phase9_large_summary.csv',index=False)
print('SCALE audit passed:',len(df),'assignments /',df.instance.nunique(),'new large instances\n',s.to_string(index=False))
