"""Locked large-instance scaling check (2048 and 4096 variables), 0.10s per trial."""
import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[v]='1'
import csv,hashlib,pathlib,time,numpy as np
from phase8_cases import generate_clauses
from phase8_direct_sat import occurrence_table
from phase9_benchmark import run_one,warm
ROOT=pathlib.Path(__file__).parent
METHODS=['event_tabu','event_weighted','event_probsat','event_novelty','phase8_original']

def main():
 warm();out=ROOT/'assignments_large';out.mkdir(exist_ok=True)
 rows=[];tic=time.perf_counter()
 for n in (2048,4096):
  for ratio in (4.27,4.5):
   for rep in range(4):
    seed=3780000+ n*100+int(ratio*100)+rep
    C=generate_clauses(n,round(n*ratio),seed)
    O,P,cnt=occurrence_table(C,n)
    h=hashlib.sha256(C.tobytes()).hexdigest()
    for name in METHODS:
     b,v,seconds,reads,updates=run_one(name,C,O,P,cnt,seed*11%2147483647,.1)
     fn=f'{seed}_{name}.npz'
     np.savez_compressed(out/fn,bits=b)
     rows.append(dict(n=n,ratio=ratio,instance=seed,method=name,violations=v,seconds=seconds,reads=reads,updates=updates,
                      assignment=fn,instance_hash=h))
    print('SCALE',n,ratio,rep,'elapsed',round(time.perf_counter()-tic,2),flush=True)
 with (ROOT/'phase9_large.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 for n in (2048,4096):
  for name in METHODS:
   a=[r['violations'] for r in rows if r['n']==n and r['method']==name]
   print('LARGE',n,name,'mean',np.mean(a),'median',np.median(a))

if __name__=='__main__':main()
