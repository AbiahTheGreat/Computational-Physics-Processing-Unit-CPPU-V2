"""Audits XOR shift test against independent XOR equation count and 3-CNF score."""
import pathlib,hashlib,json,numpy as np,pandas as pd
from phase9_stress import generate_xor
ROOT=pathlib.Path(__file__).parent
p0=ROOT/'xor_shard0.csv';p1=ROOT/'xor_shard1.csv'
df=pd.concat([pd.read_csv(p0),pd.read_csv(p1)],ignore_index=True)
assert len(df)==384
assert df.groupby(['n','ratio','instance','rep']).size().eq(6).all()
for _,r in df.iterrows():
    n=int(r.n);eqs=round(n*r.ratio)
    C,tr=generate_xor(n,eqs,int(r.instance),False)
    assert hashlib.sha256(C.tobytes()).hexdigest()==r.instance_hash
    with np.load(ROOT/'assignments_xor'/r.assignment) as f:b=f['bits']
    assert b.shape==(n,) and np.isin(b,(0,1)).all()
    clause=int(np.sum(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))
    rhs=b[tr[:,:3]]
    parity=int(np.sum((rhs[:,0]^rhs[:,1]^rhs[:,2])!=tr[:,3]))
    assert clause==parity==r.violations
summary=df.groupby(['n','method']).agg(trials=('violations','size'),mean_violations=('violations','mean'),median_violations=('violations','median'),mean_seconds=('seconds','mean')).reset_index()
summary.to_csv(ROOT/'phase9_xor_summary.csv',index=False)
df.to_csv(ROOT/'phase9_xor.csv',index=False)
print('Independent XOR audit:',len(df),'solutions, exact clause / XOR agreement.\n',summary.to_string(index=False))
