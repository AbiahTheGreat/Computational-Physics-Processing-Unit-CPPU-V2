@echo off
setlocal
cd /d "%~dp0"
py -3.10 -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
py -3.10 full_cppu.py --mode verify
if errorlevel 1 exit /b 1
py -3.10 full_cppu.py --mode hybrid --demo --steps 800 --agents 16 --polish --output results\hybrid_demo.npz
endlocal
