"""Longer-budget confirmation; pre-fixed held-out random and XOR-derived 3-CNF.
Source methods are copied unchanged from Phase9; independent scoring and saved spins.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import pathlib,sys,csv,time,hashlib,json,platform
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_phase9'))
from phase8_cases import generate_clauses
from phase9_stress import generate_xor
from phase8_direct_sat import occurrence_table
from phase9_event_core import solve_event

def score(C,b):return int(np.count_nonzero(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))

def run(C,O,P,ct,method,seed,budget):
    modes={'event_tabu':1,'event_weighted':0,'event_probsat':3,'event_novelty':4}
    mode=modes[method]
    t=time.perf_counter();best=len(C)+1;bestb=None;reads=0;moves=0
    while reads==0 or time.perf_counter()-t < budget:
        b,v,m=solve_event(C,O,P,ct,int((seed+104729*reads)%2147483647),3000,mode,4,45,.15)
        actual=score(C,b)
        if actual!=v:raise AssertionError('Solver objective disagrees with independent score')
        if v<best:best=v;bestb=b.copy()
        moves+=m;reads+=1
        if best==0:break
    return bestb,best,time.perf_counter()-t,reads,moves

def cases():
    o=[]
    for n in (512,1024):
        for ratio in (4.10,4.27,4.5):
            for i in range(4):o.append(('random3',n,ratio,4410000+n*2001+round(ratio*1000)*11+i*29))
    for ratio in (0.80,1.1):
        for i in range(4):o.append(('xor3',512,ratio,4710000+round(ratio*1000)*11+i*29))
    return o

def main(budget=.40):
    c=generate_clauses(64,270,1900);O,P,ct=occurrence_table(c,64)
    for mode in (0,1,3,4):solve_event(c,O,P,ct,11223,20,mode)
    rows=[];ad=ROOT/'saved_long_budget';ad.mkdir(exist_ok=True)
    methods=['event_tabu','event_weighted','event_probsat','event_novelty']
    for k,(family,n,ratio,seed) in enumerate(cases()):
        if family=='random3':C=generate_clauses(n,round(n*ratio),seed)
        else:C,_=generate_xor(n,round(n*ratio),seed,planted=False)
        O,P,ct=occurrence_table(C,n);h=hashlib.sha256(C.tobytes()).hexdigest()
        # Rotate order to counteract method order/CPU drift.
        for meth in methods[k%4:]+methods[:k%4]:
            b,s,sec,reads,moves=run(C,O,P,ct,meth,seed*33+21,budget)
            fn=f'{family}_{n}_{seed}_{meth}.npz';np.savez_compressed(ad/fn,bits=b)
            if score(C,b)!=s:raise AssertionError('Saved bits mismatch score')
            rows.append(dict(family=family,n=n,ratio=ratio,seed=seed,hash=h,method=meth,
                        violations=s,seconds=round(sec,6),reads=reads,moves=moves,assignment=fn))
        print('LONG',k+1,'/',len(cases()),family,n,ratio,[(m,next(r['violations'] for r in rows if r['seed']==seed and r['method']==m)) for m in methods],flush=True)
    with (ROOT/'phase10_long_trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    summary={'cases':len(cases()),'records':len(rows),'budget_per_method_s':budget,'method_mean':{},'pair_results':{}}
    for family in ('random3','xor3'):
        for n in (512,1024):
            ff=[r for r in rows if r['family']==family and r['n']==n]
            if not ff:continue
            key=f'{family}_{n}';summary['method_mean'][key]={m:round(np.mean([r['violations'] for r in ff if r['method']==m]),3) for m in methods}
            summary['pair_results'][key]={}
            for other in methods[1:]:
                gaps=[]
                for seed in sorted({r['seed'] for r in ff}):
                    rr={r['method']:r['violations'] for r in ff if r['seed']==seed}
                    gaps.append(rr[other]-rr['event_tabu'])
                summary['pair_results'][key][other]={'tabu_wins':sum(v>0 for v in gaps),'ties':sum(v==0 for v in gaps),
                   'tabu_losses':sum(v<0 for v in gaps),'mean_opponent_minus_tabu':round(float(np.mean(gaps)),3)}
    (ROOT/'phase10_long_summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main(float(sys.argv[1]) if len(sys.argv)>1 else .4)
