"""Reconstruct and verify all saved Phase10 MAX3SAT assignments from seeds.
Scores are recomputed with NumPy rather than the solver objective function.
Reruns the same exact MILP constraint assertions on stored HiGHS assignments.
Phase10 longer-budget first 21 cases have assignment bytes but missing runtime logs:
never invent timings; mark the field unavailable.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[k]='1'
import csv,json,hashlib,sys,pathlib,numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from phase10_long_budget import cases as long_cases
from phase10_independent_milp import suite as milp_cases, planted
from source_phase9.phase8_cases import generate_clauses
from source_phase9.phase9_stress import generate_xor

def score(C,b):
    if len(b)<np.max(np.abs(C)) or not np.all(np.isin(b,[0,1])):raise ValueError('Invalid bits')
    return int(np.sum(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))

def getclauses(typ,n,ratio,seed):
    if typ=='xor3':return generate_xor(n,round(n*ratio),seed,planted=False)[0]
    if typ=='planted3':return planted(n,round(n*ratio),seed)
    return generate_clauses(n,round(n*ratio),seed)

def main():
    milp_saved={}
    with (ROOT/'phase10_trials.csv').open() as f:
        rows=list(csv.DictReader(f))
    for r in rows:
        C=getclauses(r['family'],int(r['n']),float(r['ratio']),int(r['seed']))
        if hashlib.sha256(C.tobytes()).hexdigest()!=r['sha256']:raise AssertionError('MILP instance hash mismatch')
        if not r['assignment']:continue
        b=np.load(ROOT/'saved_assignments'/r['assignment'])['bits']
        v=score(C,b)
        if v!=int(r['violations']):raise AssertionError(('MILP score mismatch',r,v))
        milp_saved[(r['family'],r['n'],r['seed'],r['method'])]=v
        if r['method']=='highs_milp' and r['optimal']=='True':
            for name in ('event_tabu','event_weighted','event_probsat_control'):
                ov=next(x['violations'] for x in rows if x['family']==r['family'] and x['n']==r['n'] and x['seed']==r['seed'] and x['method']==name)
                if int(ov)<v:raise AssertionError('Heuristic beats certified optimum!')
    longrows=[]
    methods=('event_tabu','event_weighted','event_probsat','event_novelty')
    tail={}
    with (ROOT/'phase10_long_last11.csv').open() as f:
        for r in csv.DictReader(f):tail[(r['seed'],r['method'])]=r
    for idx,(family,n,ratio,seed) in enumerate(long_cases()):
        C=getclauses(family,n,ratio,seed);h=hashlib.sha256(C.tobytes()).hexdigest()
        for meth in methods:
            fn=f'{family}_{n}_{seed}_{meth}.npz'
            b=np.load(ROOT/'saved_long_budget'/fn)['bits']
            v=score(C,b)
            rr=tail.get((str(seed),meth),{})
            if rr and v!=int(rr['violations']):raise AssertionError(('Long score mismatch',rr,v))
            longrows.append(dict(family=family,n=n,ratio=ratio,seed=seed,sha256=h,method=meth,
                                 violations=v,seconds=rr.get('seconds',''),reads=rr.get('reads',''),
                                 moves=rr.get('moves',''),timing_available=bool(rr),assignment=fn))
    with (ROOT/'phase10_long_verified.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(longrows[0]));w.writeheader();w.writerows(longrows)
    summary={'milp_verified':len(milp_saved),'long_verified':len(longrows),'long_timing_available':sum(r['timing_available'] for r in longrows),
             'long_timing_missing':sum(not r['timing_available'] for r in longrows),'by_family_and_size':{},'long_nominal_budget_s':.4}
    for fam in ('random3','xor3'):
        for n in (512,1024):
            group=[r for r in longrows if r['family']==fam and r['n']==n]
            if not group:continue
            key=f'{fam}_{n}'
            ms={m:[r['violations'] for r in group if r['method']==m] for m in methods}
            counts={}
            for m in methods[1:]:
                delta=[]
                for seed in sorted(set(r['seed'] for r in group)):
                    sub={r['method']:r['violations'] for r in group if r['seed']==seed}
                    delta.append(sub[m]-sub['event_tabu'])
                counts[m]={'tabu_wins':sum(x>0 for x in delta),'ties':sum(x==0 for x in delta),'tabu_losses':sum(x<0 for x in delta),
                           'mean_difference_opponent_minus_tabu':round(float(np.mean(delta)),3)}
            summary['by_family_and_size'][key]={'cases':len(group)//4,'means':{m:round(float(np.mean(ms[m])),3) for m in methods},'pairs':counts}
    (ROOT/'phase10_long_audit.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
