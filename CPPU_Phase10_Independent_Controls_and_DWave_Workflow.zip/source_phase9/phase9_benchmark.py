"""Phase9 exploratory and locked confirmation. Paired by instance and trial, approx wall-clock budgets.
Reports real clock overshoot, independent solution recheck, and deterministic construction seeds.
"""
import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[v]='1'
import sys,time,csv,json,hashlib,platform,pathlib,argparse
import numpy as np
from phase8_cases import generate_clauses
from phase8_direct_sat import occurrence_table
from phase8_focused_memory import focused_memory
from phase9_event_core import solve_event
ROOT=pathlib.Path(__file__).resolve().parent
METHODS=['event_weighted','event_tabu','event_walksat','event_probsat','event_novelty','phase8_original']

def recheck(C,b):
    return int(np.count_nonzero(~np.any(b[np.abs(C)-1]==(C>0),axis=1)))

def run_one(name,C,O,P,cnt,base_seed,budget,save=None,pressure_period=45,tenure=4):
    best_v=len(C)+1;best_b=None
    start=time.perf_counter();reads=0;updates=0
    while reads==0 or (time.perf_counter()-start)<budget:
        seed=int((base_seed+104729*reads)%(2**31-1))
        if name=='phase8_original':
            b,v=focused_memory(C,O,P,cnt,seed,1000,4,1,1,.15)
        else:
            mode=METHODS.index(name)
            b,v,moves=solve_event(C,O,P,cnt,seed,1500,mode,tenure,pressure_period,.15)
            updates+=moves
        actual=recheck(C,b)
        if v!=actual:raise AssertionError((name,v,actual))
        if actual<best_v:
            best_v=actual;best_b=b.copy()
        reads+=1
        if best_v==0:break
    secs=time.perf_counter()-start
    return best_b,best_v,secs,reads,updates

def warm():
    C=generate_clauses(32,round(4.27*32),98450)
    O,P,cnt=occurrence_table(C,32)
    for name in METHODS: run_one(name,C,O,P,cnt,43287,.00001)

def build_suite(phase):
    if phase=='calibration':
        # No reuse of held-out or earlier Phase 8 seeds
        return [(n,ratio,1760000+n*100+int(ratio*100)+i,rep) for n in (512,1024) for ratio in (4.27,4.5) for i in range(3) for rep in range(1)]
    if phase=='confirmation':
        return [(n,ratio,1770000+n*100+int(ratio*100)*100+i,rep) for n in (512,1024) for ratio in (4.1,4.27,4.5) for i in range(12) for rep in range(2)]
    raise ValueError('Bad phase')

def main(phase,methods=None,budget=0.075,shard=0,shards=1):
    warm()
    triallist=[(ix,t) for ix,t in enumerate(build_suite(phase)) if ix%shards==shard]
    out=ROOT/('phase9_'+phase+(f'_shard{shard}of{shards}' if shards>1 else '')+'.csv')
    assignment_dir=ROOT/('assignments_'+phase)
    assignment_dir.mkdir(exist_ok=True)
    chosen=METHODS if methods is None else methods
    rows=[]
    for k,(run_i,(n,ratio,instance,rep)) in enumerate(triallist):
        C=generate_clauses(n,round(ratio*n),instance)
        O,P,cnt=occurrence_table(C,n)
        hashC=hashlib.sha256(C.tobytes()).hexdigest()
        base_seed=int((instance*37+rep*7919)% (2**31-1))
        rotated=chosen[(run_i)%len(chosen):]+chosen[:(run_i)%len(chosen)]
        for meth in rotated:
            bits,score,secs,reads,updates=run_one(meth,C,O,P,cnt,base_seed,budget)
            fname=f'{n}_{instance}_{rep}_{meth}.npz'
            np.savez_compressed(assignment_dir/fname,bits=bits)
            rows.append(dict(phase=phase,n=n,ratio=ratio,instance=instance,rep=rep,instance_hash=hashC,
                    seed=base_seed,method=meth,violations=score,seconds=round(secs,7),budget=budget,
                    reads=reads,updates=updates,assignment=fname))
        if k%6==0:
            print(phase,'progress',k+1,'/',len(triallist), 'elapsed',round(time.perf_counter()-T0,1),'sec',flush=True)
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('SAVED',out,len(rows),'rows',flush=True)
    for n in sorted(set(r['n'] for r in rows)):
        for meth in chosen:
            a=np.array([r['violations'] for r in rows if r['n']==n and r['method']==meth])
            sec=np.array([r['seconds'] for r in rows if r['n']==n and r['method']==meth])
            print('SUMMARY',n,meth,'mean',round(a.mean(),3),'median',np.median(a),'solved',int(sum(a==0)),'secs',round(sec.mean(),4),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',required=True,choices=('calibration','confirmation'))
    parser.add_argument('--budget',type=float,default=.075)
    parser.add_argument('--shard',type=int,default=0);parser.add_argument('--shards',type=int,default=1)
    args=parser.parse_args()
    T0=time.perf_counter();main(args.phase,budget=args.budget,shard=args.shard,shards=args.shards)
