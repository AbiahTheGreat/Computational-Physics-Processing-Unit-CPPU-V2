"""Independent shifted-distribution test: 3-XOR constraints encoded exactly as 3-CNF.
Every XOR equation produces four 3-literal clauses. The assignment violates
exactly one clause iff it violates the XOR equation.  Important contrast to
uniform random 3SAT: structured correlated clause groups and plateaus.
"""
import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[v]='1'
import time,hashlib,pathlib,csv,argparse
import numpy as np
from phase8_direct_sat import occurrence_table
from phase9_benchmark import METHODS,run_one,warm,recheck
ROOT=pathlib.Path(__file__).parent

def generate_xor(n,eqs,seed,planted=False):
    rng=np.random.default_rng(seed)
    hidden=rng.integers(0,2,size=n,dtype=np.int8)
    triples=[];clauses=[]
    for t in range(eqs):
        inds=rng.choice(n,3,replace=False)
        parity=(int(hidden[inds[0]]^hidden[inds[1]]^hidden[inds[2]]) if planted else int(rng.integers(0,2)))
        triples.append((int(inds[0]),int(inds[1]),int(inds[2]),parity))
        for a in range(8):
            b0=(a>>0)&1;b1=(a>>1)&1;b2=(a>>2)&1
            if (b0^b1^b2)!=parity:
                clauses.append([int((1 if b0==0 else -1)*(inds[0]+1)),
                                int((1 if b1==0 else -1)*(inds[1]+1)),
                                int((1 if b2==0 else -1)*(inds[2]+1))])
    C=np.asarray(clauses,dtype=np.int32)
    if planted:assert recheck(C,hidden)==0
    return C,np.asarray(triples,dtype=np.int32)

def main(shard):
    warm()
    outdir=ROOT/'assignments_xor';outdir.mkdir(exist_ok=True)
    rows=[];start=time.perf_counter()
    suites=[(n,ratio,2680000+n*100+int(ratio*1000)+i,rep) for n in (256,512) for ratio in (.8,1.1) for i in range(8) for rep in range(2)]
    for k,(n,ratio,seed,rep) in enumerate(suites):
        if k%2!=shard:continue
        C,triples=generate_xor(n,round(n*ratio),seed,planted=False)
        O,P,cnt=occurrence_table(C,n)
        h=hashlib.sha256(C.tobytes()).hexdigest()
        fixedseed=int((seed*41+rep*23)%(2**31-1))
        chosen=METHODS[k%len(METHODS):]+METHODS[:k%len(METHODS)]
        for meth in chosen:
            b,v,t,reads,updates=run_one(meth,C,O,P,cnt,fixedseed,.075)
            # Equivalence of XOR violation count and CNF violated clauses on every result.
            bv=b[triples[:,:3]]
            count_xor=int(np.sum((bv[:,0]^bv[:,1]^bv[:,2])!=triples[:,3]))
            assert v==count_xor
            fname=f'{seed}_{rep}_{meth}.npz';np.savez_compressed(outdir/fname,bits=b)
            rows.append(dict(n=n,ratio=ratio,instance=seed,rep=rep,method=meth,clauses=len(C),
                             instance_hash=h,violations=v,seconds=t,reads=reads,updates=updates,assignment=fname))
        if k%8==shard:print('progress',shard,k+1,'/',len(suites),'sec',round(time.perf_counter()-start,1),flush=True)
    fn=ROOT/f'xor_shard{shard}.csv'
    with fn.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print('DONE',fn,len(rows),flush=True)
    for n in (256,512):
        for meth in METHODS:
            a=[r['violations'] for r in rows if r['n']==n and r['method']==meth]
            print(n,meth,'mean',round(np.mean(a),2),'median',np.median(a),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--shard',type=int,choices=(0,1),required=True)
    args=parser.parse_args();main(args.shard)
