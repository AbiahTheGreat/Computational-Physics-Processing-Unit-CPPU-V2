"""CPPU follow-up: independent SciPy/HiGHS MILP controls for MAX-3SAT.

The event search is Phase9 classical tabu-like search, not original CPPU physics.
MILP objective and clause constraints derived independently from SAT definitions.
All scores recomputed directly from stored assignments, and 'optimal' asserted
only when HiGHS provides a proof of optimality.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[k]='1'
import sys, time, json, csv, hashlib, pathlib, argparse, platform
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_phase9'))
import numpy as np
from scipy.sparse import coo_array
from scipy.optimize import milp, Bounds, LinearConstraint
from phase8_cases import generate_clauses
from phase8_direct_sat import occurrence_table
from phase9_event_core import solve_event
from phase9_stress import generate_xor


def score(C,b):
    return int(np.sum(~np.any(b[np.abs(C)-1] == (C > 0),axis=1)))


def exact_max3sat(C,n,limit):
    """Min sum y_j subject to every clause having a satisfied literal or y_j=1.

    For each literal sign positive x, negative 1-x. For each clause,
    sum_{pos} x_i - sum_{neg} x_i + y_j >= 1-#neg.
    The result is exact iff HiGHS declares it optimal (status == 0).
    """
    m=len(C); ri=[];ci=[];data=[];lb=np.empty(m,float)
    for j,cl in enumerate(C):
        neg=0
        for lit in cl:
            if lit<0: neg+=1
            ri.append(j);ci.append(abs(int(lit))-1);data.append(1. if lit>0 else -1.)
        ri.append(j);ci.append(n+j);data.append(1.)
        lb[j]=1.-neg
    A=coo_array((np.asarray(data,float),(np.asarray(ri,np.int32),np.asarray(ci,np.int32))),shape=(m,n+m)).tocsr()
    c=np.r_[np.zeros(n),np.ones(m)]
    t=time.perf_counter()
    res=milp(c=c,integrality=np.ones(n+m,np.int32),bounds=Bounds(np.zeros(n+m),np.ones(n+m)),
             constraints=LinearConstraint(A,lb,np.full(m,np.inf)),options={'time_limit':limit,'mip_rel_gap':0.0})
    sec=time.perf_counter()-t
    bits=None; violations=None
    if res.x is not None:
        bits=np.rint(res.x[:n]).astype(np.int8)
        violations=score(C,bits)
        # Independently validate all clause constraints and objective bounds.
        if not np.all(np.logical_or(np.any(bits[np.abs(C)-1]==(C>0),axis=1),res.x[n:]>.999999)):
            raise AssertionError('invalid MILP solution')
        if violations>np.rint(sum(res.x[n:]))+1e-5:
            raise AssertionError('MILP reported fewer misses than the returned assignment contains')
        if res.status==0 and abs(violations-np.rint(sum(res.x[n:])))>1e-5:
            raise AssertionError('Certified MILP optimum differs from the returned assignment')
    return {'bits':bits,'violations':violations,'seconds':sec,'status':int(res.status),
            'optimal':bool(res.status==0),'dual_bound':float(getattr(res,'mip_dual_bound',float('nan'))),
            'mip_gap':float(getattr(res,'mip_gap',float('nan'))),'message':str(res.message)}


def search_phase9(C,n,seed,budget,mode):
    O,P,ct=occurrence_table(C,n)
    t=time.perf_counter();best=len(C)+1;bestb=None;reads=0;steps=0
    while reads==0 or (time.perf_counter()-t)<budget:
        b,v,m=solve_event(C,O,P,ct,seed+reads*1013,1500,mode,4,45,.15)
        if score(C,b)!=v:raise AssertionError('event incremental error')
        if v<best:best=v;bestb=b.copy()
        reads+=1;steps+=m
        if best==0:break
    return {'bits':bestb,'violations':int(best),'seconds':time.perf_counter()-t,'reads':reads,'moves':steps}


def planted(n,m,seed):
    C=generate_clauses(n,m,seed)
    rng=np.random.default_rng(seed+1000001)
    hidden=rng.integers(0,2,size=n)
    for j,cl in enumerate(C):
        if not np.any(hidden[np.abs(cl)-1] == (cl>0)):
            # flip a random literal to make it true under the planted assignment
            k=int(rng.integers(3));C[j,k]*=-1
    assert score(C,hidden)==0
    return C


def suite():
    out=[]
    for n,amount in ((24,5),(40,5),(64,5),(96,3),(128,3)):
        for k in range(amount):out.append(('random3',n,4.27,343001+n*1103+k*73))
    for n,amount in ((40,4),(64,4),(96,2)):
        for k in range(amount):out.append(('planted3',n,4.40,363001+n*1103+k*73))
    for n,amount in ((24,3),(40,3),(64,2)):
        for k in range(amount):out.append(('xor3',n,1.10,383001+n*1103+k*73))
    return out


def main(limit,budget):
    # Warm Numba outside comparisons; local controls already exist in Phase9.
    C=generate_clauses(16,68,12345)
    O,P,ct=occurrence_table(C,16)
    for mode in (1,0,3):solve_event(C,O,P,ct,87654,20,mode)
    rows=[];first=time.perf_counter();out=ROOT/'saved_assignments';out.mkdir(exist_ok=True)
    for case_i,(typ,n,ratio,seed) in enumerate(suite()):
        if typ=='xor3':C,_=generate_xor(n,round(n*ratio),seed,planted=False)
        elif typ=='planted3':C=planted(n,round(n*ratio),seed)
        else:C=generate_clauses(n,round(n*ratio),seed)
        C=C.astype(np.int32)
        h=hashlib.sha256(C.tobytes()).hexdigest()
        result=exact_max3sat(C,n,limit)
        methods=[('highs_milp',result)]
        for mode,name in ((1,'event_tabu'),(0,'event_weighted'),(3,'event_probsat_control')):
            methods.append((name,search_phase9(C,n,seed+127, budget,mode)))
        for name,r in methods:
            b=r.get('bits');fn=''
            if b is not None:
                fn=f'{typ}_{n}_{seed}_{name}.npz';np.savez_compressed(out/fn,bits=b)
                if score(C,b)!=r['violations']:raise AssertionError('saving wrong score')
            rows.append(dict(family=typ,n=n,ratio=ratio,seed=seed,sha256=h,method=name,
                violations=r.get('violations'),seconds=round(r['seconds'],6),optimal=r.get('optimal',False),
                solver_status=r.get('status',''),dual_bound=r.get('dual_bound',''),mip_gap=r.get('mip_gap',''),
                reads=r.get('reads',''),moves=r.get('moves',''),assignment=fn))
        print('CASE',case_i+1,len(suite()),typ,n,'MIP',result['violations'],'PROVEN',result['optimal'],'TABU',methods[1][1]['violations'],'WGT',methods[2][1]['violations'],'PROB',methods[3][1]['violations'],flush=True)
    with (ROOT/'phase10_trials.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    report={'cases':len(suite()),'rows':len(rows),'max_milp_time':limit,'max_local_nominal_time':budget,
        'python':platform.python_version(),'scipy':__import__('scipy').__version__,'numpy':np.__version__,
        'elapsed':round(time.perf_counter()-first,2),'family_summary':{},'optimal_count':sum(r['optimal'] for r in rows)}
    for fam in sorted({x['family'] for x in rows}):
        fr=[x for x in rows if x['family']==fam]
        ms={}
        for name in ('highs_milp','event_tabu','event_weighted','event_probsat_control'):
            s=[r for r in fr if r['method']==name and r['violations'] is not None]
            ms[name]={'mean':round(np.mean([r['violations'] for r in s]),3) if s else None,
                      'median':float(np.median([r['violations'] for r in s])) if s else None,
                      'solved_zero':sum(r['violations']==0 for r in s),'trials':len(s),
                      'total_seconds':round(sum(r['seconds'] for r in s),3)}
        report['family_summary'][fam]=dict(solvers=ms,milp_proved=sum(r['optimal'] for r in fr if r['method']=='highs_milp'))
    (ROOT/'phase10_summary.json').write_text(json.dumps(report,indent=2))
    print('SUMMARY',json.dumps(report,indent=2),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--milp-time',type=float,default=0.75);ap.add_argument('--local-time',type=float,default=.075)
    a=ap.parse_args();main(a.milp_time,a.local_time)
