"""Phase 9 SAT event-list search.  New classical search implementation, not original CPPU.
Supports known tabu, PAWS-inspired weights, WalkSAT, and ProbSAT controls.
Incrementally maintains unsatisfied clauses for O(1) uniform selection and O(U) weighted selection.
Scientific description: events cache objective state, not a new physical computation law.
"""
import os
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'): os.environ[k]='1'
import numpy as np
from numba import njit

@njit
def solve_event(C, occ, pol, count, seed, steps=3000, mode=0, tenure=4, pressure_period=45, noise=0.15, verify=False):
    # mode: 0 tabu weighted, 1 tabu unweighted, 2 WalkSAT, 3 ProbSAT, 4 Novelty+-style age-based
    np.random.seed(seed)
    n=len(count); m=len(C)
    b=np.random.randint(0,2,n)
    sat=np.zeros(m,dtype=np.int32)
    for j in range(m):
        for k in range(3):
            lit=C[j,k]; i=abs(lit)-1
            if (lit>0 and b[i]==1) or (lit<0 and b[i]==0):sat[j]+=1
    unsat=np.empty(m,dtype=np.int32)
    pos=np.full(m,-1,dtype=np.int32)
    U=0
    for j in range(m):
        if sat[j]==0:
            pos[j]=U;unsat[U]=j;U+=1
    best=b.copy();bestv=U
    forbid=np.zeros(n,dtype=np.int64)
    weights=np.ones(m,dtype=np.int32)
    lastflip=np.full(n,-100000,dtype=np.int64)
    stagnation=0
    # Track a cheap diagnostic of transitions for independent internal verification.
    moves=0
    for t in range(steps):
        if U==0 or bestv==0: break
        if mode==0 and t>0 and t%pressure_period==0 and stagnation>0:
            for z in range(U):
                j=unsat[z]
                if weights[j]<13:weights[j]+=1
            if t%(10*pressure_period)==0:
                for j in range(m):
                    if weights[j]>1:weights[j]=(weights[j]+1)//2
        if mode==0:
            total=0
            for z in range(U):total+=weights[unsat[z]]
            r=np.random.randint(total)
            j=unsat[0]
            for z in range(U):
                j=unsat[z]
                r-=weights[j]
                if r<0:break
        else:j=unsat[np.random.randint(U)]
        clause=C[j]
        chosen=-1; choosed=0
        bestscore=1e30
        scores=np.zeros(3,dtype=np.float64)
        deltas=np.zeros(3,dtype=np.int32)
        breaks=np.zeros(3,dtype=np.int32)
        for k in range(3):
            i=abs(clause[k])-1
            d=0;dw=0;br=0
            for z in range(count[i]):
                c=occ[i,z]
                active=(b[i]==1 and pol[i,z]==1) or (b[i]==0 and pol[i,z]==-1)
                if active and sat[c]==1:
                    d+=1;dw+=weights[c];br+=1
                elif (not active) and sat[c]==0:
                    d-=1;dw-=weights[c]
            deltas[k]=d;breaks[k]=br
            if mode==0 or mode==1:
                if t<forbid[i] and U+d>=bestv:continue
                value=(dw if mode==0 else d)
                if noise>0:value += (np.random.random()-0.5)*noise*max(1,abs(value))
                if value<bestscore:
                    bestscore=value;chosen=i;choosed=d
            elif mode==2:
                if d<bestscore:
                    bestscore=d;chosen=i;choosed=d
            else:
                scores[k] = (0.2+br)**(-2.3)
        if mode==2 and np.random.random()<0.38:
            k=np.random.randint(3);chosen=abs(clause[k])-1;choosed=deltas[k]
        if mode==3:
            total=scores[0]+scores[1]+scores[2]
            rand=np.random.random()*total
            k=0
            while k<2 and rand>scores[k]:rand-=scores[k];k+=1
            chosen=abs(clause[k])-1;choosed=deltas[k]
        if mode==4:
            # Best/second best move; Novelty-style last-flipped penalty, some exploration.
            kbest=np.argmin(deltas)
            ksecond=(kbest+1)%3
            for kk in range(3):
                if kk!=kbest and deltas[kk]<deltas[ksecond]:ksecond=kk
            if np.random.random()<0.05:kbest=np.random.randint(3)
            elif lastflip[abs(clause[kbest])-1] > lastflip[abs(clause[ksecond])-1] and np.random.random()<0.25:
                kbest=ksecond
            chosen=abs(clause[kbest])-1;choosed=deltas[kbest]
        if chosen<0:
            for k in range(3):forbid[abs(clause[k])-1]=0
            continue
        old=b[chosen];b[chosen]=1-old
        for z in range(count[chosen]):
            c=occ[chosen,z]
            active=(old==1 and pol[chosen,z]==1) or (old==0 and pol[chosen,z]==-1)
            was=sat[c]
            sat[c] += -1 if active else 1
            now=sat[c]
            if was==0 and now>0:
                idx=pos[c]
                U-=1
                swap=unsat[U]
                unsat[idx]=swap;pos[swap]=idx
                pos[c]=-1
            elif was>0 and now==0:
                unsat[U]=c;pos[c]=U;U+=1
        if verify:
            true_U=0
            for jcheck in range(m):
                sc=0
                for kk in range(3):
                    lit=C[jcheck,kk];bi=abs(lit)-1
                    if (lit>0 and b[bi]==1) or (lit<0 and b[bi]==0):sc+=1
                if sc!=sat[jcheck]: raise ValueError('incremental satisfaction count error')
                if sc==0:
                    true_U+=1
                    if pos[jcheck]<0 or pos[jcheck]>=U or unsat[pos[jcheck]]!=jcheck:raise ValueError('unsat list/position mismatch')
                elif pos[jcheck]!=-1:raise ValueError('satisfied clause in unsat list')
            if true_U!=U: raise ValueError('unsat cardinality mismatch')
        lastflip[chosen]=t
        moves+=1
        if mode<2:forbid[chosen]=t+tenure+np.random.randint(0,max(2,tenure//3+1))
        if U<bestv:
            bestv=U;best=b.copy();stagnation=0
        else:stagnation+=1
        # No unrecorded best-state restart: benchmark runner handles multiple independent starts.
    return best, bestv, moves

if __name__=='__main__':
    from phase8_cases import generate_clauses
    from phase8_direct_sat import occurrence_table, count_unsat
    for n in (16,64,256):
        for seed in range(4):
            C=generate_clauses(n,round(n*4.27),seed+951)
            O,P,cnt=occurrence_table(C,n)
            for mode in range(5):
                b,v,moves=solve_event(C,O,P,cnt,seed+10,700,mode)
                assert count_unsat(C,b)==v,(n,seed,mode,v,count_unsat(C,b))
                if n==16:
                    bb,vv,mm=solve_event(C,O,P,cnt,seed+10,70,mode,verify=True)
                    assert count_unsat(C,bb)==vv
    print('Phase9 event-list five-method correctness tests PASS')
