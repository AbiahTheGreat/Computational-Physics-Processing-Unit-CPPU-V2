"""Phase 8 research: DIRECT MAX-3SAT, not original CPPU. Numba CPU-only.

Objective is literal number of unsatisfied clauses. Aspiration, tabu tenure,
and optional clause-weighting/stagnation escape are established local-search ideas.
The 'historical operators' motivated exploration, not a claim of source recovery.
"""
import os
for x in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):
    os.environ[x]='1'
import numpy as np
from numba import njit


def occurrence_table(clauses, n):
    if clauses.ndim != 2 or clauses.shape[1]!=3:raise ValueError('three literals per clause')
    if np.any(np.abs(clauses)>n) or np.any(clauses==0):raise ValueError('invalid literals')
    if any(len(set(np.abs(c)))!=3 for c in clauses):raise ValueError('variables must be distinct per clause')
    cnt=np.bincount(np.abs(clauses).flatten()-1,minlength=n)
    occ=np.full((n,int(cnt.max())), -1, dtype=np.int32)
    pol=np.zeros_like(occ)
    pos=np.zeros(n,dtype=np.int32)
    for j,row in enumerate(clauses):
        for lit in row:
            i=abs(int(lit))-1;k=pos[i];occ[i,k]=j;pol[i,k]=1 if lit>0 else -1;pos[i]+=1
    return occ,pol,pos

@njit
def count_unsat(clauses,b):
    bad=0
    for j in range(len(clauses)):
        sat=0
        for k in range(3):
            lit=clauses[j,k]
            if (lit>0 and b[lit-1]==1) or (lit<0 and b[-lit-1]==0):sat+=1
        if sat==0:bad+=1
    return bad

@njit
def solve(clauses,occ,pol,cnt,seed,steps=3000,tenure=5,weights_mode=0,escape_mode=1):
    """mode 0: plain clause objective, 1: persistent-unsat clause weights.
    escape_mode: 0 none, 1 restart from best with random flips after long stalls.
    Per-turn delta is exact for both true violation counts and weighted auxiliary score.
    Every true best is verified against original clause structure by caller.
    """
    np.random.seed(seed)
    n=len(cnt);m=len(clauses)
    bits=np.random.randint(0,2,n)
    sat=np.zeros(m,dtype=np.int32)
    for j in range(m):
        for k in range(3):
            lit=clauses[j,k];i=abs(lit)-1
            if (lit>0 and bits[i]==1) or (lit<0 and bits[i]==0):sat[j]+=1
    cur=0
    for j in range(m):
        if sat[j]==0:cur+=1
    best=bits.copy();bestv=cur
    tab=np.zeros(n,dtype=np.int64)
    weight=np.ones(m,dtype=np.int32)
    stuck=0
    for t in range(steps):
        if bestv==0:break
        if weights_mode and t%37==0 and t>0 and stuck>0:
            for j in range(m):
                if sat[j]==0 and weight[j]<17:weight[j]+=1
            if t%370==0:
                for j in range(m):
                    if weight[j]>1:weight[j]=(weight[j]+1)//2
        chosen=-1; bestweighted=1e15;chosenraw=0
        for i in range(n):
            raw=0;weighted=0
            for p in range(cnt[i]):
                j=occ[i,p]
                is_true=(bits[i]==1 and pol[i,p]==1) or (bits[i]==0 and pol[i,p]==-1)
                d=0
                if is_true and sat[j]==1:d=1
                elif (not is_true) and sat[j]==0:d=-1
                raw+=d;weighted+=d*weight[j]
            if t<tab[i] and cur+raw>=bestv:continue
            # random tie break to ensure distinct, reproducible trajectories
            v=float(weighted)+np.random.random()*0.001
            if v<bestweighted:
                bestweighted=v;chosen=i;chosenraw=raw
        if chosen<0:
            for i in range(n):tab[i]=0
            continue
        i=chosen;old=bits[i];bits[i]=1-old
        for p in range(cnt[i]):
            j=occ[i,p]
            oldtrue=(old==1 and pol[i,p]==1) or (old==0 and pol[i,p]==-1)
            sat[j]+= -1 if oldtrue else 1
        cur+=chosenraw
        tab[i]=t+tenure+np.random.randint(0,max(2,tenure//3+1))
        if cur<bestv:
            best=bits.copy();bestv=cur;stuck=0
        else:stuck+=1
        if escape_mode and stuck > 7*n and t%(2*n)==0:
            bits=best.copy()
            for z in range(max(2,n//8)):
                q=np.random.randint(n);bits[q]=1-bits[q]
            sat[:]=0
            for j in range(m):
                for k in range(3):
                    lit=clauses[j,k];q=abs(lit)-1
                    if (lit>0 and bits[q]==1) or (lit<0 and bits[q]==0):sat[j]+=1
            cur=0
            for j in range(m):
                if sat[j]==0:cur+=1
            for q in range(n):tab[q]=0
            stuck=0
    return best,bestv

if __name__=='__main__':
    rng=np.random.default_rng(42)
    for n in (8,16):
        for seed in range(3):
            rows=[]
            for _ in range(4*n):
                ids=rng.choice(n,3,False)+1
                rows.append(ids*rng.choice(np.array([-1,1]),3))
            C=np.array(rows,dtype=np.int32);o,p,c=occurrence_table(C,n)
            for mode in range(2):
                b,v=solve(C,o,p,c,seed,400,3,mode)
                assert count_unsat(C,b)==v
    print('Direct-clause solver self-tests passed')
