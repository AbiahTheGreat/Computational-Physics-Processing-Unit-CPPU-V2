# ===============================================================
#  plunder_allinone_final.py  (FINAL JSON-SAFE VERSION)
# ===============================================================

import argparse, os, time, json, subprocess, sys
import numpy as np
import torch
import random
from pathlib import Path

# ---------------------------------------------------------------
#  Optional temp sensors
# ---------------------------------------------------------------
try:
    import pynvml
    pynvml.nvmlInit()
    HAVE_NVML = True
except:
    HAVE_NVML = False

def get_gpu_temp():
    if not HAVE_NVML:
        return None
    try:
        h = pynvml.nvmlDeviceGetHandleByIndex(0)
        return float(pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU))
    except:
        return None

def get_cpu_temp():
    return None

# ---------------------------------------------------------------
#  Stable hypersphere projection
# ---------------------------------------------------------------
def project_hypersphere(x):
    if x.dim() == 1:
        return x / x.norm().clamp_min(1e-12)
    elif x.dim() == 2:
        return x / x.norm(dim=1, keepdim=True).clamp_min(1e-12)
    else:
        raise ValueError(f"Bad shape: {x.shape}")

# ---------------------------------------------------------------
#  Energy functions
# ---------------------------------------------------------------
def cont_energy_per_agent(x, J, h):
    return -(x * (x @ J.t()) + h * x).sum(dim=1)

def binarize(x):
    return torch.sign(x)

def bin_energy(b, J, h):
    E = []
    for i in range(b.size(0)):
        v = b[i]
        E.append((-(v @ (J @ v) + h @ v)).item())
    return torch.tensor(E)

# ---------------------------------------------------------------
#  INTERNAL PLUNDER ENGINE
# ---------------------------------------------------------------
def run_plunder(J, h, cfg):

    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)
    random.seed(cfg.seed)

    device = cfg.device
    n = J.size(0)
    agents = cfg.agents

    x = torch.randn(agents, n, device=device)
    x = project_hypersphere(x)

    memory = []
    best_E = float("inf")
    best_assign = None

    D = cfg.D0
    dt = cfg.dt

    for step in range(cfg.steps):

        grad = -(x @ J + h)

        drift = -cfg.alpha * grad
        drift = drift - (drift * x).sum(dim=1, keepdim=True) * x

        noise = torch.randn_like(x) * (2 * D * dt)**0.5
        noise = noise - (noise * x).sum(dim=1, keepdim=True) * x

        x = x + drift * dt + noise
        x = project_hypersphere(x)

        D *= cfg.adaptive_gain

        if step % cfg.mem_inject_every == 0 and len(memory) > 0:
            idx = np.random.randint(len(memory))
            mem_vec = memory[idx]
            a = np.random.randint(agents)
            blended = (1 - cfg.mem_blend) * x[a] + cfg.mem_blend * mem_vec
            x[a] = project_hypersphere(blended)

        if step % cfg.log_every == 0 or step == cfg.steps - 1:
            b = binarize(x)
            Es = bin_energy(b, J, h)
            mn = Es.min().item()
            if mn < best_E:
                best_E = mn
                best_assign = b[Es.argmin()].clone()

            if len(memory) < cfg.mem_size:
                memory.append(best_assign.clone())
            else:
                memory.pop(0)
                memory.append(best_assign.clone())

            print(f"[{step:6d}] best_binE={best_E:.3f} mean_contE={cont_energy_per_agent(x,J,h).mean().item():.6f} D={D:.5f} mem={len(memory)}")

    # 🚨 JSON-SAFE OUTPUT FIX HERE
    return {
        "best_E": float(best_E),
        "best_assign": best_assign.cpu().numpy().astype(int).tolist(),
        "steps": cfg.steps
    }

# ---------------------------------------------------------------
#  3-SAT & QUBO
# ---------------------------------------------------------------
def generate_3sat(nvars):
    ratio = 4.27
    n_clauses = int(ratio * nvars)
    clauses = []
    for _ in range(n_clauses):
        clause = []
        for _ in range(3):
            v = random.randint(1, nvars)
            s = random.choice([-1, 1])
            clause.append(s * v)
        clauses.append(tuple(clause))
    return clauses

def qubo_from_3sat(clauses, nvars):
    Q = np.zeros((nvars, nvars))
    for (a,b,c) in clauses:
        lits = [a,b,c]
        for i in range(3):
            vi = abs(lits[i]) - 1
            si = 1 if lits[i] > 0 else -1
            Q[vi, vi] += 1
            for j in range(i+1,3):
                vj = abs(lits[j]) - 1
                sj = 1 if lits[j] > 0 else -1
                Q[vi, vj] += si * sj
                Q[vj, vi] += si * sj
    return Q

def qubo_to_ising(Q):
    Q = 0.5*(Q+Q.T)
    n = Q.shape[0]
    h = np.zeros(n)
    J = np.zeros_like(Q)
    for i in range(n):
        h[i] = Q[i,i]/2
        for j in range(i+1,n):
            J[i,j] = Q[i,j]/4
            J[j,i] = J[i,j]
    return J, h, 0.0

# ---------------------------------------------------------------
#  SK model
# ---------------------------------------------------------------
def generate_SK(N):
    J = np.random.normal(0, 1/np.sqrt(N), size=(N,N))
    J = np.triu(J,1)
    J = J+J.T
    np.fill_diagonal(J,0)
    h = np.zeros(N)
    return J, h

# ---------------------------------------------------------------
#  cfg builder
# ---------------------------------------------------------------
def build_cfg(args):
    return argparse.Namespace(
        agents=args.agents,
        steps=args.steps,
        dt=args.dt,
        D0=args.D0,
        mem_size=args.mem_size,
        mem_inject_every=args.mem_inject_every,
        mem_blend=args.mem_blend,
        alpha=1.0,
        adaptive_gain=0.995,
        log_every=250,
        seed=12345,
        device=("cuda" if args.device=="cuda" and torch.cuda.is_available() else "cpu")
    )

# ---------------------------------------------------------------
#  MAIN
# ---------------------------------------------------------------
def main():
    p = argparse.ArgumentParser()

    p.add_argument("--which", choices=["3sat","sk","both"], default="both")
    p.add_argument("--device", default="auto")
    p.add_argument("--agents", type=int, default=64)
    p.add_argument("--steps", type=int, default=50000)
    p.add_argument("--dt", type=float, default=0.001)
    p.add_argument("--D0", type=float, default=0.05)
    p.add_argument("--mem_size", type=int, default=800)
    p.add_argument("--mem_inject_every", type=int, default=500)
    p.add_argument("--mem_blend", type=float, default=0.3)
    p.add_argument("--hard", action="store_true")
    p.add_argument("--use_sys_time", action="store_true")
    p.add_argument("--use_sys_temp", action="store_true")
    p.add_argument("--save_prefix", default="plunder_allinone")

    args = p.parse_args()

    outdir = Path(args.save_prefix)
    outdir.mkdir(exist_ok=True)

    # ----------------- 3-SAT --------------------
    if args.which in ["3sat","both"]:
        print("Generating 3-SAT…")
        n = 400
        clauses = generate_3sat(n)
        Q = qubo_from_3sat(clauses, n)
        np.save(outdir/"3sat_Q.npy", Q)

        J, h, _ = qubo_to_ising(Q)
        Jt = torch.tensor(J, dtype=torch.float32)
        ht = torch.tensor(h, dtype=torch.float32)

        cfg = build_cfg(args)

        print("Running plunder on 3-SAT…")
        res = run_plunder(Jt, ht, cfg)

        with open(outdir/"3sat_results.json","w") as f:
            json.dump(res,f,indent=2)

    # ----------------- SK -----------------------
    if args.which in ["sk","both"]:
        print("Generating SK model…")
        J, h = generate_SK(1000)
        np.save(outdir/"SK_J.npy", J)

        Jt = torch.tensor(J, dtype=torch.float32)
        ht = torch.tensor(h, dtype=torch.float32)

        cfg = build_cfg(args)

        print("Running plunder on SK…")
        res = run_plunder(Jt, ht, cfg)

        with open(outdir/"SK_results.json","w") as f:
            json.dump(res,f,indent=2)

    print("All tasks complete.")

if __name__ == "__main__":
    main()
