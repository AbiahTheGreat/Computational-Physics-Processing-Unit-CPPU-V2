"""Phase8b focused clause-pressure search: new classical SAT heuristic, NOT source-original CPPU.
Uses exact clause violations, dynamic clause pressures, and temporary variable refractory memory.
Unlike global scan direct_sat, inspects only variables in an unsatisfied clause.
"""
import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[v]='1'
import numpy as np
from numba import njit

@njit
def focused_memory(clauses,occ,pol,cnt,seed,steps=3500,tenure=5,pressure=1,escape=1,noise=0.15):
    np.random.seed(seed)
    n=len(cnt);m=len(clauses)
    b=np.random.randint(0,2,n)
    sat=np.zeros(m,dtype=np.int32)
    for j in range(m):
        for k in range(3):
            lit=clauses[j,k];i=abs(lit)-1
            if (lit>0 and b[i]==1) or (lit<0 and b[i]==0):sat[j]+=1
    cur=0
    for j in range(m):
        if sat[j]==0:cur+=1
    best=b.copy();bestv=cur
    forbid=np.zeros(n,dtype=np.int64)
    w=np.ones(m,dtype=np.int32)
    stuck=0
    for t in range(steps):
        if bestv==0:break
        if pressure and stuck>0 and t>0 and t%45==0:
            for j in range(m):
                if sat[j]==0 and w[j]<13:w[j]+=1
            if t%450==0:
                for j in range(m):
                    if w[j]>1:w[j]=(w[j]+1)//2
        selected=-1;accum=0
        # Sample unsatisfied clauses, weighted by pressure; separate randomness from tie handling.
        for j in range(m):
            if sat[j]==0:
                q=w[j] if pressure else 1
                accum+=q
                if np.random.random()*accum<q:selected=j
        if selected<0:break
        clause=clauses[selected]
        chosen=-1;chosen_delta=0;bestmove=1e20
        for k in range(3):
            i=abs(clause[k])-1
            d=0;dw=0
            for z in range(cnt[i]):
                j=occ[i,z]
                istr=(b[i]==1 and pol[i,z]==1) or (b[i]==0 and pol[i,z]==-1)
                if istr and sat[j]==1:d+=1;dw+=w[j]
                elif not istr and sat[j]==0:d-=1;dw-=w[j]
            if t<forbid[i] and cur+d>=bestv:continue
            # Soft random noise is a standard diversification heuristic, not hardware temperature.
            val=dw + (np.random.random()-0.5)*noise*max(1,abs(dw))
            if val<bestmove:
                bestmove=val;chosen=i;chosen_delta=d
        if chosen<0:
            # Avoid permanent deadlocks due to memory prohibitions
            for k in range(3):forbid[abs(clause[k])-1]=0
            continue
        old=b[chosen];b[chosen]=1-old
        for z in range(cnt[chosen]):
            j=occ[chosen,z]
            istr=(old==1 and pol[chosen,z]==1) or (old==0 and pol[chosen,z]==-1)
            sat[j] += -1 if istr else 1
        cur+=chosen_delta
        forbid[chosen]=t+tenure+np.random.randint(0,max(2,tenure//3+1))
        if cur<bestv:
            best= b.copy();bestv=cur;stuck=0
        else:stuck+=1
        if escape and stuck>8*n and t%(2*n)==0:
            b=best.copy()
            for z in range(max(2,n//10)):
                i=np.random.randint(n);b[i]=1-b[i]
            sat[:]=0
            for j in range(m):
                for k in range(3):
                    lit=clauses[j,k];i=abs(lit)-1
                    if (lit>0 and b[i]==1) or (lit<0 and b[i]==0):sat[j]+=1
            cur=0
            for j in range(m):
                if sat[j]==0:cur+=1
            for i in range(n):forbid[i]=0
            stuck=0
    return best,bestv

if __name__=='__main__':
    from phase8_direct_sat import occurrence_table,count_unsat
    import sys
    
    from phase8_cases import generate_clauses
    for n in [32,64,128]:
        for se in range(5):
            C=generate_clauses(n,round(n*4.27),700+se)
            O,P,c=occurrence_table(C,n)
            b,v=focused_memory(C,O,P,c,se,1200,5,1,1)
            assert v==count_unsat(C,b)
    print('Focused-memory tests passed')
