"""CPPU phase 6: explicitly separate original Plunder, new physical-state hybrid, and ordinary baselines.
All optimization methods are exploratory; new variants are not byte-preserved original CPPU.
"""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS']:
    os.environ[k]='1'
import numpy as np
from numba import njit

@njit
def value(J,h,s):
    return -(s@(J@s)+h@s)

@njit
def quench(J,h,s):
    n=len(s)
    s=s.copy()
    field=J@s
    for step in range(10*n):
        bestd=-1e-10; idx=-1
        for i in range(n):
            d=4*s[i]*field[i]+2*s[i]*h[i]
            if d<bestd:bestd=d;idx=i
        if idx<0:break
        v=s[idx];s[idx]=-v
        for j in range(n):field[j]-=2*v*J[j,idx]
    return s

@njit
def kick(J,h,s,rng_seed,steps,temperature=0.6):
    np.random.seed(rng_seed)
    n=len(s);s=s.copy();field=J@s
    for t in range(steps):
        i=np.random.randint(n)
        d=4*s[i]*field[i]+2*s[i]*h[i]
        if d < 0 or np.random.random()<np.exp(-d/temperature):
            v=s[i];s[i]=-v
            for j in range(n):field[j]-=2*v*J[j,i]
    return s

@njit
def run_dynamics(J,h,seed,niter=900,replicas=8,method=0,quench_every=30,pump=1.5,noise=0.10,feedback=0.35):
    """Coupled quartic potential/spins; changes to original CPPU are explicitly experimental.
    method 0: continuous analog + quench, memory-feedback on best
    method 1: continuous analog + quench, no feedback
    method 2: discrete kick + quench basin hopping
    method 3: random restart greedy only (control)
    """
    np.random.seed(seed)
    n=len(h)
    best=np.ones(n,dtype=np.float64)
    bestv=1e300
    localfieldscale=0.
    for i in range(n):
        l=h[i]*h[i]
        for j in range(n):l+=4*J[i,j]*J[i,j]
        localfieldscale+=l
    localfieldscale=max(np.sqrt(localfieldscale/n),1e-10)
    for a in range(replicas):
        x=np.empty(n,dtype=np.float64)
        if method==3:
            for i in range(n):x[i]=1. if np.random.random()>.5 else -1.
            s=quench(J,h,x)
            v=value(J,h,s)
            if v<bestv:bestv=v;best=s.copy()
            continue
        if method==2:
            for i in range(n):x[i]=1. if np.random.random()>.5 else -1.
            s=quench(J,h,x)
            v=value(J,h,s)
            if v<bestv:bestv=v;best=s.copy()
            for cycle in range(max(1,niter//quench_every)):
                s=kick(J,h,s,seed + a*9127 + cycle*71,max(1,int(n*(0.04+cycle/(max(1,niter//quench_every))*0.25))),0.4+0.8*np.random.random()*localfieldscale)
                s=quench(J,h,s)
                v=value(J,h,s)
                if v<bestv:bestv=v;best=s.copy()
            continue
        for i in range(n):x[i]=0.35*np.random.randn()
        for step in range(niter):
            progress=step/max(niter-1,1)
            delta=0.025
            # Nonlinear bistable potential + corrected exact Ising drift, with annealed thermal forcing
            coupling=2*(J@x)+h
            pumpk=pump*(2*progress-1.)
            for i in range(n):
                drift=1.4*coupling[i]/localfieldscale + pumpk*x[i]-x[i]*x[i]*x[i]
                stochastic= np.sqrt(2*noise*delta)*max(0.02,1-progress)*np.random.randn()
                x[i]=min(3.5,max(-3.5,x[i]+delta*drift+stochastic))
            if step%quench_every==0 or step==niter-1:
                s=np.where(x>=0,1.,-1.)
                s=quench(J,h,s)
                v=value(J,h,s)
                if v<bestv:
                    bestv=v;best=s.copy()
                if method==0:
                    # Feedback from verified discrete state into continuous physical state
                    for i in range(n):
                        x[i]=(1-feedback)*x[i]+feedback*s[i]
    return best,bestv

@njit
def sa_fixed(J,h,seed,sweeps=160):
    """Independent single-flip SA. Equivalent discrete Ising objective, each sweep ~n attempted flips."""
    np.random.seed(seed)
    n=len(h)
    s=np.empty(n,dtype=np.float64)
    for i in range(n):s[i]=1 if np.random.random()<.5 else -1
    field=J@s
    ene=value(J,h,s)
    best= s.copy();bestv=ene
    scale=0.
    for i in range(n):
        scale+=h[i]*h[i]
        for j in range(n):scale+=4*J[i,j]*J[i,j]
    scale=np.sqrt(scale/n)
    T0=max(0.1,5*scale); Tf=max(0.001,0.004*T0)
    for k in range(sweeps):
        T=T0*(Tf/T0)**(k/max(1,sweeps-1))
        for z in range(n):
            i=np.random.randint(n)
            d=4*s[i]*field[i]+2*s[i]*h[i]
            if d<0 or np.random.random()<np.exp(-d/T):
                old=s[i];s[i]=-old;ene+=d
                for j in range(n):field[j]-=2*old*J[j,i]
                if ene<bestv:
                    bestv=ene;best=s.copy()
    return best,value(J,h,best)

@njit
def run_sa_budget(J,h,seed,seconds,sweeps=120):
    # Time measurement in Python wrapper; Numba nopython mode can't call perf_counter here.
    return sa_fixed(J,h,seed,sweeps)

@njit
def sat_violations(clauses,b):
    v=0
    for j in range(clauses.shape[0]):
        good=False
        for k in range(3):
            lit=clauses[j,k];i=abs(lit)-1
            if (lit>0 and b[i]==1) or (lit<0 and b[i]==0):good=True
        if not good:v+=1
    return v

@njit
def walksat(clauses,n,seed,flips=3000,p_noise=0.38):
    # Plain WalkSAT baseline, test on exactly same original clauses and count actual violations.
    np.random.seed(seed)
    b=np.random.randint(0,2,n)
    best=b.copy();bestv=sat_violations(clauses,b)
    for step in range(flips):
        unsat=np.empty(clauses.shape[0],dtype=np.int32);num=0
        for j in range(clauses.shape[0]):
            good=False
            for k in range(3):
                lit=clauses[j,k];i=abs(lit)-1
                if (lit>0 and b[i]==1) or (lit<0 and b[i]==0):good=True
            if not good:
                unsat[num]=j;num+=1
        if num<bestv:
            bestv=num;best=b.copy()
        if num==0:break
        clause=clauses[unsat[np.random.randint(num)]]
        if np.random.random()<p_noise:
            ix=abs(clause[np.random.randint(3)])-1
        else:
            ix=-1;vmin=1e9
            for k in range(3):
                i=abs(clause[k])-1;b[i]=1-b[i]
                v=sat_violations(clauses,b)
                b[i]=1-b[i]
                if v<vmin:vmin=v;ix=i
        b[ix]=1-b[ix]
    return best,bestv

@njit
def direct_sat_continuous(clauses,n,seed,steps=1600,replicas=6,pump=1.4,noise=0.12,feedback=0.25):
    # Exact expected count of violated clauses on independent Bernoulli spins x in [-1,1],
    # E[c violation] = product_l (1-sign(l)*x[var])/2; has valid continuous gradient.
    np.random.seed(seed)
    best=np.zeros(n,dtype=np.int64);bestv=10**9
    for a in range(replicas):
        x=0.4*np.random.randn(n)
        for t in range(steps):
            prog=t/max(steps-1,1)
            grad=np.zeros(n,dtype=np.float64)
            for j in range(clauses.shape[0]):
                lits=clauses[j]
                p0=np.empty(3,dtype=np.float64)
                signs=np.empty(3,dtype=np.float64)
                ids=np.empty(3,dtype=np.int64)
                for k in range(3):
                    lit=lits[k]; ids[k]=abs(lit)-1; signs[k]=1 if lit>0 else -1
                    p0[k]=0.5*(1-signs[k]*x[ids[k]])
                for k in range(3):
                    d=-0.5*signs[k]*p0[(k+1)%3]*p0[(k+2)%3]
                    grad[ids[k]]+=d
            for i in range(n):
                drift= -3.0*grad[i]/(clauses.shape[0]/n) + pump*(2*prog-1)*x[i]-x[i]**3
                x[i]=max(-1.,min(1.,x[i]+0.025*drift+np.sqrt(2*noise*.025)*max(.02,1-prog)*np.random.randn()))
            if (t%40)==0 or t==steps-1:
                s=(x>0).astype(np.int64)
                v=sat_violations(clauses,s)
                if v<bestv:bestv=v;best=s.copy()
                if feedback>0:
                    for i in range(n):x[i]=(1-feedback)*x[i]+feedback*(2*s[i]-1)
    return best,bestv

if __name__=='__main__':
    rng=np.random.default_rng(22);n=8;J=rng.normal(size=(n,n));J=(J+J.T)/2;np.fill_diagonal(J,0);h=rng.normal(size=n)
    for s in (rng.choice([-1.,1.],size=n) for _ in range(8)):
        assert value(J,h,quench(J,h,s))<=value(J,h,s)+1e-8
    for method in range(4):
        s,e=run_dynamics(J,h,22,100,2,method)
        print(method,e)
    s,e=sa_fixed(J,h,22,12);print('SA',e)

@njit
def refractory_ising(J,h,seed,steps=6000,tenure=13,perturb=0.0,source=None):
    """Discrete dynamics with temporal refractory memory. Conventional tabu-like operator;
    not original CPPU and no claim of a new algorithm. Optional input 'source' starts from analog CPPU seed.
    """
    np.random.seed(seed)
    n=len(h)
    if source is None:
        s=np.empty(n,dtype=np.float64)
        for i in range(n):s[i]=1. if np.random.random()<.5 else -1.
    else:
        s=source.copy().astype(np.float64)
    field=J@s
    cur=value(J,h,s);bestv=cur;best=s.copy()
    forbid=np.zeros(n,dtype=np.int32)
    stuck=0
    for t in range(steps):
        # energy as exact bit-flip delta, plus small annealed randomized tie-breaking
        bestd=1e300;k=-1
        for i in range(n):
            d=4*s[i]*field[i]+2*s[i]*h[i]
            # aspiration if new global optimum; otherwise obey refractory interval
            if t>=forbid[i] or cur+d<bestv-1e-8:
                if perturb != 0.0:
                    d+=perturb*np.random.randn()
                if d<bestd:bestd=d;k=i
        if k<0:
            for i in range(n):forbid[i]=0
            continue
        d=4*s[k]*field[k]+2*s[k]*h[k]
        v=s[k];s[k]=-v;cur+=d
        for j in range(n):field[j]-=2*v*J[j,k]
        forbid[k]=t+tenure+np.random.randint(0,max(2,tenure//2))
        if cur<bestv-1e-8:
            bestv=cur;best=s.copy();stuck=0
        else:stuck+=1
        if stuck>n*8 and (t%max(1,2*n))==0:
            # erase temporal memory, shake from best-known configuration
            s=best.copy()
            for z in range(max(2,n//12)):
                i=np.random.randint(n);s[i]=-s[i]
            field=J@s;cur=value(J,h,s)
            for i in range(n):forbid[i]=0
            stuck=0
    return best,value(J,h,best)
