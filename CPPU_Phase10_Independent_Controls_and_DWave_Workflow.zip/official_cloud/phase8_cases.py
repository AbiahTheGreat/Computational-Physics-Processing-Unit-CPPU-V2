"""Portable benchmark instance generation for phase 7.
Exact function bodies copied/adapted from benchmark_round2.py and phase6_heldout.py,
using numpy only. SAT QUBO has one auxiliary bit per clause.
"""
import numpy as np

def qubo_to_cppu_correct(Q):
    Q=np.asarray(Q,dtype=np.float64)
    assert Q.shape[0]==Q.shape[1] and np.allclose(Q,Q.T,atol=1e-12)
    J=-Q/4
    np.fill_diagonal(J,0.0)
    h=-Q.sum(axis=1)/2
    constant=(Q.sum()+np.trace(Q))/4
    return J,h,float(constant)

def make_affine_terms(lit):
    return ((1.,-1.) if lit>0 else (0.,1.)),abs(lit)-1

def sat_to_symmetric_Q(clauses,n,penalty=2.0):
    m=len(clauses);Q=np.zeros((n+m,n+m),dtype=float);constant=0.
    def addlin(i,a):Q[i,i]+=a
    def addpair(i,j,a):
        assert i!=j
        Q[i,j]+=a/2;Q[j,i]+=a/2
    for j,cl in enumerate(clauses):
        if len({abs(v) for v in cl})!=3:raise ValueError('distinct variables needed in each clause')
        (c1,a1),i1=make_affine_terms(cl[0]);(c2,a2),i2=make_affine_terms(cl[1]);(c3,a3),i3=make_affine_terms(cl[2])
        iy=n+j
        constant+=penalty*c1*c2
        addlin(i1,penalty*a1*c2);addlin(i2,penalty*a2*c1)
        addpair(i1,i2,penalty*a1*a2)
        addlin(iy, (c3+penalty*(3-2*c1-2*c2)))
        addpair(iy,i1,-2*penalty*a1)
        addpair(iy,i2,-2*penalty*a2)
        addpair(iy,i3,a3)
    return Q,float(constant)

def generate_clauses(n,m,seed):
    rng=np.random.default_rng(seed)
    cl=[]
    for _ in range(m):
        vs=rng.choice(n,size=3,replace=False)+1
        neg=rng.choice(np.array([-1,1]),size=3)
        cl.append([int(a*b) for a,b in zip(vs,neg)])
    return np.asarray(cl,dtype=np.int32)

def make_case(kind,seed):
    if kind=='SK':
        n=256;rng=np.random.default_rng(seed)
        A=np.triu(rng.normal(0,1/np.sqrt(n),(n,n)),1)
        return {'name':f'SK256_{seed}','kind':'SK','J':A+A.T,'h':np.zeros(n),'nvars':n,'clauses':None,'offset':0.}
    n=32;cl=generate_clauses(n,round(4.27*n),seed+70000)
    Q,c=sat_to_symmetric_Q(cl,n)
    J,h,k=qubo_to_cppu_correct(Q)
    return {'name':f'SAT32_{seed}','kind':'SAT','J':J,'h':h,'nvars':n,'clauses':cl,'offset':c+k}

if __name__=='__main__':
    for seed in (76001,96001,126001):
        for kind in ('SK','SAT'):
            c=make_case(kind,seed)
            assert np.allclose(c['J'],c['J'].T)
            assert np.allclose(np.diag(c['J']),0)
    print('Instance construction passes elementary checks')
