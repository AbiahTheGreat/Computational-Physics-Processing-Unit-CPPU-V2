# CPPU Phase 10, verified research handoff

**Status: 284 newly saved assignment scores independently checked; 25 MILP optimality certificates. Official D-Wave benchmark still NOT RUN.**

- `PHASE10_REPORT.md`: full findings, limitations, source attribution and exact counts.
- `phase10_trials.csv`: 156 scores, with independent HiGHS MILP reference and optimality status.
- `phase10_long_verified.csv`: 128 independently recomputed scores; timing missing for 84 due to restart after timeout.
- `phase10_summary.json`, `phase10_long_audit.json`: objective summaries and paired counts.
- `saved_assignments/`, `saved_long_budget/`: exact binary assignments from every experiment.
- `source_phase9/`: original unchanged Phase 9 classical local-search implementation and instance generators.
- `official_cloud/`: source-original Plunder, current Phase 9 solvers, and official D-Wave runner.
- `phase10_github_workflow.yml`: copy to `.github/workflows/phase10-dwave.yml` to run on GitHub Actions after committing this complete ZIP to the repository root.

**No score in this package is an executed official Neal/Tabu benchmark.**
