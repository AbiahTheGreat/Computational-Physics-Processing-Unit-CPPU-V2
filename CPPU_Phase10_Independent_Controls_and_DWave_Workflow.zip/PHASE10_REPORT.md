# CPPU Phase 10: Independent HiGHS controls, longer-budget stress, and official D-Wave handoff

Research continuation: November 7, 2026. Source: archived original Plunder (SHA256 `3b9cf879b93132fa86a9b8fd3a4d2dd2f20e4654bc4f2b504f31964cc25f767a`) and the separately labeled Phase 9 classical event-driven local-search code.

## Findings

**The actual official D-Wave benchmark remains unexecuted.** Attempts to install `dwave-samplers`, `dimod`, and/or `dwave-neal` in the current sandbox failed due to unavailable packages/network. Do not interpret results below as D-Wave Neal or D-Wave Tabu results. The `official_cloud` folder holds a preflighted runner and workflow for a GitHub-hosted official experiment. The modern API is `dwave.samplers.SimulatedAnnealingSampler` (which D-Wave documents as the successor/alias to Neal).

### Test A: An independent solver with proof certificates

I formulated unweighted MAX-3SAT as a mixed-integer linear program (MILP), minimizing one binary unsatisfied-clause indicator per clause, with exact clause-satisfaction inequalities. A separately maintained implementation, **SciPy/HiGHS MILP**, produced independent lower bounds and optimality certificates. Compared alongside the *classical Phase 9* event-tabu, weighted tabu and ProbSAT-style controls. The MILP solver had a **0.75-second per-instance limit**, while each local method had a nominal **0.075-second limit**, so this is not a claim of equal-compute competition; HiGHS is primarily an independent reference and certification control.

- 39 fresh instances: 21 random MAX-3SAT, 10 satisfiable planted MAX-3SAT, and 8 XOR-derived MAX-3SAT; sizes 24–128 variables.
- 156 stored assignments; all independently rescored.
- HiGHS **proved optimality on 25 of 39 cases**, including 12/21 random, 9/10 planted, and 4/8 XOR-derived. In *all 25 certified cases*, no local solver exceeded the proven optimal result.
- All three local methods attained **the same best objective** for each of 39 cases, despite different search dynamics. This is a ceiling effect on easier instances, not evidence that the methods are equivalent on difficult problems.
- On multiple larger cases HiGHS reached a time limit and returned a nonoptimal incumbent, sometimes worse than the local search result. A feasible MILP incumbent is **not** an optimum unless HiGHS returned status `optimal`.
- A time-limited MILP incumbent can have extra clause slack variables left at 1 even when clauses are satisfied; those cases were scored independently using the actual Boolean assignment. The independent audit verifies this and does not misrepresent the MILP objective as the clause score.

### Test B: 0.4-second nominal long-budget continuation

32 additional held-out instances: 12 random 512-variable, 12 random 1,024-variable, and 8 XOR-derived 512-variable. Four search algorithms; 128 saved assignments independently rescored. These tests use a larger nominal time per method than the Phase 9 75 ms trials. **A run reached an execution timeout after the first 21 cases.** The 21 completed instances' assignments were preserved but their detailed runtime/iteration metadata were not; the remaining 11 cases were run separately with the identical code and target budget. Thus all 128 scores are preserved, but exact run-time metrics are available for only **44 of 128 solver assignments**. Do not claim all 128 runs were proven exactly equal wall-clock.

Mean violated clauses (smaller is better):

| Test set | Event tabu | Event + clause weights | Local ProbSAT-style | Local Novelty-style |
|---|---:|---:|---:|---:|
| Random MAX-3SAT, 512 variables (12) | 3.083 | **2.500** | **2.500** | 3.667 |
| Random MAX-3SAT, 1,024 variables (12) | 13.333 | **12.000** | 15.417 | 14.333 |
| XOR-derived MAX-3SAT, 512 variables (8) | **14.125** | 22.750 | 23.250 | 17.750 |

At the longer target budget, clause weighting improved random cases modestly but was markedly worse on structured XOR-derived clauses. Therefore **there is no single universally best of these Phase 9 variants**; the intended problem family matters. This qualification matters more than any one win. With so few instances and some missing per-trial timing metadata, all comparisons are exploratory.

**Paired bootstrap 95% intervals** (opponent minus event tabu, positive favors event tabu), resampling instances:

- Random 512, weighted: -0.583, interval [-1.333, 0.000].
- Random 1,024, weighted: -1.333, interval [-3.250, 0.750].
- XOR-derived 512, weighted: +8.625, interval [2.250, 14.875].

The random results do not establish a statistically robust advantage for weighting, whereas the XOR reversal is substantial within this particular small test set.

### What is and is not CPPU

The original archived Plunder solver has been byte-preserved and executed again (a separate 16-spin smoke test). It is a software implementation of stochastic continuous physical-style dynamics, **not** a quantum device and not a validated hardware accelerator. The Phase 7–9 optimizers are newer conventional classical local-search algorithms, influenced by the user's research. Their results must not be attributed to novel CPPU operators.

### Remaining external limitations

- **Official D-Wave SA/Neal and Tabu:** prepared GitHub Actions runner; package install unavailable locally, so unrun. Modern Neal's API has moved to `dwave.samplers` in the current Ocean SDK.
- **MaxSAT Evaluation 2026:** independently maintained competition uses WCNF/weighted/partial instances beyond this 3-distinct-literal-only implementation. Its benchmark set has not been downloaded or executed here.
- **MIPLIB:** general mixed-integer linear constraints are not accepted by the Phase 9 native SAT engine, and the Plunder Ising backend would require an independently verified and often large constrained QUBO encoding. No MIPLIB score has been generated.
- **External independent optimized MaxSAT competitors:** no externally maintained specialist binary was available locally. The local ProbSAT/Novelty controls are implementations of their strategies, not official reference implementations.
- **Time-to-target and hardware comparisons:** need a more durable dedicated host with exact software versions, fixed budgets and logs; any GPU-vs-CPU result must disclose hardware.

## Reproduction

Run from `phase10/`:

```bash
python phase10_independent_milp.py --milp-time 0.75 --local-time 0.075
python phase10_independent_audit.py
python phase10_long_budget.py 0.4  # long, can timeout; all final 128 assignments are already saved
cd official_cloud
python phase10_official_dwave_runner.py --preflight
```

`phase10_github_workflow.yml` is designed to live at `.github/workflows/phase10-dwave.yml` in the user's repository **after** the root-level archive `CPPU_Phase10_Independent_Controls_and_DWave_Workflow.zip` is uploaded. Trigger `Actions > CPPU Phase 10 vs Official D-Wave Simulated Annealing and Tabu > Run workflow` using GitHub web, including mobile. The GitHub workflow contains no API tokens or machine secrets and runs the official benchmark on GitHub Actions cloud resources; it will save `official-dwave-phase10-results` for independent review.

The official runner captures original Plunder, modern D-Wave SA, optional D-Wave Tabu, Phase 7, and Phase 9 on corresponding Ising/SAT instances, rescoring all solutions independently. The workflow must actually execute before results can be reported to Murray as D-Wave results.
